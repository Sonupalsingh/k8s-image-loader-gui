"""Images present on each node: what CRI-O or containerd holds (what Kubernetes can start without
pulling), plus Docker's images where Docker is installed (Kubernetes does not use those).

Also removes images: one at a time, or a clean-up of dangling (untagged) and unused images.
"In use" is decided cluster-wide: every pod (including static system pods) and every workload
template (Deployment, StatefulSet, DaemonSet, Job, CronJob), also those scaled to zero. In an
air-gapped cluster a wrongly removed image cannot simply be pulled again.
"""
from __future__ import annotations

import asyncio
from typing import Literal

import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import common as c

router = APIRouter(dependencies=[Depends(c.require_auth)])


async def _agents() -> list[tuple[str, str, str | None]]:
    """[(node, pod ip, runtime hint)] for every ready agent."""
    pods = await c.k8s(c.core_api.list_namespaced_pod, c.AGENT_NAMESPACE, label_selector=c.AGENT_SELECTOR)
    hints = await c.node_runtime_hints()
    return [(p.spec.node_name, p.status.pod_ip, hints.get(p.spec.node_name)) for p in pods.items
            if p.status.pod_ip and any(x.type == "Ready" and x.status == "True" for x in (p.status.conditions or []))]


def _ref(image: str) -> str:
    return image if "@" in (image or "") else c.fully_qualified(image or "")


async def _usage(scoped: bool) -> tuple[dict[str, list[str]], set[str]]:
    """({image name: [who uses it]}, {image IDs / digests of running containers}).

    scoped=True limits the owners to namespaces the user may see (for display);
    scoped=False covers the whole cluster (for deciding what is safe to remove)."""
    calls = [c.k8s(c.core_api.list_pod_for_all_namespaces),
             c.k8s(c.apps_api.list_deployment_for_all_namespaces),
             c.k8s(c.apps_api.list_stateful_set_for_all_namespaces),
             c.k8s(c.apps_api.list_daemon_set_for_all_namespaces),
             c.k8s(c.batch_api.list_cron_job_for_all_namespaces),
             c.k8s(c.batch_api.list_job_for_all_namespaces)]
    pods, deps, sts, dss, cjs, jobs = await asyncio.gather(*calls, return_exceptions=True)
    names: dict[str, list[str]] = {}
    ids: set[str] = set()

    def add(ref: str, owner: str, ns: str):
        if scoped and not c.visible(ns):
            owner = None
        lst = names.setdefault(_ref(ref), [])
        if owner and owner not in lst:
            lst.append(owner)

    for kind, res, spec_of in (("Deployment", deps, lambda o: o.spec.template.spec),
                               ("StatefulSet", sts, lambda o: o.spec.template.spec),
                               ("DaemonSet", dss, lambda o: o.spec.template.spec),
                               ("CronJob", cjs, lambda o: o.spec.job_template.spec.template.spec),
                               ("Job", jobs, lambda o: o.spec.template.spec)):
        if isinstance(res, Exception):
            if not scoped:           # never decide "unused" on incomplete information
                raise HTTPException(503, f"Cannot check which images are in use ({kind}s: {res}). Nothing was removed.")
            continue
        for o in res.items:
            ns = o.metadata.namespace
            label = f"{ns}/{o.metadata.name}" if kind == "Deployment" else f"{ns}/{o.metadata.name} ({kind})"
            for ct in (spec_of(o).init_containers or []) + (spec_of(o).containers or []):
                add(ct.image, label, ns)
    if isinstance(pods, Exception):
        if not scoped:
            raise HTTPException(503, f"Cannot check which images are in use (pods: {pods}). Nothing was removed.")
    else:
        for p in pods.items:
            ns, owned = p.metadata.namespace, bool(p.metadata.owner_references)
            for ct in (p.spec.init_containers or []) + (p.spec.containers or []):
                add(ct.image, None if owned else f"{ns}/{p.metadata.name} (Pod)", ns)   # static/bare pods named
            for cs in (p.status.container_statuses or []) + (p.status.init_container_statuses or []):
                for x in (cs.image_id, cs.image):
                    if x:
                        ids.add(x.removeprefix("docker-pullable://"))
    return names, ids


def _in_use(img: dict, names: dict, ids: set) -> list[str] | None:
    """Owners if the image is in use (possibly empty list for 'used by an owned pod'), else None."""
    for t in img.get("tags") or []:
        if _ref(t) in names:
            return names[_ref(t)]
    fid = img.get("full_id") or ""
    if fid and (fid in ids or fid.removeprefix("sha256:") in ids or f"sha256:{fid.removeprefix('sha256:')}" in ids):
        return []
    if any(d in ids for d in img.get("digests") or []):
        return []
    return None


async def _collect() -> list[tuple[str, str, str | None, dict | None, str | None]]:
    """[(node, ip, hint, data, error)] from every ready agent."""
    agents = await _agents()
    if not agents:
        raise HTTPException(409, "No node agents are ready.")

    async def one(http, node, ip, hint):
        try:
            r = await http.get(f"http://{ip}:{c.AGENT_PORT}/images", params={"runtime": hint or ""},
                               headers={"x-agent-token": c.AGENT_TOKEN})
            data = r.json()
            return (node, ip, hint, data, None) if r.status_code == 200 else (node, ip, hint, None, data.get("detail", r.text))
        except Exception as exc:  # noqa: BLE001
            return node, ip, hint, None, str(exc)

    async with httpx.AsyncClient(timeout=60) as http:
        return await asyncio.gather(*[one(http, n, ip, h) for n, ip, h in agents])


@router.get("/api/node-images")
async def node_images():
    results = await _collect()
    names, ids = await _usage(scoped=True)
    merged: dict[tuple[str, str], dict] = {}          # (source, image or id) -> row
    nodes, errors = [], []
    for node, _ip, _h, data, err in results:
        if err:
            errors.append({"node": node, "error": err}); continue
        if data.get("error"):
            errors.append({"node": node, "error": data["error"]})     # partial: still show what was readable
        nodes.append({"node": node, "runtime": data["runtime"], "docker": data.get("docker") is not None})
        for source, imgs in ((data["runtime"], data["images"]), ("docker", data.get("docker") or [])):
            for img in imgs:
                used = None if source == "docker" else _in_use(img, names, ids)
                for ref in img["tags"] or [None]:
                    key = (source, ref or "id:" + img["id"])
                    row = merged.setdefault(key, {"image": ref, "id": img["id"], "full_id": img.get("full_id") or img["id"],
                                                  "size": img["size"], "source": source, "digests": img.get("digests") or [],
                                                  "nodes": [], "pinned": img.get("pinned", False),
                                                  "used_by": used or [], "in_use": used is not None})
                    if node not in row["nodes"]:
                        row["nodes"].append(node)
    rows = sorted(merged.values(), key=lambda r: (r["source"] == "docker", r["image"] is None, r["image"] or r["id"]))
    return {"nodes": sorted(nodes, key=lambda n: n["node"]), "errors": errors, "images": rows}


# --------------------------------------------------------------------------- removal
class RemoveIn(BaseModel):
    node: str
    image: str                       # name, or full ID for untagged images
    source: Literal["runtime", "docker"] = "runtime"
    force: bool = False


def _require_cleanup_rights():
    c.require("cluster")
    if c.READ_ONLY:
        raise HTTPException(403, "The dashboard is in read-only mode (READ_ONLY=true).")


async def _remove_on(http, node: str, ip: str, hint: str | None, image: str, source: str) -> tuple[bool, str]:
    r = await http.post(f"http://{ip}:{c.AGENT_PORT}/images/remove", json={"image": image, "runtime": hint, "source": source},
                        headers={"x-agent-token": c.AGENT_TOKEN})
    if r.status_code == 200:
        return True, "removed"
    try:
        return False, r.json().get("detail", r.text)
    except ValueError:
        return False, r.text


@router.post("/api/node-images/remove")
async def remove(body: RemoveIn):
    _require_cleanup_rights()
    if body.source == "runtime":
        names, _ids = await _usage(scoped=False)
        users = names.get(_ref(body.image))
        if users is not None and not body.force:
            who = ", ".join(users) or "running pods"
            raise HTTPException(409, f"{body.image} is used by {who}. If those pods restart on {body.node}, "
                                     f"they would need to pull it again.")
    agent = next(((ip, h) for n, ip, h in await _agents() if n == body.node), None)
    if not agent:
        raise HTTPException(409, f"No ready node agent on {body.node}.")
    async with httpx.AsyncClient(timeout=150) as http:
        ok, msg = await _remove_on(http, body.node, agent[0], agent[1], body.image, body.source)
    if not ok:
        raise HTTPException(409, msg)
    c.audit("image-remove", f"node/{body.node}", f"{body.image}{' (Docker)' if body.source == 'docker' else ''}")
    return {"ok": True}


class CleanupIn(BaseModel):
    mode: Literal["dangling", "unused"] = "dangling"   # dangling = untagged; unused = + tagged images nothing uses
    docker: bool = False                               # also prune Docker's dangling images
    nodes: list[str] = []                              # empty = every node
    dry_run: bool = True


@router.post("/api/node-images/cleanup")
async def cleanup(body: CleanupIn):
    """Preview (dry_run) or remove dangling / unused images on the nodes."""
    _require_cleanup_rights()
    results = await _collect()
    names, ids = await _usage(scoped=False)            # whole cluster, or refuse
    plan, errors = [], []
    for node, ip, hint, data, err in results:
        if body.nodes and node not in body.nodes:
            continue
        if err or (data and data.get("error")):
            errors.append({"node": node, "error": err or data["error"]}); continue
        for img in data["images"]:
            if img.get("pinned") or _in_use(img, names, ids) is not None:
                continue
            if not img["tags"]:
                reason = "dangling (untagged)"
            elif body.mode == "unused":
                reason = "not used by any pod or workload"
            else:
                continue
            plan.append({"node": node, "ip": ip, "hint": hint, "source": data["runtime"], "reason": reason,
                         "image": img["tags"][0] if img["tags"] else None, "id": img["id"],
                         "ref": img["tags"][0] if img["tags"] else (img.get("full_id") or img["id"]), "size": img["size"] or 0})
        if body.docker and data.get("docker") is not None:
            for img in data["docker"]:
                if not img["tags"]:
                    plan.append({"node": node, "ip": ip, "hint": hint, "source": "docker", "reason": "dangling (untagged)",
                                 "image": None, "id": img["id"], "ref": img.get("full_id") or img["id"], "size": img["size"] or 0})
    public = lambda p: {k: p[k] for k in ("node", "source", "reason", "image", "id", "size")}
    if body.dry_run:
        return {"dry_run": True, "candidates": [public(p) for p in plan], "total_bytes": sum(p["size"] for p in plan),
                "errors": errors}

    done, reclaimed = [], 0
    async with httpx.AsyncClient(timeout=300) as http:
        for p in [x for x in plan if x["source"] != "docker"]:
            ok, msg = await _remove_on(http, p["node"], p["ip"], p["hint"], p["ref"], "runtime")
            done.append({**public(p), "ok": ok, "message": msg})
            reclaimed += p["size"] if ok else 0
        for node in sorted({p["node"] for p in plan if p["source"] == "docker"}):
            ip = next(p["ip"] for p in plan if p["node"] == node)
            r = await http.post(f"http://{ip}:{c.AGENT_PORT}/images/docker-prune", headers={"x-agent-token": c.AGENT_TOKEN})
            ok = r.status_code == 200
            d = r.json() if ok else {}
            for p in [x for x in plan if x["source"] == "docker" and x["node"] == node]:
                done.append({**public(p), "ok": ok, "message": "removed by docker image prune" if ok else r.text[:200]})
            reclaimed += d.get("space_reclaimed", 0) if ok else 0
    removed = sum(1 for d in done if d["ok"])
    c.audit("image-cleanup", "nodes/" + (",".join(body.nodes) or "all"),
            f"{body.mode}{' + Docker' if body.docker else ''}: removed {removed} of {len(done)}, {reclaimed} bytes")
    return {"dry_run": False, "results": done, "removed": removed, "failed": len(done) - removed,
            "reclaimed_bytes": reclaimed, "errors": errors}
