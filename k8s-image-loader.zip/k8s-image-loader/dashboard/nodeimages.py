"""Images present on each node: what CRI-O or containerd holds (what Kubernetes can start without
pulling), plus Docker's images where Docker is installed (Kubernetes does not use those)."""
from __future__ import annotations

import asyncio

import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import common as c

router = APIRouter(dependencies=[Depends(c.require_auth)])


async def _agents() -> list[tuple[str, str, str | None]]:
    """[(node, pod ip, runtime hint)] for every ready agent."""
    pods = await c.k8s(c.core_api.list_namespaced_pod, c.AGENT_NAMESPACE, label_selector=c.AGENT_SELECTOR)
    hints = await c.node_runtime_hints()
    return [(p.spec.node_name, p.status.pod_ip, hints.get(p.spec.node_name)) for p in pods.items
            if p.status.pod_ip and any(x.type == "Ready" and x.status == "True" for x in (p.status.conditions or []))]


async def _usage() -> dict[str, list[str]]:
    """{fully qualified image: ["ns/deployment", ...]} limited to what this user may see."""
    res = await c.k8s(c.apps_api.list_deployment_for_all_namespaces)
    out: dict[str, list[str]] = {}
    for d in res.items:
        if not c.visible(d.metadata.namespace):
            continue
        for ct in (d.spec.template.spec.init_containers or []) + d.spec.template.spec.containers:
            ref = ct.image if "@" in (ct.image or "") else c.fully_qualified(ct.image or "")
            out.setdefault(ref, [])
            name = f"{d.metadata.namespace}/{d.metadata.name}"
            if name not in out[ref]:
                out[ref].append(name)
    return out


@router.get("/api/node-images")
async def node_images():
    agents = await _agents()
    if not agents:
        raise HTTPException(409, "No node agents are ready.")

    async def one(http, node, ip, hint):
        try:
            r = await http.get(f"http://{ip}:{c.AGENT_PORT}/images", params={"runtime": hint or ""},
                               headers={"x-agent-token": c.AGENT_TOKEN})
            data = r.json()
            return (node, data, None) if r.status_code == 200 else (node, None, data.get("detail", r.text))
        except Exception as exc:  # noqa: BLE001
            return node, None, str(exc)

    async with httpx.AsyncClient(timeout=60) as http:
        results = await asyncio.gather(*[one(http, n, ip, h) for n, ip, h in agents])
    usage = await _usage()

    merged: dict[tuple[str, str], dict] = {}          # (source, image or id) -> row
    nodes, errors = [], []
    for node, data, err in results:
        if err:
            errors.append({"node": node, "error": err}); continue
        if data.get("error"):
            errors.append({"node": node, "error": data["error"]})     # partial: still show what was readable
        nodes.append({"node": node, "runtime": data["runtime"], "docker": data.get("docker") is not None})
        for source, imgs in ((data["runtime"], data["images"]), ("docker", data.get("docker") or [])):
            for img in imgs:
                refs = img["tags"] or [None]
                for ref in refs:
                    key = (source, ref or "id:" + img["id"])
                    row = merged.setdefault(key, {"image": ref, "id": img["id"], "size": img["size"], "source": source,
                                                  "digests": img.get("digests") or [], "nodes": [], "pinned": img.get("pinned", False),
                                                  "used_by": [] if source == "docker" or not ref else usage.get(ref, [])})
                    if node not in row["nodes"]:
                        row["nodes"].append(node)
    rows = sorted(merged.values(), key=lambda r: (r["source"] == "docker", r["image"] is None, r["image"] or r["id"]))
    return {"nodes": sorted(nodes, key=lambda n: n["node"]), "errors": errors, "images": rows}


class RemoveIn(BaseModel):
    node: str
    image: str
    force: bool = False


@router.post("/api/node-images/remove")
async def remove(body: RemoveIn):
    c.require("cluster")
    if c.READ_ONLY:
        raise HTTPException(403, "The dashboard is in read-only mode (READ_ONLY=true).")
    users = (await _usage()).get(body.image, [])
    if users and not body.force:
        raise HTTPException(409, f"{body.image} is used by {', '.join(users)}. If those pods restart on "
                                 f"{body.node}, they would need to pull it again.")
    agent = next(((ip, h) for n, ip, h in await _agents() if n == body.node), None)
    if not agent:
        raise HTTPException(409, f"No ready node agent on {body.node}.")
    async with httpx.AsyncClient(timeout=150) as http:
        r = await http.post(f"http://{agent[0]}:{c.AGENT_PORT}/images/remove", json={"image": body.image, "runtime": agent[1]},
                            headers={"x-agent-token": c.AGENT_TOKEN})
    if r.status_code != 200:
        raise HTTPException(r.status_code if r.status_code < 500 else 502, r.json().get("detail", r.text))
    c.audit("image-remove", f"node/{body.node}", body.image)
    return {"ok": True}
