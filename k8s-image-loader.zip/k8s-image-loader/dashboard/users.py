"""Dashboard users: a role and a namespace scope per person, each with their own token.

Users live in the Secret `dashboard-users` in the dashboard's namespace. Only a SHA-256
hash of each token is stored; the token itself is shown once, when it is created.
The DASHBOARD_TOKEN from the `dashboard-auth` secret is the built-in admin and always works.
"""
from __future__ import annotations

import asyncio
import base64
import datetime as dt
import hashlib
import hmac
import json
import secrets
import time

from fastapi import APIRouter, Depends, HTTPException
from kubernetes.client.rest import ApiException
from pydantic import BaseModel

import common as c

SECRET_NAME = "dashboard-users"
NAMESPACE = c.AGENT_NAMESPACE                # the dashboard's own namespace
TOKEN_PREFIX = "ilu_"
CACHE_SECONDS = 15

router = APIRouter(dependencies=[Depends(c.require_auth)])
_cache: dict = {"at": 0.0, "users": [], "rv": None}
_lock = asyncio.Lock()
LAST_SEEN: dict[str, str] = {}               # name -> ISO time of last request (in memory)


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


async def _load(force: bool = False) -> list[dict]:
    if not force and time.monotonic() - _cache["at"] < CACHE_SECONDS:
        return _cache["users"]
    try:
        s = await c.k8s(c.core_api.read_namespaced_secret, SECRET_NAME, NAMESPACE)
        raw = base64.b64decode((s.data or {}).get("users.json", "") or b"W10=").decode() or "[]"
        users, rv = json.loads(raw), s.metadata.resource_version
    except ApiException as exc:
        if exc.status != 404:
            raise
        users, rv = [], None
    _cache.update(at=time.monotonic(), users=users, rv=rv)
    return users


async def _save(users: list[dict]) -> None:
    body = {"metadata": {"name": SECRET_NAME, "namespace": NAMESPACE,
                         "labels": {"app.kubernetes.io/name": "k8s-image-loader", "app.kubernetes.io/component": "users"}},
            "type": "Opaque",
            "data": {"users.json": base64.b64encode(json.dumps(users, indent=1).encode()).decode()}}
    if _cache["rv"] is None:
        try:
            await c.k8s(c.core_api.create_namespaced_secret, NAMESPACE, body)
        except ApiException as exc:
            if exc.status != 409:
                raise
            raise HTTPException(409, "Users were changed at the same time. Reload and try again.")
    else:
        body["metadata"]["resourceVersion"] = _cache["rv"]      # optimistic lock
        try:
            await c.k8s(c.core_api.replace_namespaced_secret, SECRET_NAME, NAMESPACE, body)
        except ApiException as exc:
            if exc.status == 409:
                raise HTTPException(409, "Users were changed at the same time. Reload and try again.")
            raise
    await _load(force=True)


def _to_user(u: dict) -> c.User:
    return c.User(u["name"], u["role"], u.get("namespaces") or ["*"])


async def authenticate(token: str) -> c.User | None:
    if not token.startswith(TOKEN_PREFIX):
        return None
    h = _hash(token)
    for u in await _load():
        if not u.get("disabled") and hmac.compare_digest(u.get("token_sha256", ""), h):
            LAST_SEEN[u["name"]] = c.now_iso()
            return _to_user(u)
    return None


# --------------------------------------------------------------------------- API
class UserIn(BaseModel):
    name: str
    role: str
    namespaces: list[str] = ["*"]           # ["*"] = all namespaces (cluster)


class UserUpdate(BaseModel):
    role: str | None = None
    namespaces: list[str] | None = None
    disabled: bool | None = None


def _check(role: str | None, namespaces: list[str] | None) -> None:
    if role is not None and role not in c.ROLES:
        raise HTTPException(400, f"Role must be one of: {', '.join(c.ROLES)}")
    if namespaces is not None:
        if not namespaces:
            raise HTTPException(400, "Choose at least one namespace, or all namespaces.")
        for ns in namespaces:
            if ns != "*" and not c.DNS_LABEL.match(ns):
                raise HTTPException(400, f"'{ns}' is not a valid namespace name.")


def _public(u: dict) -> dict:
    x = _to_user(u).public()
    x.update(disabled=bool(u.get("disabled")), created=u.get("created"), created_by=u.get("created_by"),
             last_seen=LAST_SEEN.get(u["name"]))
    return x


@router.get("/api/me")
async def me():
    return c.user().public()


@router.get("/api/users")
async def list_users():
    c.require("users")
    users = await _load(force=True)
    return {"roles": {r: sorted(caps) for r, caps in c.ROLES.items()},
            "users": [c.ADMIN.public() | {"disabled": False, "created": None, "created_by": None, "last_seen": None}]
                     + [_public(u) for u in sorted(users, key=lambda u: u["name"])]}


@router.post("/api/users")
async def create_user(body: UserIn):
    c.require("users")
    name = c.check_name(body.name.strip().lower(), "User name", label=True)
    _check(body.role, body.namespaces)
    if name == c.ADMIN.name:
        raise HTTPException(409, "'admin' is the built-in administrator.")
    async with _lock:
        users = await _load(force=True)
        if any(u["name"] == name for u in users):
            raise HTTPException(409, f"User {name} already exists.")
        token = TOKEN_PREFIX + secrets.token_hex(24)
        users.append({"name": name, "role": body.role, "namespaces": body.namespaces, "token_sha256": _hash(token),
                      "created": c.now_iso(), "created_by": c.user().name, "disabled": False})
        await _save(users)
    c.audit("user-create", f"user/{name}", f"role {body.role}, namespaces {', '.join(body.namespaces)}")
    return {"user": _public(users[-1]), "token": token}


@router.put("/api/users/{name}")
async def update_user(name: str, body: UserUpdate):
    c.require("users")
    _check(body.role, body.namespaces)
    async with _lock:
        users = await _load(force=True)
        u = next((x for x in users if x["name"] == name), None)
        if not u:
            raise HTTPException(404, f"User {name} not found.")
        changes = []
        if body.role is not None and body.role != u["role"]:
            changes.append(f"role {u['role']} -> {body.role}"); u["role"] = body.role
        if body.namespaces is not None and body.namespaces != u.get("namespaces"):
            changes.append(f"namespaces -> {', '.join(body.namespaces)}"); u["namespaces"] = body.namespaces
        if body.disabled is not None and body.disabled != bool(u.get("disabled")):
            changes.append("disabled" if body.disabled else "enabled"); u["disabled"] = body.disabled
        if changes:
            await _save(users)
    if changes:
        c.audit("user-update", f"user/{name}", "; ".join(changes))
    return {"user": _public(u)}


@router.post("/api/users/{name}/token")
async def reset_token(name: str):
    c.require("users")
    async with _lock:
        users = await _load(force=True)
        u = next((x for x in users if x["name"] == name), None)
        if not u:
            raise HTTPException(404, f"User {name} not found.")
        token = TOKEN_PREFIX + secrets.token_hex(24)
        u["token_sha256"] = _hash(token)
        await _save(users)
    c.audit("user-token", f"user/{name}", "new token issued; the old one stopped working")
    return {"token": token}


@router.delete("/api/users/{name}")
async def delete_user(name: str):
    c.require("users")
    async with _lock:
        users = await _load(force=True)
        if not any(u["name"] == name for u in users):
            raise HTTPException(404, f"User {name} not found.")
        await _save([u for u in users if u["name"] != name])
    LAST_SEEN.pop(name, None)
    c.audit("user-delete", f"user/{name}")
    return {"ok": True}
