(() => {
  "use strict";

  // ================================================================== basics
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const S = {
    token: sessionStorage.getItem("il-token") || "",
    cfg: {}, tab: "workloads", namespaces: [],
    deployments: [], configmaps: [], secrets: [], pvcs: [], pvs: [], classes: [],
    nodes: null, nodesAt: 0,
  };
  let refreshTimer = null;

  async function api(path, opts = {}) {
    const headers = Object.assign({}, opts.headers || {});
    if (S.token) headers.Authorization = "Bearer " + S.token;
    if (opts.json !== undefined) { headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(opts.json); }
    const res = await fetch(path, Object.assign({}, opts, { headers }));
    if (res.status === 401) { showLogin(); throw new Error("Sign in required"); }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const d = data.detail;
      throw new Error(Array.isArray(d) ? d.map((e) => `${e.loc?.slice(-1)[0]}: ${e.msg}`).join("; ") : (d || res.statusText));
    }
    return data;
  }
  const qs = (o) => new URLSearchParams(o).toString();

  function toast(msg, kind = "") {
    [...$("toasts").children].forEach((t) => { if (t.textContent === msg) t.remove(); });
    const el = document.createElement("div");
    el.className = "toast " + kind; el.textContent = msg;
    $("toasts").appendChild(el);
    setTimeout(() => el.remove(), kind === "error" ? 8000 : 5000);
  }
  function age(sec) {
    if (sec == null) return "";
    if (sec < 3600) return Math.max(1, Math.floor(sec / 60)) + "m";
    if (sec < 86400) return Math.floor(sec / 3600) + "h";
    return Math.floor(sec / 86400) + "d";
  }
  const timeOf = (iso) => iso ? new Date(iso).toLocaleTimeString() : "";
  const nsName = (x) => `<div class="dname">${esc(x.name)}</div><div class="dns">${esc(x.namespace)}</div>`;
  const usedBy = (list) => list && list.length ? `<span class="used">${list.map(esc).join(", ")}</span>` : '<span class="muted">Not used</span>';
  const matches = (x, ...fields) => {
    const q = $("search").value.trim().toLowerCase();
    return !q || fields.some((f) => String(f ?? "").toLowerCase().includes(q));
  };
  const currentNs = () => $("nsSelect").value;
  // Role-aware: what the signed-in user may change (the server enforces the same rules)
  const can = (cap, ns) => !S.cfg.read_only && ((S.me && S.me.caps) || []).includes(cap)
    && !(ns && (S.cfg.protected_namespaces || []).includes(ns));
  const canWrite = (ns, cap = "deploy") => can(cap, ns);
  const ABBR = { ReadWriteOnce: "RWO", ReadOnlyMany: "ROX", ReadWriteMany: "RWX", ReadWriteOncePod: "RWOP" };

  async function busy(btn, label, fn) {
    const old = btn.textContent; btn.disabled = true; btn.textContent = label;
    try { return await fn(); } finally { btn.disabled = false; btn.textContent = old; }
  }
  function typedConfirm(name, message) {
    const v = prompt(`${message}\n\nType ${name} to confirm.`);
    return v !== null && v.trim() === name;
  }

  async function getNodes(force = false) {
    if (!force && S.nodes && Date.now() - S.nodesAt < 30000) return S.nodes;
    S.nodes = (await api("/api/agents")).nodes; S.nodesAt = Date.now();
    return S.nodes;
  }
  const nsOptions = (sel, cap = "deploy") => S.namespaces.filter((n) => can(cap, n)).map((n) => `<option ${n === sel ? "selected" : ""}>${esc(n)}</option>`).join("");

  // ================================================================== auth
  function showLogin() {
    $("app").hidden = true; $("tabs").hidden = true; $("login").hidden = false; $("signOut").hidden = true;
    stopRefresh(); $("tokenInput").focus();
  }
  $("tokenBtn").onclick = () => { S.token = $("tokenInput").value.trim(); sessionStorage.setItem("il-token", S.token); start(); };
  $("tokenInput").addEventListener("keydown", (e) => { if (e.key === "Enter") $("tokenBtn").click(); });
  $("signOut").onclick = () => { S.token = ""; sessionStorage.removeItem("il-token"); showLogin(); };

  // ================================================================== routing
  const VIEWS = ["workloads", "images", "apply", "configmaps", "secrets", "storage", "nodes", "users"];
  function route() {
    const tab = (location.hash || "#workloads").slice(1);
    S.tab = VIEWS.includes(tab) ? tab : "workloads";
    VIEWS.forEach((v) => { $("v-" + v).hidden = v !== S.tab; });
    document.querySelectorAll("#tabs a").forEach((a) => a.setAttribute("aria-current", a.getAttribute("href") === "#" + S.tab ? "page" : "false"));
    $("systemToggle").hidden = !["configmaps", "secrets"].includes(S.tab);
    $("nsSelect").disabled = ["nodes", "images", "apply", "users"].includes(S.tab);
    $("search").value = "";
    refreshView();
  }
  window.addEventListener("hashchange", route);

  function refreshView() {
    const loaders = {
      workloads: loadDeployments, images: loadImages, apply: loadApply, configmaps: loadConfigMaps, secrets: loadSecrets,
      storage: loadStorage, nodes: () => { loadNodes(); loadJobs(); loadAudit(); }, users: loadUsers,
    };
    loaders[S.tab]();
  }
  function rerender() {
    ({ workloads: renderDeployments, images: () => (S.imgPane === "nodes" ? renderNodeImages() : renderImages()), apply: () => {}, configmaps: renderConfigMaps, secrets: renderSecrets,
       storage: renderStorage, nodes: () => {}, users: renderUsers })[S.tab]();
  }

  // ================================================================== generic editor sheet
  const Ed = {
    open(title, sub, bodyHtml, buttons = []) {
      $("edTitle").textContent = title; $("edSub").textContent = sub || "";
      $("edBody").innerHTML = bodyHtml;
      const foot = $("edFoot"); foot.innerHTML = "";
      const left = buttons.filter((b) => b.left), right = buttons.filter((b) => !b.left);
      const mk = (b) => {
        const el = document.createElement("button");
        el.className = "btn " + (b.cls || ""); el.textContent = b.label; if (b.id) el.id = b.id;
        el.onclick = () => b.onClick(el); return el;
      };
      left.forEach((b) => foot.appendChild(mk(b)));
      const sp = document.createElement("div"); sp.className = "spacer"; foot.appendChild(sp);
      foot.appendChild(mk({ label: right.length ? "Cancel" : "Close", onClick: Ed.close }));
      right.forEach((b) => foot.appendChild(mk(b)));
      $("edScrim").classList.add("open"); $("editor").classList.add("open");
      return $("edBody");
    },
    close() { $("edScrim").classList.remove("open"); $("editor").classList.remove("open"); Ed.onClose && Ed.onClose(); Ed.onClose = null; },
    isOpen: () => $("editor").classList.contains("open"),
  };
  $("edClose").onclick = Ed.close; $("edScrim").onclick = Ed.close;

  // ================================================================== workloads
  async function loadNamespaces() {
    S.namespaces = await api("/api/namespaces");
    const sel = $("nsSelect"), keep = sel.value;
    sel.innerHTML = '<option value="">All namespaces</option>' + S.namespaces.map((n) => `<option>${esc(n)}</option>`).join("");
    sel.value = keep;
  }

  async function loadDeployments() {
    try {
      S.deployments = await api("/api/deployments?" + qs({ namespace: currentNs() }));
      $("clusterDot").className = "dot ok"; $("clusterText").textContent = "Connected to cluster";
      renderDeployments();
    } catch (e) {
      $("clusterDot").className = "dot fail"; $("clusterText").textContent = "Cluster unreachable";
      if (e.message !== "Sign in required") toast("Could not load deployments: " + e.message, "error");
    }
  }

  const STATUS_LABEL = { healthy: "Healthy", progressing: "Rolling out", degraded: "Degraded", failed: "Failed", "scaled-down": "Scaled to 0" };
  function renderDeployments() {
    const all = S.deployments;
    const items = all.filter((d) => matches(d, d.name, d.namespace, ...d.containers.map((c) => c.image)));
    const count = (s) => all.filter((d) => d.status === s).length;
    const parts = [`<b>${all.length}</b> deployments`, `<b>${count("healthy")}</b> healthy`];
    if (count("progressing")) parts.push(`<b>${count("progressing")}</b> rolling out`);
    if (count("degraded") + count("failed")) parts.push(`<b>${count("degraded") + count("failed")}</b> need attention`);
    if (count("scaled-down")) parts.push(`<b>${count("scaled-down")}</b> scaled to zero`);
    $("summary").innerHTML = parts.join(", ");

    if (!items.length) {
      $("rows").innerHTML = `<tr><td colspan="6" class="empty">${all.length ? "No deployments match this filter." : "No deployments in this namespace."}</td></tr>`;
      return;
    }
    $("rows").innerHTML = items.map((d, i) => {
      const pct = d.replicas ? Math.round((d.ready / d.replicas) * 100) : 0;
      const imgs = d.containers.map((c) => `<span class="img mono" title="${esc(c.image)}"><span class="cname">${esc(c.name)}:</span> ${esc(c.image)}<span class="policy">${esc(c.pull_policy || "")}</span></span>`).join("");
      const loaded = d.last_loaded.at ? `<div class="loaded">Loaded from tar ${esc(new Date(d.last_loaded.at).toLocaleString())}</div>` : "";
      const w = !d.protected && can("deploy", d.namespace);
      return `<tr>
        <td><div class="dname">${esc(d.name)}</div><div class="dns">${esc(d.namespace)}${d.revision ? ", revision " + esc(d.revision) : ""}</div></td>
        <td><span class="pill s-${d.status}">${STATUS_LABEL[d.status] || d.status}</span></td>
        <td class="reps">${d.ready} / ${d.replicas}<div class="bar"><i style="width:${pct}%"></i></div></td>
        <td>${imgs}${loaded}</td>
        <td>${age(d.age_seconds)}</td>
        <td><div class="actions">
          <button class="btn small" data-yaml="${i}">YAML</button>
          <button class="btn small" data-manage="${i}">Manage</button>
          ${w ? `<button class="btn small primary" data-update="${i}">Update image</button>` : ""}
        </div></td></tr>`;
    }).join("");
    $("rows").querySelectorAll("[data-update]").forEach((b) => b.onclick = () => openImageForm(items[+b.dataset.update]));
    $("rows").querySelectorAll("[data-manage]").forEach((b) => b.onclick = () => openManage(items[+b.dataset.manage].namespace, items[+b.dataset.manage].name));
    $("rows").querySelectorAll("[data-yaml]").forEach((b) => b.onclick = () => openYamlFor("Deployment", items[+b.dataset.yaml].namespace, items[+b.dataset.yaml].name));
  }

  // ================================================================== manage deployment
  const VOL_LABEL = { persistentVolumeClaim: "Claim", hostPath: "Node disk", emptyDir: "Temporary", configMap: "Config map", secret: "Secret", projected: "Projected", nfs: "NFS", csi: "CSI" };

  // ---------------------------------------------------------------- autoscaling (HPA) in Manage
  function autoscalingSection(d, wD) {
    const h = d.hpa, a = d.autoscaling || {}, noReq = a.containers_without_cpu_request || [];
    const pct = (v) => v == null ? "–" : v + "%";
    const status = h ? `
      <div class="hpa-now">
        <span><b>${h.current_replicas ?? "–"}</b>pods now</span>
        <span><b>${h.min}–${h.max}</b>allowed</span>
        ${h.cpu ? `<span><b>${pct(h.current_cpu)}</b>CPU (target ${h.cpu}%)</span>` : ""}
        ${h.memory ? `<span><b>${pct(h.current_memory)}</b>memory (target ${h.memory}%)</span>` : ""}
      </div>
      ${h.problem ? `<div class="notice">Not scaling: ${esc(h.problem.reason || "")}. ${esc(h.problem.message || "")}</div>` : ""}` : "";
    const warnMetrics = a.metrics_available === false ? `<div class="notice">metrics-server is not installed, so the autoscaler cannot measure CPU or memory and will not scale. Install it once for the cluster (<span class="mono">kubectl apply -f components.yaml</span> from the metrics-server release; in an air-gapped cluster load its image first).</div>` : "";
    const form = wD ? `
      <div class="hpa-grid">
        <label class="lbl">Minimum pods <input class="field" type="number" id="hMin" min="1" max="500" value="${h ? h.min : Math.max(1, d.replicas)}"></label>
        <label class="lbl">Maximum pods <input class="field" type="number" id="hMax" min="1" max="500" value="${h ? h.max : Math.max(3, d.replicas * 3)}"></label>
        <span></span>
        <label class="lbl"><span><input type="checkbox" id="hCpuOn" ${!h || h.cpu ? "checked" : ""}> CPU target</span>
          <input class="field" type="number" id="hCpu" min="1" max="1000" value="${h && h.cpu ? h.cpu : 70}"><span class="hint">% of each pod's CPU request</span></label>
        <label class="lbl"><span><input type="checkbox" id="hMemOn" ${h && h.memory ? "checked" : ""}> Memory target</span>
          <input class="field" type="number" id="hMem" min="1" max="1000" value="${h && h.memory ? h.memory : 80}"><span class="hint">% of each pod's memory request</span></label>
      </div>
      ${noReq.length ? `<label class="check" id="hReqRow" style="align-items:flex-start"><input type="checkbox" id="hReqOn" checked style="margin-top:4px">
        <span>Set a CPU request of <input class="field" id="hReq" value="100m" style="width:80px;padding:3px 6px"> for ${noReq.map((n) => `<span class="mono">${esc(n)}</span>`).join(", ")}
        <br><span class="muted" style="font-size:13px">${noReq.length === 1 ? "This container has" : "These containers have"} no CPU request. The CPU target is measured against it, so without one the autoscaler cannot scale on CPU.</span></span></label>` : ""}
      <div style="display:flex;gap:10px">
        <button class="btn primary" id="hSave">${h ? "Save autoscaling" : "Turn on autoscaling"}</button>
        ${h ? '<button class="btn danger" id="hOff">Turn off</button>' : ""}
      </div>` : (h ? "" : '<div class="muted">Off. Deployers can turn it on.</div>');
    return `<div class="sec">
      <div class="sec-head"><h3>Autoscaling</h3><span class="pill s-${h ? (h.problem ? "degraded" : "healthy") : "queued"}">${h ? (h.problem ? "On, not scaling" : "On") : "Off"}</span></div>
      <div class="muted" style="font-size:13px;margin-bottom:10px">Adds pods when they are busy and removes them when they are idle, between a minimum and a maximum (Kubernetes HorizontalPodAutoscaler).</div>
      ${warnMetrics}${status}${form}
    </div>`;
  }

  function wireAutoscaling(body, d, ns, name, wD, reload) {
    if (!wD || !$("hSave")) return;
    const sync = () => {
      $("hCpu").disabled = !$("hCpuOn").checked; $("hMem").disabled = !$("hMemOn").checked;
      if ($("hReqRow")) $("hReqRow").hidden = !$("hCpuOn").checked;
    };
    $("hCpuOn").onchange = sync; $("hMemOn").onchange = sync; sync();
    $("hSave").onclick = (e) => busy(e.target, "Saving…", async () => {
      const min = +$("hMin").value, max = +$("hMax").value;
      if (!(min >= 1) || !(max >= min)) return toast("Maximum pods must be at least the minimum (and the minimum at least 1).", "error");
      if (!$("hCpuOn").checked && !$("hMemOn").checked) return toast("Choose a CPU or memory target.", "error");
      const json = { min_replicas: min, max_replicas: max,
        cpu_percent: $("hCpuOn").checked ? +$("hCpu").value : null, memory_percent: $("hMemOn").checked ? +$("hMem").value : null,
        set_cpu_request: $("hReqOn") && $("hReqOn").checked && $("hCpuOn").checked ? $("hReq").value.trim() : null };
      try {
        await api(`/api/deployments/${ns}/${name}/autoscaling`, { method: "PUT", json });
        toast(`Autoscaling ${d.hpa ? "saved" : "on"} for ${name}: ${min}–${max} pods`); reload();
      } catch (err) { toast(err.message, "error"); }
    });
    if ($("hOff")) $("hOff").onclick = (e) => {
      if (!confirm(`Turn off autoscaling for ${name}? It keeps its current ${d.hpa.current_replicas ?? d.replicas} pods; you can scale it by hand again.`)) return;
      busy(e.target, "Turning off…", async () => {
        try { await api(`/api/deployments/${ns}/${name}/autoscaling`, { method: "DELETE" }); toast(`Autoscaling off for ${name}`); reload(); }
        catch (err) { toast(err.message, "error"); }
      });
    };
  }

  function wireDelete(ns, name) {
    let plan = null;
    $("mDel").onclick = (e) => busy(e.target, "Checking…", async () => {
      if (!plan) {
        try { plan = await api(`/api/deployments/${ns}/${name}/delete-preview`); } catch (err) { return toast(err.message, "error"); }
        const own = plan.services.filter((x) => !x.shared_with.length), shared = plan.services.filter((x) => x.shared_with.length);
        $("mDelInfo").innerHTML = `<ul class="list" style="margin-bottom:10px">
          <li>Removes <strong>${plan.replicas}</strong> pod(s)${plan.hpa ? `, and its autoscaler <span class="mono">${esc(plan.hpa)}</span>` : ""}.</li>
          ${own.length ? `<li><label class="check"><input type="checkbox" id="mDelSvc" checked> Also delete its Service${own.length > 1 ? "s" : ""}: ${own.map((x) => `<span class="mono">${esc(x.name)}</span>`).join(", ")}</label></li>` : ""}
          ${shared.map((x) => `<li>Keeps Service <span class="mono">${esc(x.name)}</span>: ${esc(x.shared_with.join(", "))} still use${x.shared_with.length > 1 ? "" : "s"} it.</li>`).join("")}
          ${plan.claims.length ? `<li>Keeps storage claim${plan.claims.length > 1 ? "s" : ""} ${plan.claims.map((x) => `<span class="mono">${esc(x)}</span>`).join(", ")} and the data in them.</li>` : ""}
        </ul>`;
        e.target.textContent = "Delete permanently";
        return;
      }
      if (!typedConfirm(name, `Delete deployment ${ns}/${name}? Its pods stop now. This cannot be undone from the dashboard.`)) return;
      try {
        const r = await api(`/api/deployments/${ns}/${name}?` + qs({ delete_services: $("mDelSvc") && $("mDelSvc").checked ? "true" : "false" }), { method: "DELETE" });
        toast(`Deleted: ${r.deleted.join(", ")}`); Ed.close(); loadDeployments();
      } catch (err) { toast(err.message, "error"); }
    });
  }

  async function openManage(ns, name) {
    let d;
    try { d = await api(`/api/deployments/${ns}/${name}`); } catch (e) { return toast(e.message, "error"); }
    const wD = !d.protected && can("deploy", ns), wC = !d.protected && can("config", ns);
    const w = wC;                                  // volumes and env below are configuration
    const mountsOf = (vol) => d.containers.flatMap((c) => c.mounts.filter((m) => m.volume === vol).map((m) =>
      `<span class="mono">${esc(d.containers.length > 1 ? c.name + ":" : "")}${esc(m.path)}${m.sub_path ? ` (${esc(m.sub_path)})` : ""}</span>${m.read_only ? ' <span class="muted">read-only</span>' : ""}`)).join("<br>") || '<span class="muted">not mounted</span>';

    const html = `
      ${d.protected ? '<div class="notice">This namespace is protected or the dashboard is read-only. Details are shown, changes are disabled.</div>' : '<div class="notice info">Changes here replace pods one by one using the deployment\'s rollout strategy.</div>'}

      <div class="sec">
        <div class="sec-head"><h3>Replicas</h3><span class="muted">${d.ready} of ${d.replicas} ready</span></div>
        ${wD && !d.hpa ? `<div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
          <div class="stepper"><button data-step="-1" aria-label="Fewer replicas">−</button><input id="mRep" type="number" min="0" max="500" value="${d.replicas}" aria-label="Replicas"><button data-step="1" aria-label="More replicas">+</button></div>
          <button class="btn" id="mScale">Scale</button></div>` : `<div>${d.replicas} replicas</div>`}
        ${d.hpa ? `<div class="notice info">Autoscaling controls the number of pods (${d.hpa.min} to ${d.hpa.max}). Change the limits below instead.</div>` : ""}
        ${wD ? `<div style="margin-top:10px"><button class="btn" id="mRestart">Restart pods</button>
          <span class="muted" style="font-size:13px;margin-left:8px">Replaces the pods one by one, for example to pick up changed config.</span></div>` : ""}
      </div>
      ${autoscalingSection(d, wD)}

      <div class="sec">
        <div class="sec-head"><h3>Containers</h3></div>
        ${d.containers.map((c) => `
          <div class="subform">
            <div class="sec-head"><strong>${esc(c.name)}</strong>${wD ? `<button class="btn small" data-img="${esc(c.name)}">Update image</button>` : ""}</div>
            <div class="mono" style="word-break:break-all">${esc(c.image)}</div>
            <div><div class="muted" style="font-size:13px;margin-bottom:6px">Environment loaded from${c.env_count ? `, plus ${c.env_count} individual variables` : ""}</div>
              <div class="chips">${c.env_from.map((e) => `<span class="chip">${e.kind === "secret" ? "Secret" : "Config map"} ${esc(e.name)}${e.prefix ? ` (prefix ${esc(e.prefix)})` : ""}
                ${w ? `<button title="Stop loading" data-envdel="${esc(c.name)}|${e.kind}|${esc(e.name)}">×</button>` : ""}</span>`).join("") || '<span class="muted" style="font-size:13px">Nothing yet</span>'}</div></div>
            ${w ? `<div class="row3" data-envform="${esc(c.name)}">
              <select class="field" data-k="kind"><option value="configMap">Config map</option><option value="secret">Secret</option></select>
              <select class="field" data-k="name"><option value="">Loading…</option></select>
              <button class="btn" data-envadd="${esc(c.name)}">Load environment</button></div>` : ""}
          </div>`).join("")}
      </div>

      <div class="sec">
        <div class="sec-head"><h3>Storage</h3>${w ? '<button class="btn small" id="mAddVol">Add storage</button>' : ""}</div>
        ${d.pinned_node ? `<div class="notice info">Pods are pinned to node <strong>${esc(d.pinned_node)}</strong> so they keep their local disk.${w ? ' <button class="link" id="mUnpin">Unpin</button>' : ""}</div>` : ""}
        <div id="mVolForm"></div>
        ${d.volumes.length ? `<table class="mini"><tbody>${d.volumes.map((v) => `<tr>
            <td><strong>${esc(v.name)}</strong><div class="muted" style="font-size:13px">${VOL_LABEL[v.type] || esc(v.type)}: ${esc(v.source)}</div></td>
            <td>${mountsOf(v.name)}</td>
            <td style="text-align:right">${w ? `<button class="btn small danger" data-voldel="${esc(v.name)}">Remove</button>` : ""}</td></tr>`).join("")}</tbody></table>`
          : '<div class="muted">No volumes. Data written by the container is lost when the pod is replaced.</div>'}
      </div>

      <div class="sec">
        <div class="sec-head"><h3>Pods</h3></div>
        ${d.pods.length ? `<table class="mini"><tbody>${d.pods.map((p) => `<tr>
          <td class="mono" style="word-break:break-all">${esc(p.name)}</td><td>${esc(p.node || "unscheduled")}</td>
          <td><span class="pill s-${p.reason && p.reason !== "Completed" ? "degraded" : p.ready === p.containers ? "healthy" : "progressing"}">${esc(p.reason || p.phase)}</span></td>
          <td class="muted">${p.restarts} restarts, ${age(p.age_seconds)}</td></tr>`).join("")}</tbody></table>` : '<div class="muted">No pods.</div>'}
      </div>`;

    const canDelete = !d.protected && can("config", ns);
    const body = Ed.open(`${name}`, `Deployment in ${ns}`, html + (canDelete ? `
      <div class="sec" id="mDelSec">
        <div class="sec-head"><h3>Delete deployment</h3></div>
        <div class="muted" style="font-size:13px;margin-bottom:10px">Stops and removes all its pods. Storage claims are kept, so their data is safe.</div>
        <div id="mDelInfo"></div>
        <button class="btn danger" id="mDel">Delete deployment…</button>
      </div>` : ""));
    if (canDelete) wireDelete(ns, name);
    const reload = () => { openManage(ns, name); loadDeployments(); };

    if (!wD && !wC) return;
    wireAutoscaling(body, d, ns, name, wD, reload);

    // replicas
    body.querySelectorAll("[data-step]").forEach((b) => b.onclick = () => {
      const i = $("mRep"); i.value = Math.max(0, Math.min(500, (+i.value || 0) + +b.dataset.step));
    });
    if ($("mRestart")) $("mRestart").onclick = (e) => {
      if (!confirm(`Restart all pods of ${ns}/${name}? They are replaced one by one, following the rollout strategy.`)) return;
      busy(e.target, "Restarting…", async () => {
        try { await api(`/api/deployments/${ns}/${name}/restart`, { method: "POST" }); toast(`Restarting ${name}`); reload(); }
        catch (err) { toast(err.message, "error"); }
      });
    };
    if ($("mScale")) $("mScale").onclick = (e) => busy(e.target, "Scaling…", async () => {
      const n = +$("mRep").value;
      if (n === 0 && !confirm(`Scale ${name} to 0? All its pods stop.`)) return;
      try { await api(`/api/deployments/${ns}/${name}/replicas`, { method: "PUT", json: { replicas: n } }); toast(`Scaled ${name} to ${n}`); reload(); }
      catch (err) { toast(err.message, "error"); }
    });

    // images
    body.querySelectorAll("[data-img]").forEach((b) => b.onclick = () => {
      const dep = S.deployments.find((x) => x.namespace === ns && x.name === name);
      if (dep) { Ed.close(); openImageForm(dep, b.dataset.img); }
    });

    // env from
    const [cms, secs] = await Promise.all([
      api("/api/configmaps?" + qs({ namespace: ns })).catch(() => []),
      api("/api/secrets?" + qs({ namespace: ns })).catch(() => []),
    ]);
    body.querySelectorAll("[data-envform]").forEach((f) => {
      const kind = f.querySelector('[data-k="kind"]'), sel = f.querySelector('[data-k="name"]');
      const fill = () => {
        const list = kind.value === "secret" ? secs.filter((s) => !s.system) : cms.filter((c) => !c.system);
        sel.innerHTML = list.length ? list.map((x) => `<option>${esc(x.name)}</option>`).join("") : '<option value="">None in this namespace</option>';
      };
      kind.onchange = fill; fill();
    });
    body.querySelectorAll("[data-envadd]").forEach((b) => b.onclick = () => busy(b, "Saving…", async () => {
      const f = b.closest("[data-envform]");
      const kind = f.querySelector('[data-k="kind"]').value, src = f.querySelector('[data-k="name"]').value;
      if (!src) return toast("Create a config map or secret in this namespace first.", "error");
      try { await api(`/api/deployments/${ns}/${name}/env-from`, { method: "POST", json: { container: b.dataset.envadd, kind, name: src } }); toast(`${b.dataset.envadd} now loads ${src}`); reload(); }
      catch (err) { toast(err.message, "error"); }
    }));
    body.querySelectorAll("[data-envdel]").forEach((b) => b.onclick = async () => {
      const [container, kind, source] = b.dataset.envdel.split("|");
      if (!confirm(`Stop loading environment from ${source} in ${container}?`)) return;
      try { await api(`/api/deployments/${ns}/${name}/env-from?` + qs({ container, kind, source }), { method: "DELETE" }); reload(); }
      catch (err) { toast(err.message, "error"); }
    });

    // storage
    body.querySelectorAll("[data-voldel]").forEach((b) => b.onclick = async () => {
      if (!confirm(`Remove volume ${b.dataset.voldel} from ${name}? The data itself is not deleted.`)) return;
      try { await api(`/api/deployments/${ns}/${name}/volumes/${b.dataset.voldel}`, { method: "DELETE" }); toast("Volume removed"); reload(); }
      catch (err) { toast(err.message, "error"); }
    });
    if ($("mUnpin")) $("mUnpin").onclick = async () => {
      if (!confirm("Unpin pods from this node? Pods on other nodes will not see data stored on this node's disk.")) return;
      try { await api(`/api/deployments/${ns}/${name}/node-pin`, { method: "DELETE" }); reload(); } catch (err) { toast(err.message, "error"); }
    };
    if ($("mAddVol")) $("mAddVol").onclick = () => renderVolumeForm(d, cms, secs, reload);
  }

  async function renderVolumeForm(d, cms, secs, reload) {
    const ns = d.namespace;
    const [pvcs, classes, nodes] = await Promise.all([
      api("/api/storage/pvcs?" + qs({ namespace: ns })).catch(() => []),
      api("/api/storage/classes").catch(() => []),
      getNodes().catch(() => []),
    ]);
    const box = $("mVolForm");
    box.innerHTML = `<div class="subform">
      <label class="lbl">Type of storage
        <select class="field" id="vType">
          <option value="persistentVolumeClaim">Persistent claim (PVC), survives pod restarts</option>
          <option value="hostPath">Directory on the node's local disk (hostPath)</option>
          <option value="emptyDir">Temporary space, deleted with the pod (emptyDir)</option>
          <option value="configMap">Config map as files</option>
          <option value="secret">Secret as files</option>
        </select></label>
      <div id="vFields" style="display:grid;gap:12px"></div>
      <div class="row3">
        <label class="lbl">Volume name <input class="field" id="vName" placeholder="data"></label>
        <label class="lbl">Container <select class="field" id="vCont">${d.containers.map((c) => `<option>${esc(c.name)}</option>`).join("")}</select></label>
        <label class="lbl">Mount path <input class="field mono" id="vPath" placeholder="/data"></label>
      </div>
      <div class="row2">
        <label class="lbl">Sub path <span class="hint">Optional folder inside the volume</span><input class="field mono" id="vSub"></label>
        <label class="lbl">Access<label class="check" style="margin-top:8px"><input type="checkbox" id="vRO"> Mount read-only</label></label>
      </div>
      <div style="display:flex;gap:10px;justify-content:flex-end"><button class="btn" id="vCancel">Cancel</button><button class="btn primary" id="vSave">Add storage</button></div>
    </div>`;

    const classOpts = `<option value="__default">Cluster default${classes.find((c) => c.default) ? ` (${esc(classes.find((c) => c.default).name)})` : ""}</option>` +
      classes.map((c) => `<option value="${esc(c.name)}">${esc(c.name)}${c.local ? " (local disks)" : ""}</option>`).join("");
    const nodeOpts = (none) => `<option value="">${none}</option>` + nodes.map((n) => `<option>${esc(n.node)}</option>`).join("");

    const fields = {
      persistentVolumeClaim: () => `
        <label class="lbl">Claim <select class="field" id="vClaim">
          ${pvcs.map((p) => `<option value="${esc(p.name)}">${esc(p.name)}, ${esc(p.capacity || p.requested)} ${esc((p.access_modes || []).map((m) => ABBR[m]).join("/"))}, ${esc(p.status)}${p.used_by.length ? `, used by ${esc(p.used_by.join(", "))}` : ""}</option>`).join("")}
          <option value="__new">Create a new claim…</option></select></label>
        <div id="vNewClaim" class="row3" hidden>
          <label class="lbl">Size <input class="field" id="vcSize" value="10Gi"></label>
          <label class="lbl">Class <select class="field" id="vcClass">${classOpts}</select></label>
          <label class="lbl">Access <select class="field" id="vcMode"><option value="ReadWriteOnce">One node (RWO)</option><option value="ReadWriteMany">Many nodes (RWX)</option></select></label>
        </div>`,
      hostPath: () => `
        <div class="row2">
          <label class="lbl">Path on the node <input class="field mono" id="vHost" placeholder="/mnt/data/${esc(d.name)}"></label>
          <label class="lbl">If missing <select class="field" id="vHType"><option value="DirectoryOrCreate">Create directory</option><option value="Directory">Must exist</option><option value="FileOrCreate">Create file</option></select></label>
        </div>
        <label class="lbl">Pin pods to node <span class="hint">Recommended. Data on a node's disk is only visible on that node.</span>
          <select class="field" id="vPin">${nodeOpts("Don't pin")}</select></label>
        <div class="notice">Anyone who can deploy here can read the node's files through this path. Prefer a local persistent volume from the Storage tab for production data.</div>`,
      emptyDir: () => `
        <div class="row2">
          <label class="lbl">Backed by <select class="field" id="vMedium"><option value="">Node disk</option><option value="Memory">Memory (counts toward the memory limit)</option></select></label>
          <label class="lbl">Size limit <input class="field" id="vLimit" placeholder="e.g. 2Gi"></label>
        </div>`,
      configMap: () => `<label class="lbl">Config map <select class="field" id="vSrc">${cms.filter((c) => !c.system).map((c) => `<option>${esc(c.name)}</option>`).join("") || '<option value="">None in this namespace</option>'}</select>
        <span class="hint">Each key becomes a file. Edits reach running pods within about a minute (not with sub path).</span></label>`,
      secret: () => `<label class="lbl">Secret <select class="field" id="vSrc">${secs.filter((s) => !s.system).map((s) => `<option>${esc(s.name)}</option>`).join("") || '<option value="">None in this namespace</option>'}</select>
        <span class="hint">Each key becomes a file.</span></label>`,
    };

    const renderFields = () => {
      const t = $("vType").value;
      $("vFields").innerHTML = fields[t]();
      $("vRO").checked = t === "configMap" || t === "secret";
      if (!$("vName").dataset.touched) $("vName").value = { persistentVolumeClaim: "data", hostPath: "node-disk", emptyDir: "scratch", configMap: "config", secret: "secret-files" }[t];
      if (!$("vPath").dataset.touched) $("vPath").value = { persistentVolumeClaim: "/data", hostPath: "/data", emptyDir: "/tmp/scratch", configMap: "/etc/config", secret: "/etc/secrets" }[t];
      if (t === "persistentVolumeClaim") {
        const claim = $("vClaim");
        const sync = () => { $("vNewClaim").hidden = claim.value !== "__new"; };
        if (!pvcs.length) claim.value = "__new";
        claim.onchange = sync; sync();
      }
    };
    $("vType").onchange = renderFields;
    ["vName", "vPath"].forEach((id) => $(id).addEventListener("input", () => { $(id).dataset.touched = "1"; }));
    renderFields();
    $("vCancel").onclick = () => { box.innerHTML = ""; };
    box.scrollIntoView({ behavior: "smooth", block: "nearest" });

    $("vSave").onclick = (e) => busy(e.target, "Saving…", async () => {
      const t = $("vType").value;
      const volName = $("vName").value.trim();
      const body = {
        name: volName, type: t,
        mounts: [{ container: $("vCont").value, mount_path: $("vPath").value.trim(), sub_path: $("vSub").value.trim(), read_only: $("vRO").checked }],
      };
      try {
        if (t === "persistentVolumeClaim") {
          let claim = $("vClaim").value;
          if (claim === "__new") {
            claim = `${d.name}-${volName}`.slice(0, 63).replace(/-+$/, "");
            const cls = $("vcClass").value;
            await api(`/api/storage/pvcs/${ns}`, { method: "POST", json: {
              name: claim, size: $("vcSize").value.trim(), access_mode: $("vcMode").value,
              storage_class: cls === "__default" ? null : cls } });
            toast(`Created claim ${claim}`);
          }
          body.claim_name = claim;
        } else if (t === "hostPath") {
          Object.assign(body, { path: $("vHost").value.trim() || $("vHost").placeholder, host_path_type: $("vHType").value, pin_node: $("vPin").value });
        } else if (t === "emptyDir") {
          Object.assign(body, { medium: $("vMedium").value, size_limit: $("vLimit").value.trim() });
        } else {
          body.source_name = $("vSrc").value;
          if (!body.source_name) return toast(`Create a ${t === "secret" ? "secret" : "config map"} in ${ns} first.`, "error");
        }
        const res = await api(`/api/deployments/${ns}/${d.name}/volumes`, { method: "POST", json: body });
        toast(`Added ${volName} to ${d.name}`);
        (res.warnings || []).forEach((w) => toast(w, "error"));
        reload();
      } catch (err) { toast(err.message, "error"); }
    });
  }

  // ================================================================== key/value editor (config maps and secrets)
  // Validates a "Name" input in place: marks the field and focuses it instead of a vague error.
  function checkName(input, what) {
    const v = input.value.trim();
    const msg = !v ? `Enter a name for the ${what}. The grey text is only an example.`
      : v.length > 253 || !/^[a-z0-9]([-a-z0-9.]*[a-z0-9])?$/.test(v)
        ? `"${v}" is not a valid name. Use lowercase letters, digits and '-', starting and ending with a letter or digit.` : "";
    input.setAttribute("aria-invalid", msg ? "true" : "false");
    if (msg) { input.focus(); toast(msg, "error"); input.oninput = () => input.setAttribute("aria-invalid", "false"); }
    return !msg;
  }

  // A whole Kubernetes object (apiVersion + kind), rather than the contents of a config file
  function manifestKind(text) {
    if (!/^\s*apiVersion:\s*\S+/m.test(text)) return null;
    const m = text.match(/^\s*kind:\s*([A-Za-z]+)/m);
    return m ? m[1] : null;
  }
  function openInApply(text, ns) {
    Ed.close();
    A.pending = { text, ns: ns || currentNs() || "default" };
    if (location.hash === "#apply") loadApply(); else location.hash = "#apply";
  }
  function offerApply(text, what) {
    const kind = manifestKind(text);
    if (!kind) return false;
    const ok = confirm(`${what} is a Kubernetes ${kind} manifest (it has apiVersion and kind), not the contents of a config file.\n\n` +
      `OK: open it in Apply YAML and create the ${kind} from it (recommended).\nCancel: keep it here as a plain file.`);
    if (ok) openInApply(text, $("edNs") ? $("edNs").value : null);
    return ok;
  }

  function kvEditor(host, data, { secret = false, binaryKeys = [], readOnly = false } = {}) {
    const rows = Object.entries(data).map(([k, v]) => ({ key: k, value: v, revealed: !secret }));
    const binary = binaryKeys.map((k) => ({ key: k, keep: true }));
    const render = () => {
      host.innerHTML = `<div class="kv">
        ${rows.map((r, i) => `<div class="kv-row">
          <input class="field mono" data-i="${i}" data-f="key" value="${esc(r.key)}" placeholder="key" ${readOnly ? "disabled" : ""} aria-label="Key">
          ${r.revealed ? `<textarea class="field" data-i="${i}" data-f="value" rows="${Math.min(12, Math.max(1, (r.value.match(/\n/g) || []).length + 1))}" ${readOnly ? "disabled" : ""} aria-label="Value">${esc(r.value)}</textarea>`
            : `<div class="masked"><span>Hidden, ${r.value.length} characters</span><button class="link" data-reveal="${i}">Show</button></div>`}
          ${readOnly ? "<span></span>" : `<button class="icon" data-del="${i}" title="Remove key" aria-label="Remove key">×</button>`}
        </div>`).join("")}
        ${binary.map((b, i) => `<div class="kv-row"><input class="field mono" value="${esc(b.key)}" disabled>
          <div class="masked"><span>${b.keep ? "Binary value, kept as is" : "Will be removed"}</span></div>
          ${readOnly ? "<span></span>" : `<button class="icon" data-bin="${i}" title="${b.keep ? "Remove" : "Keep"}">${b.keep ? "×" : "↺"}</button>`}</div>`).join("")}
        ${!rows.length && !binary.length ? '<div class="muted">No keys yet.</div>' : ""}
        ${readOnly ? "" : `<div style="display:flex;gap:10px;flex-wrap:wrap">
          <button class="btn small" data-add>Add key</button>
          <button class="btn small" data-file>Add key from file</button>
          ${secret && rows.some((r) => !r.revealed) ? '<button class="btn small" data-revealall>Show all values</button>' : ""}
          <input type="file" data-fileinput hidden multiple></div>`}
      </div>`;
      host.querySelectorAll("[data-f]").forEach((el) => el.oninput = () => { rows[+el.dataset.i][el.dataset.f] = el.value; });
      host.querySelectorAll("[data-reveal]").forEach((b) => b.onclick = () => { rows[+b.dataset.reveal].revealed = true; render(); });
      host.querySelectorAll("[data-del]").forEach((b) => b.onclick = () => { rows.splice(+b.dataset.del, 1); render(); });
      host.querySelectorAll("[data-bin]").forEach((b) => b.onclick = () => { binary[+b.dataset.bin].keep = !binary[+b.dataset.bin].keep; render(); });
      const q = (s) => host.querySelector(s);
      if (q("[data-add]")) q("[data-add]").onclick = () => { rows.push({ key: "", value: "", revealed: true }); render(); host.querySelectorAll('[data-f="key"]')[rows.length - 1].focus(); };
      if (q("[data-revealall]")) q("[data-revealall]").onclick = () => { rows.forEach((r) => r.revealed = true); render(); };
      if (q("[data-file]")) {
        q("[data-file]").onclick = () => q("[data-fileinput]").click();
        q("[data-fileinput]").onchange = async (e) => {
          for (const f of e.target.files) {
            if (f.size > 1024 * 1024) { toast(`${f.name} is larger than 1 MiB. Use a volume for large files.`, "error"); continue; }
            const text = await f.text();
            if (text.includes("\uFFFD")) { toast(`${f.name} looks binary. Only text files can be added here.`, "error"); continue; }
            if (offerApply(text, f.name)) return;
            const existing = rows.find((r) => r.key === f.name);
            if (existing) { existing.value = text; existing.revealed = true; } else rows.push({ key: f.name, value: text, revealed: true });
          }
          render();
        };
      }
    };
    render();
    return {
      collect() {
        const data = {};
        for (const r of rows) {
          const k = r.key.trim();
          if (!k) { if (r.value) throw new Error("Every value needs a key."); continue; }
          if (!/^[-._a-zA-Z0-9]+$/.test(k)) throw new Error(`Key "${k}" may only use letters, digits, '-', '_' and '.'.`);
          if (k in data) throw new Error(`Key "${k}" appears twice.`);
          data[k] = r.value;
        }
        return { data, keep_binary: binary.filter((b) => b.keep).map((b) => b.key) };
      },
    };
  }

  function restartOption(usedBy) {
    if (!usedBy || !usedBy.length) return "";
    return `<label class="check"><input type="checkbox" id="edRestart" checked> Restart ${usedBy.length === 1 ? "the deployment" : `${usedBy.length} deployments`} that use it: ${usedBy.map(esc).join(", ")}</label>
      <span class="muted" style="font-size:13px;margin-top:-10px">Environment variables only change when pods restart. Mounted files update on their own, but apps usually read them once at start.</span>`;
  }

  // ================================================================== config maps
  async function loadConfigMaps() {
    try { S.configmaps = await api("/api/configmaps?" + qs({ namespace: currentNs() })); renderConfigMaps(); }
    catch (e) { toast("Could not load config maps: " + e.message, "error"); }
  }
  function renderConfigMaps() {
    const items = S.configmaps.filter((x) => ($("showSystem").checked || !x.system) && matches(x, x.name, x.namespace, ...x.keys));
    $("cmRows").innerHTML = items.length ? items.map((x, i) => `<tr>
      <td>${nsName(x)}</td>
      <td><div class="keys mono" title="${esc(x.keys.join(", "))}">${esc(x.keys.join(", ")) || '<span class="muted">empty</span>'}</div><div class="dns">${x.keys.length} keys${x.immutable ? ", immutable" : ""}</div></td>
      <td>${usedBy(x.used_by)}</td><td>${age(x.age_seconds)}</td>
      <td><div class="actions">
        <button class="btn small" data-cm="${i}">${x.protected || x.immutable || x.system ? "View" : "Edit"}</button>
        ${x.protected || x.system ? "" : `<button class="btn small danger" data-cmdel="${i}">Delete</button>`}
      </div></td></tr>`).join("")
      : `<tr><td colspan="5" class="empty">${S.configmaps.length ? "No config maps match this filter." : "No config maps here. Create one to hold settings or config files for your apps."}</td></tr>`;
    $("cmRows").querySelectorAll("[data-cm]").forEach((b) => b.onclick = () => openConfigMap(items[+b.dataset.cm]));
    $("cmRows").querySelectorAll("[data-cmdel]").forEach((b) => b.onclick = () => deleteObj("configmaps", items[+b.dataset.cmdel], "config map"));
  }

  async function openConfigMap(item) {
    const isNew = !item;
    let cm = { data: {}, binary_keys: [], used_by: [], namespace: currentNs() || "default" };
    if (!isNew) { try { cm = await api(`/api/configmaps/${item.namespace}/${item.name}`); } catch (e) { return toast(e.message, "error"); } }
    const ro = !isNew && (cm.protected || cm.immutable || !can("config", cm.namespace));
    const body = Ed.open(isNew ? "New config map" : cm.name, isNew ? "Settings and config files for your apps" : `Config map in ${cm.namespace}`, `
      ${ro ? `<div class="notice">${cm.immutable ? "This config map is immutable. Create a new one to change it." : "This namespace is protected. Values are shown read-only."}</div>` : ""}
      ${isNew ? `<div class="row2"><label class="lbl">Name <input class="field" id="edName" placeholder="app-settings"></label>
        <label class="lbl">Namespace <select class="field" id="edNs">${nsOptions(cm.namespace, "config")}</select></label></div>` : ""}
      <div id="edKv"></div>
      ${ro ? "" : restartOption(cm.used_by)}`,
      ro ? [] : [{ label: isNew ? "Create config map" : "Save changes", cls: "primary", onClick: save }]);
    const kv = kvEditor(body.querySelector("#edKv"), cm.data, { binaryKeys: cm.binary_keys, readOnly: ro });

    async function save(btn) {
      if (isNew && !checkName($("edName"), "config map")) return;
      let payload;
      try { payload = kv.collect(); } catch (e) { return toast(e.message, "error"); }
      const pasted = Object.entries(payload.data).find(([, v]) => manifestKind(v) === "ConfigMap");
      if (pasted && offerApply(pasted[1], `The value of "${pasted[0]}"`)) return;
      await busy(btn, "Saving…", async () => {
        try {
          if (isNew) {
            const ns = $("edNs").value;
            await api(`/api/configmaps/${ns}`, { method: "POST", json: { name: $("edName").value.trim(), data: payload.data } });
            toast(`Created config map ${$("edName").value.trim()}`);
          } else {
            const r = await api(`/api/configmaps/${cm.namespace}/${cm.name}`, { method: "PUT", json: {
              data: payload.data, resource_version: cm.resource_version, restart: !!($("edRestart") && $("edRestart").checked) } });
            toast(r.changed.length ? `Saved ${cm.name}${r.restarted.length ? `, restarting ${r.restarted.join(", ")}` : ""}` : "No changes to save");
          }
          Ed.close(); loadConfigMaps();
        } catch (e) { toast(e.message, "error"); }
      });
    }
  }
  $("newConfigMap").onclick = () => openConfigMap(null);

  async function deleteObj(kind, item, label) {
    const path = `/api/${kind}/${item.namespace}/${item.name}`;
    const warn = item.used_by.length ? `\n\nIt is used by ${item.used_by.join(", ")}. New pods of those deployments will fail to start.` : "";
    if (!typedConfirm(item.name, `Delete ${label} ${item.namespace}/${item.name}?${warn}`)) return;
    try { await api(path + (item.used_by.length ? "?force=true" : ""), { method: "DELETE" }); toast(`Deleted ${item.name}`); refreshView(); }
    catch (e) { toast(e.message, "error"); }
  }

  // ================================================================== secrets
  const SECRET_TYPE = {
    Opaque: "Generic", "kubernetes.io/tls": "TLS certificate", "kubernetes.io/dockerconfigjson": "Registry login",
    "kubernetes.io/basic-auth": "Basic auth", "kubernetes.io/ssh-auth": "SSH key",
    "kubernetes.io/service-account-token": "Service account token", "helm.sh/release.v1": "Helm release",
    "bootstrap.kubernetes.io/token": "Bootstrap token",
  };
  async function loadSecrets() {
    try { S.secrets = await api("/api/secrets?" + qs({ namespace: currentNs() })); renderSecrets(); }
    catch (e) { toast("Could not load secrets: " + e.message, "error"); }
  }
  function renderSecrets() {
    const items = S.secrets.filter((x) => ($("showSystem").checked || !x.system) && matches(x, x.name, x.namespace, x.type, ...x.keys));
    $("secRows").innerHTML = items.length ? items.map((x, i) => `<tr>
      <td>${nsName(x)}</td><td>${esc(SECRET_TYPE[x.type] || x.type)}</td>
      <td><div class="keys mono">${esc(x.keys.join(", "))}</div></td>
      <td>${usedBy(x.used_by)}</td><td>${age(x.age_seconds)}</td>
      <td><div class="actions">
        ${x.system ? '<span class="muted" style="font-size:13px">Managed by the system</span>' :
          `<button class="btn small" data-sec="${i}">${x.protected || !x.editable ? "View" : "Edit"}</button>
           ${x.protected ? "" : `<button class="btn small danger" data-secdel="${i}">Delete</button>`}`}
      </div></td></tr>`).join("")
      : `<tr><td colspan="6" class="empty">${S.secrets.length ? "No secrets match this filter." : "No secrets here. Create one for passwords, API keys, certificates or registry logins."}</td></tr>`;
    $("secRows").querySelectorAll("[data-sec]").forEach((b) => b.onclick = () => openSecret(items[+b.dataset.sec]));
    $("secRows").querySelectorAll("[data-secdel]").forEach((b) => b.onclick = () => deleteObj("secrets", items[+b.dataset.secdel], "secret"));
  }

  async function openSecret(item) {
    if (!item) return newSecret();
    let s;
    try { s = await api(`/api/secrets/${item.namespace}/${item.name}`); } catch (e) { return toast(e.message, "error"); }
    const ro = s.protected || !s.editable || !can("secrets", s.namespace);
    const body = Ed.open(s.name, `${SECRET_TYPE[s.type] || s.type} secret in ${s.namespace}`, `
      ${ro ? '<div class="notice">This secret is read-only here.</div>' : '<div class="notice info">Values are hidden until you choose Show. Viewing is recorded in the change log.</div>'}
      <div id="edKv"></div>
      ${ro ? "" : restartOption(s.used_by)}`,
      ro ? [] : [{ label: "Save changes", cls: "primary", onClick: save }]);
    const kv = kvEditor(body.querySelector("#edKv"), s.data, { secret: true, binaryKeys: s.binary_keys, readOnly: ro });

    async function save(btn) {
      if (isNew && !checkName($("edName"), "config map")) return;
      let payload;
      try { payload = kv.collect(); } catch (e) { return toast(e.message, "error"); }
      const pasted = Object.entries(payload.data).find(([, v]) => manifestKind(v) === "ConfigMap");
      if (pasted && offerApply(pasted[1], `The value of "${pasted[0]}"`)) return;
      await busy(btn, "Saving…", async () => {
        try {
          const r = await api(`/api/secrets/${s.namespace}/${s.name}`, { method: "PUT", json: {
            ...payload, resource_version: s.resource_version, restart: !!($("edRestart") && $("edRestart").checked) } });
          toast(r.changed.length ? `Saved ${s.name}${r.restarted.length ? `, restarting ${r.restarted.join(", ")}` : ""}` : "No changes to save");
          Ed.close(); loadSecrets();
        } catch (e) { toast(e.message, "error"); }
      });
    }
  }

  function newSecret() {
    const body = Ed.open("New secret", "Passwords, keys, certificates and registry logins", `
      <div class="row2">
        <label class="lbl">Name <input class="field" id="edName" placeholder="app-credentials"></label>
        <label class="lbl">Namespace <select class="field" id="edNs">${nsOptions(currentNs() || "default", "secrets")}</select></label>
      </div>
      <label class="lbl">Type <select class="field" id="edType">
        <option value="Opaque">Generic (key and value pairs)</option>
        <option value="kubernetes.io/tls">TLS certificate</option>
        <option value="kubernetes.io/dockerconfigjson">Registry login (image pull secret)</option></select></label>
      <div id="edTypeBody" style="display:grid;gap:14px"></div>`,
      [{ label: "Create secret", cls: "primary", onClick: save }]);
    let kv = null;
    const renderType = () => {
      const t = $("edType").value, host = $("edTypeBody");
      kv = null;
      if (t === "Opaque") { host.innerHTML = '<div id="edKv"></div>'; kv = kvEditor(host.querySelector("#edKv"), { "": "" }, {}); }
      else if (t === "kubernetes.io/tls") {
        host.innerHTML = `
          <label class="lbl">Certificate (tls.crt) <span class="hint">PEM, including the chain if you have one</span><textarea class="field mono" id="tCrt" rows="6" placeholder="-----BEGIN CERTIFICATE-----"></textarea></label>
          <label class="lbl">Private key (tls.key)<textarea class="field mono" id="tKey" rows="6" placeholder="-----BEGIN PRIVATE KEY-----"></textarea></label>
          <div><button class="btn small" id="tLoad">Load from files</button><input type="file" id="tFiles" multiple hidden></div>`;
        $("tLoad").onclick = () => $("tFiles").click();
        $("tFiles").onchange = async (e) => {
          for (const f of e.target.files) {
            const text = await f.text();
            if (/PRIVATE KEY/.test(text)) $("tKey").value = text; else if (/CERTIFICATE/.test(text)) $("tCrt").value = text;
            else toast(`${f.name} is not a PEM certificate or key.`, "error");
          }
        };
      } else {
        host.innerHTML = `
          <label class="lbl">Registry server <input class="field mono" id="rServer" placeholder="registry.example.com"></label>
          <div class="row2"><label class="lbl">Username <input class="field" id="rUser" autocomplete="off"></label>
            <label class="lbl">Password or token <input class="field" id="rPass" type="password" autocomplete="new-password"></label></div>
          <label class="lbl">Email <span class="hint">Optional</span><input class="field" id="rEmail"></label>
          <div class="notice info">To use it, add it to the deployment's <span class="mono">imagePullSecrets</span>, or to the namespace's default service account.</div>`;
      }
    };
    $("edType").onchange = renderType; renderType();

    async function save(btn) {
      if (!checkName($("edName"), "secret")) return;
      const t = $("edType").value;
      const json = { name: $("edName").value.trim(), type: t, data: {} };
      try {
        if (t === "Opaque") json.data = kv.collect().data;
        else if (t === "kubernetes.io/tls") json.data = { "tls.crt": $("tCrt").value.trim() + "\n", "tls.key": $("tKey").value.trim() + "\n" };
        else json.registry = { registry: $("rServer").value.trim(), username: $("rUser").value, password: $("rPass").value, email: $("rEmail").value.trim() };
        if (t === "kubernetes.io/tls" && (!$("tCrt").value.trim() || !$("tKey").value.trim())) throw new Error("Add both the certificate and the private key.");
        if (json.registry && (!json.registry.registry || !json.registry.username || !json.registry.password)) throw new Error("Enter the registry server, username and password.");
      } catch (e) { return toast(e.message, "error"); }
      await busy(btn, "Creating…", async () => {
        try { await api(`/api/secrets/${$("edNs").value}`, { method: "POST", json }); toast(`Created secret ${json.name}`); Ed.close(); loadSecrets(); }
        catch (e) { toast(e.message, "error"); }
      });
    }
    body.querySelector("#edName").focus();
  }
  $("newSecret").onclick = newSecret;

  // ================================================================== storage
  async function loadStorage() {
    try {
      [S.pvcs, S.pvs, S.classes] = await Promise.all([
        api("/api/storage/pvcs?" + qs({ namespace: currentNs() })), api("/api/storage/pvs"), api("/api/storage/classes")]);
      renderStorage();
    } catch (e) { toast("Could not load storage: " + e.message, "error"); }
  }
  const PVC_STATE = { Bound: "healthy", Pending: "progressing", Lost: "failed" };
  const PV_STATE = { Bound: "healthy", Available: "scaled-down", Released: "progressing", Failed: "failed", Pending: "progressing" };

  function renderStorage() {
    const pvcs = S.pvcs.filter((p) => matches(p, p.name, p.namespace, p.storage_class, p.volume));
    const localWaitNote = (p) => p.status === "Pending" && (S.classes.find((c) => c.name === p.storage_class) || {}).binding_mode === "WaitForFirstConsumer"
      ? '<div class="dns">Binds when a pod uses it</div>' : "";
    $("pvcRows").innerHTML = pvcs.length ? pvcs.map((p, i) => `<tr>
      <td>${nsName(p)}</td>
      <td><span class="pill s-${PVC_STATE[p.status] || "queued"}">${esc(p.status)}</span>${localWaitNote(p)}</td>
      <td>${esc(p.capacity || p.requested)}${p.capacity && p.requested && p.capacity !== p.requested ? `<div class="dns">resizing to ${esc(p.requested)}</div>` : ""}</td>
      <td>${esc(p.access_modes.map((m) => ABBR[m] || m).join(", "))}</td>
      <td>${esc(p.storage_class) || '<span class="muted">none</span>'}${p.volume ? `<div class="dns mono">${esc(p.volume)}</div>` : ""}</td>
      <td>${usedBy(p.used_by)}</td>
      <td><div class="actions">${p.protected || !can("storage", p.namespace) ? "" : `
        ${p.expandable ? `<button class="btn small" data-resize="${i}">Resize</button>` : ""}
        <button class="btn small danger" data-pvcdel="${i}">Delete</button>`}</div></td></tr>`).join("")
      : `<tr><td colspan="7" class="empty">${S.pvcs.length ? "No claims match this filter." : "No storage claims here. Create one, then attach it to a deployment."}</td></tr>`;
    $("pvcRows").querySelectorAll("[data-resize]").forEach((b) => b.onclick = () => resizePvc(pvcs[+b.dataset.resize]));
    $("pvcRows").querySelectorAll("[data-pvcdel]").forEach((b) => b.onclick = () => deletePvc(pvcs[+b.dataset.pvcdel]));

    const pvs = S.pvs.filter((p) => matches(p, p.name, p.claim, p.storage_class, p.source.detail, p.source.node));
    const src = (s) => ({ local: "Local disk", hostPath: "Node directory", nfs: "NFS", csi: "CSI" }[s.type] || s.type) +
      `<div class="dns mono">${esc(s.detail)}${s.node ? ` on ${esc(s.node)}` : ""}</div>`;
    $("pvRows").innerHTML = pvs.length ? pvs.map((p, i) => `<tr>
      <td class="dname">${esc(p.name)}</td>
      <td><span class="pill s-${PV_STATE[p.status] || "queued"}">${esc(p.status)}</span></td>
      <td>${esc(p.capacity)}<div class="dns">${esc(p.access_modes.map((m) => ABBR[m] || m).join(", "))}, ${esc(p.reclaim_policy)}</div></td>
      <td>${src(p.source)}</td><td>${esc(p.storage_class) || '<span class="muted">none</span>'}</td>
      <td>${p.claim ? `<span class="mono">${esc(p.claim)}</span>` : '<span class="muted">none</span>'}</td>
      <td><div class="actions">${!can("cluster") ? "" : `
        ${p.status === "Released" ? `<button class="btn small" data-release="${i}">Make available</button>` : ""}
        <button class="btn small danger" data-pvdel="${i}">Delete</button>`}</div></td></tr>`).join("")
      : '<tr><td colspan="7" class="empty">No persistent volumes. With a dynamic storage class you may not need any; for local disks, add one per disk.</td></tr>';
    $("pvRows").querySelectorAll("[data-release]").forEach((b) => b.onclick = () => releasePv(pvs[+b.dataset.release]));
    $("pvRows").querySelectorAll("[data-pvdel]").forEach((b) => b.onclick = () => deletePv(pvs[+b.dataset.pvdel]));

    $("scRows").innerHTML = S.classes.length ? S.classes.map((c) => `<tr>
      <td class="dname">${esc(c.name)}${c.default ? ' <span class="pill s-healthy">Default</span>' : ""}</td>
      <td class="mono">${esc(c.provisioner)}</td><td>${c.binding_mode === "WaitForFirstConsumer" ? "When a pod uses it" : "Immediately"}</td>
      <td>${esc(c.reclaim_policy)}</td><td>${c.allow_expansion ? "Yes" : "No"}</td></tr>`).join("")
      : '<tr><td colspan="5" class="empty">No storage classes. Add a local disk class to use disks attached to your nodes.</td></tr>';
    $("newLocalClass").hidden = !can("cluster") || S.classes.some((c) => c.local);
  }

  function classOptions(selected) {
    const def = S.classes.find((c) => c.default);
    return `<option value="__default">Cluster default${def ? ` (${esc(def.name)})` : ", none set"}</option>` +
      S.classes.map((c) => `<option value="${esc(c.name)}" ${c.name === selected ? "selected" : ""}>${esc(c.name)}${c.local ? " (local disks)" : ""}</option>`).join("") +
      '<option value="">No class, bind to a specific volume</option>';
  }

  function newPvc() {
    Ed.open("New storage claim", "Request persistent storage for a namespace", `
      <div class="row2">
        <label class="lbl">Name <input class="field" id="pName" placeholder="app-data"></label>
        <label class="lbl">Namespace <select class="field" id="pNs">${nsOptions(currentNs() || "default", "storage")}</select></label>
      </div>
      <div class="row2">
        <label class="lbl">Size <input class="field" id="pSize" value="10Gi"><span class="hint">Mi, Gi or Ti, e.g. 500Mi, 20Gi</span></label>
        <label class="lbl">Access <select class="field" id="pMode">
          <option value="ReadWriteOnce">Read-write on one node (RWO)</option>
          <option value="ReadWriteMany">Read-write on many nodes (RWX)</option>
          <option value="ReadOnlyMany">Read-only on many nodes (ROX)</option>
          <option value="ReadWriteOncePod">Read-write by one pod (RWOP)</option></select></label>
      </div>
      <label class="lbl">Storage class <select class="field" id="pClass">${classOptions()}</select></label>
      <label class="lbl" id="pVolWrap" hidden>Volume <select class="field" id="pVol"></select>
        <span class="hint">Only available volumes that are large enough and match the class are listed.</span></label>
      <div class="notice info" id="pHint" hidden></div>`,
      [{ label: "Create claim", cls: "primary", onClick: save }]);

    const sync = () => {
      const cls = $("pClass").value, sc = S.classes.find((c) => c.name === cls);
      const pickVolume = cls === "" || (sc && sc.local);
      $("pVolWrap").hidden = !pickVolume;
      if (pickVolume) {
        const want = cls === "__default" ? null : cls;
        const avail = S.pvs.filter((p) => p.status === "Available" && (want === null || p.storage_class === want));
        $("pVol").innerHTML = (sc && sc.local ? '<option value="">Any matching volume (chosen when a pod starts)</option>' : "") +
          avail.map((p) => `<option value="${esc(p.name)}">${esc(p.name)}, ${esc(p.capacity)}, ${esc(p.source.detail)}${p.source.node ? " on " + esc(p.source.node) : ""}</option>`).join("");
        if (!avail.length && cls === "") $("pVol").innerHTML = '<option value="">No available volumes. Create one first.</option>';
      }
      $("pHint").hidden = !(sc && sc.local);
      $("pHint").textContent = "Local disk claims stay Pending until a pod uses them. Kubernetes then picks a volume on the node where the pod runs.";
    };
    $("pClass").onchange = sync; sync();

    async function save(btn) {
      const cls = $("pClass").value;
      const json = { name: $("pName").value.trim(), size: $("pSize").value.trim(), access_mode: $("pMode").value,
        storage_class: cls === "__default" ? null : cls, volume_name: $("pVolWrap").hidden ? "" : $("pVol").value };
      if (cls === "" && !json.volume_name) return toast("Choose a volume, or pick a storage class.", "error");
      await busy(btn, "Creating…", async () => {
        try { await api(`/api/storage/pvcs/${$("pNs").value}`, { method: "POST", json }); toast(`Created claim ${json.name}`); Ed.close(); loadStorage(); }
        catch (e) { toast(e.message, "error"); }
      });
    }
  }
  $("newPvc").onclick = newPvc;

  async function newPv() {
    const nodes = await getNodes().catch(() => []);
    const localClass = S.classes.find((c) => c.local);
    Ed.open("New persistent volume", "Register a disk or share that claims can use", `
      <label class="lbl">Where the data lives <select class="field" id="vType">
        <option value="local">Local disk on a node (recommended for node disks)</option>
        <option value="hostPath">Directory on a node (hostPath, single-node or test clusters)</option>
        <option value="nfs">NFS share</option></select></label>
      <div class="row2">
        <label class="lbl">Name <input class="field" id="vName" placeholder="node1-ssd1"></label>
        <label class="lbl">Capacity <input class="field" id="vCap" value="100Gi"></label>
      </div>
      <div class="row2" id="vNodeRow">
        <label class="lbl">Node <select class="field" id="vNode"><option value="">Choose a node</option>${nodes.map((n) => `<option>${esc(n.node)}</option>`).join("")}</select></label>
        <label class="lbl">Path <input class="field mono" id="vPath" placeholder="/mnt/disks/ssd1"></label>
      </div>
      <label class="check" id="vDirRow"><input type="checkbox" id="vDir" checked> Create the directory on the node if it is missing</label>
      <label class="lbl" id="vNfsRow" hidden>NFS server <input class="field mono" id="vNfs" placeholder="10.0.0.20"></label>
      <div class="row2">
        <label class="lbl">Storage class <select class="field" id="vClass">
          ${S.classes.map((c) => `<option value="${esc(c.name)}" ${localClass && c.name === localClass.name ? "selected" : ""}>${esc(c.name)}</option>`).join("")}
          <option value="" ${localClass ? "" : "selected"}>No class</option></select></label>
        <label class="lbl">Access <select class="field" id="vMode"><option value="ReadWriteOnce">One node (RWO)</option><option value="ReadWriteMany">Many nodes (RWX)</option><option value="ReadOnlyMany">Read-only, many (ROX)</option></select></label>
      </div>
      <label class="lbl">When its claim is deleted <select class="field" id="vReclaim"><option value="Retain">Keep the data (Retain)</option><option value="Delete">Delete the volume (Delete)</option></select></label>
      <div class="notice info" id="vHint"></div>`,
      [{ label: "Create volume", cls: "primary", onClick: save }]);

    const hints = {
      local: `Use a disk mounted on the node, for example /mnt/disks/ssd1. The node agent can create folders under /mnt/disks or /var/lib/k8s-volumes. Pods using this volume are scheduled onto that node automatically.${localClass ? "" : " Tip: add a local disk class first so claims bind at the right moment."}`,
      hostPath: "The directory is created if missing. Pinning to a node is optional but strongly recommended.",
      nfs: "Every node needs NFS client tools installed (nfs-common or nfs-utils). Use Many nodes (RWX) to share it across replicas.",
    };
    const sync = () => {
      const t = $("vType").value;
      $("vNodeRow").querySelector("label").hidden = t === "nfs";
      $("vNfsRow").hidden = t !== "nfs";
      $("vDirRow").hidden = t !== "local";
      $("vHint").textContent = hints[t];
      $("vPath").placeholder = t === "nfs" ? "/exports/data" : t === "hostPath" ? "/var/lib/app-data" : "/mnt/disks/ssd1";
    };
    $("vType").onchange = sync; sync();

    async function save(btn) {
      const json = { name: $("vName").value.trim(), type: $("vType").value, capacity: $("vCap").value.trim(), path: $("vPath").value.trim(),
        node: $("vType").value === "nfs" ? "" : $("vNode").value, nfs_server: $("vNfs").value.trim(),
        storage_class: $("vClass").value, access_mode: $("vMode").value, reclaim_policy: $("vReclaim").value,
        create_dir: $("vType").value === "local" && $("vDir").checked };
      await busy(btn, "Creating…", async () => {
        try { const r = await api("/api/storage/pvs", { method: "POST", json });
          toast(`Created volume ${json.name}${r.created_dir ? `, and ${json.path} on ${json.node}` : ""}`); Ed.close(); loadStorage(); }
        catch (e) { toast(e.message, "error"); }
      });
    }
  }
  $("newPv").onclick = newPv;

  $("newLocalClass").onclick = () => {
    Ed.open("Add local disk class", "For disks attached directly to nodes", `
      <p style="margin:0">This creates a storage class with no provisioner and delayed binding. You register each disk as a persistent volume, and Kubernetes binds a claim to a disk on the node where its pod is scheduled.</p>
      <label class="lbl">Name <input class="field" id="lcName" value="local-storage"></label>
      <label class="check"><input type="checkbox" id="lcDefault"> Make it the cluster default</label>`,
      [{ label: "Add class", cls: "primary", onClick: (btn) => busy(btn, "Adding…", async () => {
        try { await api("/api/storage/classes/local", { method: "POST", json: { name: $("lcName").value.trim(), make_default: $("lcDefault").checked } });
          toast("Added local disk class"); Ed.close(); loadStorage(); }
        catch (e) { toast(e.message, "error"); }
      }) }]);
  };

  function resizePvc(p) {
    Ed.open(`Resize ${p.name}`, `Claim in ${p.namespace}`, `
      <div class="current">Current size <strong>${esc(p.capacity || p.requested)}</strong>, class ${esc(p.storage_class)}</div>
      <label class="lbl">New size <input class="field" id="rsSize" value="${esc(p.requested)}"><span class="hint">Volumes can only grow. Some drivers finish resizing when the pod restarts.</span></label>`,
      [{ label: "Resize", cls: "primary", onClick: (btn) => busy(btn, "Resizing…", async () => {
        try { await api(`/api/storage/pvcs/${p.namespace}/${p.name}/size`, { method: "PUT", json: { size: $("rsSize").value.trim() } }); toast(`Resizing ${p.name}`); Ed.close(); loadStorage(); }
        catch (e) { toast(e.message, "error"); }
      }) }]);
  }
  async function deletePvc(p) {
    const warn = p.used_by.length ? `It is mounted by ${p.used_by.join(", ")}.` : "";
    if (!typedConfirm(p.name, `Delete claim ${p.namespace}/${p.name}? ${warn}\nWith reclaim policy Delete, the data is destroyed.`)) return;
    try { await api(`/api/storage/pvcs/${p.namespace}/${p.name}${p.used_by.length ? "?force=true" : ""}`, { method: "DELETE" }); toast(`Deleted claim ${p.name}`); loadStorage(); }
    catch (e) { toast(e.message, "error"); }
  }
  async function releasePv(p) {
    if (!confirm(`Make ${p.name} available for new claims? Its existing data is kept and will be visible to the next claim.`)) return;
    try { await api(`/api/storage/pvs/${p.name}/release`, { method: "POST" }); toast(`${p.name} is available`); loadStorage(); }
    catch (e) { toast(e.message, "error"); }
  }
  async function deletePv(p) {
    if (!typedConfirm(p.name, `Delete volume ${p.name}?${p.claim ? `\nIt is bound to ${p.claim}.` : ""}\nFor local and NFS volumes the files on disk are not removed.`)) return;
    try { await api(`/api/storage/pvs/${p.name}${p.status === "Bound" ? "?force=true" : ""}`, { method: "DELETE" }); toast(`Deleted volume ${p.name}`); loadStorage(); }
    catch (e) { toast(e.message, "error"); }
  }

  // ================================================================== images (local registry)
  const regOn = () => !!(S.cfg.registry && S.cfg.registry.enabled);
  const fmtBytes = (n) => n == null ? "" : n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(0)} KiB` : n < 1073741824 ? `${(n / 1048576).toFixed(1)} MiB` : `${(n / 1073741824).toFixed(2)} GiB`;
  const fmtDate = (iso) => iso ? new Date(iso).toLocaleString() : "";
  S.repos = []; S.openRepos = new Set(); S.tagCache = {};

  async function getRepos(force = false) {
    if (!regOn()) return [];
    if (force || !S.reposAt || Date.now() - S.reposAt > 15000) {
      S.repos = (await api("/api/registry")).repositories; S.reposAt = Date.now();
    }
    return S.repos;
  }
  async function getTags(repo, force = false) {
    if (force || !S.tagCache[repo]) S.tagCache[repo] = (await api("/api/registry/tags?" + qs({ repo }))).tags;
    return S.tagCache[repo];
  }

  async function loadImages() {
    await loadRegistrySwitch();
    if (S.imgPane === "nodes") {
      $("pushTar").hidden = true; $("setupNodes").hidden = true;
      return loadNodeImages();
    }
    const cfg = S.cfg.registry || {}, on = regOn();
    $("pushTar").hidden = !on || !can("deploy"); $("setupNodes").hidden = !on || !can("cluster");
    $("regOff").hidden = on;
    if (!on) {
      $("regOff").innerHTML = !cfg.configured
        ? 'The local registry is not set up. Install it from <span class="mono">deploy/registry</span> and set <span class="mono">REGISTRY_URL</span> on the dashboard. You can still load tar files straight onto the nodes, and see them under <strong>On nodes</strong>.'
        : `The local registry is switched off.${can("cluster") ? " Switch it on above to push and deploy registry images." : " An admin can switch it on."} Images already on the nodes are listed under <strong>On nodes</strong>.`;
      $("regInfo").textContent = ""; $("regNodes").hidden = true;
      $("imgRows").innerHTML = '<tr><td colspan="4" class="empty">Registry images are not available while the registry is off.</td></tr>';
      return;
    }
    try {
      await getRepos(true);
      $("regInfo").innerHTML = `Nodes pull these images from <span class="mono">${esc(cfg.host)}</span>.`;
      await Promise.all([...S.openRepos].map((r) => getTags(r, true).catch(() => null)));
      renderImages(); checkNodeTrust();
    } catch (e) {
      $("imgRows").innerHTML = `<tr><td colspan="4" class="empty">${esc(e.message)}</td></tr>`;
    }
  }


  // ---------------------------------------------------------------- registry switch and images on nodes
  S.imgPane = "reg"; S.ni = null;
  const RT_LABEL = { crio: "CRI-O", containerd: "containerd", docker: "Docker" };

  async function loadRegistrySwitch() {
    const cfg = S.cfg.registry || {};
    $("regSwitch").hidden = !cfg.configured;
    if (!cfg.configured) return;
    try {
      const st = await api("/api/registry/status");
      S.regStatus = st;
      S.cfg.registry.enabled = st.enabled;
      const [cls, label, text] = !st.managed ? ["healthy", "External", `Uses the registry at ${st.host}, which the dashboard did not install; it has no on/off switch here.`]
        : !st.enabled ? ["queued", "Off", "Switched off. Its stored images are kept and come back when you switch it on."]
        : !st.ready ? ["progressing", "Starting", `Starting at ${st.host}…`]
        : ["healthy", "On", `Running. Nodes pull from ${st.host}.`];
      $("regPill").className = "pill s-" + cls; $("regPill").textContent = label; $("regState").textContent = text;
      $("regToggle").hidden = !st.managed || !can("cluster");
      $("regToggle").textContent = st.enabled ? "Switch off" : "Switch on";
      $("regToggle").className = "btn" + (st.enabled ? "" : " primary");
    } catch (e) { $("regState").textContent = e.message; }
  }

  $("regToggle").onclick = async () => {
    const st = S.regStatus || {}, on = !st.enabled;
    if (!on) {
      const inUse = st.images_in_use || [];
      const warn = inUse.length ? `\n\n${inUse.length} image(s) from the registry are in use:\n${inUse.slice(0, 6).join("\n")}${inUse.length > 6 ? "\n…" : ""}\n\nRunning pods keep running, but new pods on nodes without a copy cannot start until you switch it on again.` : "";
      if (!confirm(`Switch off the local registry?\n\nIts pod is stopped; stored images are kept on its volume.${warn}`)) return;
    }
    await busy($("regToggle"), on ? "Switching on…" : "Switching off…", async () => {
      try {
        const r = await api("/api/registry/state", { method: "POST", json: { enabled: on } });
        S.cfg.registry.enabled = r.enabled; S.reposAt = 0; S.tagCache = {};
        toast(on ? "Local registry switched on" : "Local registry switched off");
        loadImages();
      } catch (e) { toast(e.message, "error"); }
    });
  };

  function showImgPane(p) {
    S.imgPane = p;
    $("imgTabReg").setAttribute("aria-selected", p === "reg"); $("imgTabNodes").setAttribute("aria-selected", p === "nodes");
    $("imgRegPane").hidden = p !== "reg"; $("imgNodesPane").hidden = p !== "nodes";
    loadImages();
  }
  $("imgTabReg").onclick = () => showImgPane("reg");
  $("imgTabNodes").onclick = () => showImgPane("nodes");

  async function loadNodeImages() {
    try { S.ni = await api("/api/node-images"); }
    catch (e) { $("niRows").innerHTML = `<tr><td colspan="6" class="empty">${esc(e.message)}</td></tr>`; return; }
    const keep = $("niNode").value;
    $("niNode").innerHTML = '<option value="">All nodes</option>' + S.ni.nodes.map((n) => `<option ${n.node === keep ? "selected" : ""}>${esc(n.node)}</option>`).join("");
    $("niCleanup").hidden = !can("cluster");
    $("niErr").hidden = !S.ni.errors.length;
    $("niErr").innerHTML = S.ni.errors.map((e) => `<div><strong>${esc(e.node)}</strong>: ${esc(e.error)}</div>`).join("");
    const rts = [...new Set(S.ni.nodes.map((n) => RT_LABEL[n.runtime] || n.runtime))].join(" and ");
    const dockerNodes = S.ni.nodes.filter((n) => n.docker).length;
    $("niInfo").innerHTML = `What each node's ${esc(rts || "runtime")} holds, read through the CRI like the kubelet does. Kubernetes starts these without pulling.`
      + (dockerNodes ? ` ${dockerNodes} node(s) also run Docker; its images are listed separately because Kubernetes does not use them.` : "");
    renderNodeImages();
  }

  function renderNodeImages() {
    if (!S.ni) return;
    const src = $("niSource").value, node = $("niNode").value, unused = $("niUnused").checked, total = S.ni.nodes.length;
    const rows = S.ni.images.filter((i) => (src === "all" || (src === "docker") === (i.source === "docker"))
      && (!node || i.nodes.includes(node)) && (!unused || (!i.in_use && i.source !== "docker")) && matches(i, i.image || "", i.id, ...i.used_by));
    $("niRows").innerHTML = rows.map((i, k) => {
      const docker = i.source === "docker";
      const where = docker ? '<span class="src-docker">Docker<div class="dns">not used by Kubernetes</div></span>' : esc(RT_LABEL[i.source] || i.source);
      const nodes = i.nodes.length === total && total > 1 ? `all ${total} nodes` : i.nodes.map(esc).join(", ");
      const missing = !docker && i.image && i.nodes.length < total ? `<div class="dns" style="color:var(--warn)">not on ${total - i.nodes.length} node(s)</div>` : "";
      return `<tr>
        <td>${i.image ? `<span class="mono">${esc(i.image)}</span>` : `<span class="muted">untagged</span> <span class="mono">${esc(i.id)}</span>`}
          ${i.pinned ? '<div class="dns">pinned by the runtime (system image)</div>' : ""}</td>
        <td>${where}</td><td>${esc(fmtBytes(i.size))}</td><td>${nodes}${missing}</td>
        <td>${docker ? '<span class="muted">n/a</span>' : i.used_by.length ? usedBy(i.used_by) : i.in_use ? "Running pods" : '<span class="muted">Not used</span>'}</td>
        <td><div class="actions">
          ${!docker && i.image && !i.pinned && can("deploy") ? `<button class="btn small primary" data-nideploy="${k}">Deploy</button>` : ""}
          ${!i.pinned && can("cluster") ? `<button class="btn small danger" data-nirm="${k}">Remove</button>` : ""}
        </div></td></tr>`;
    }).join("") || `<tr><td colspan="6" class="empty">${S.ni.images.length ? "No images match." : "No images found on the nodes."}</td></tr>`;
    $("niRows").querySelectorAll("[data-nideploy]").forEach((b) => b.onclick = () => {
      const i = rows[+b.dataset.nideploy]; useImage(i.image, { nodes: i.nodes, total });
    });
    $("niRows").querySelectorAll("[data-nirm]").forEach((b) => b.onclick = () => removeNodeImage(rows[+b.dataset.nirm]));
  }
  ["niSource", "niNode", "niUnused"].forEach((id) => $(id).onchange = renderNodeImages);

  async function removeNodeImage(i) {
    const docker = i.source === "docker", ref = i.image || i.full_id || i.id;
    const where = i.nodes.length > 1 ? i.nodes.length + " nodes" : i.nodes[0];
    const users = i.used_by.length ? i.used_by.join(", ") : "running pods";
    const msg = `Remove ${i.image || "untagged image " + i.id} from ${where}${docker ? " (Docker)" : ""}?`
      + (i.in_use ? `\n\nIt is used by ${users}. Pods restarted on these nodes would need to pull it again${regOn() ? "" : " (and the registry is off)"}.` : "")
      + (docker ? "\n\nKubernetes does not use Docker's images; this only frees disk space." : "\n\nThe runtime refuses if a running container uses it.");
    if (i.in_use ? !typedConfirm(i.image || i.id, msg) : !confirm(msg)) return;
    const results = [];
    for (const node of i.nodes) {
      try { await api("/api/node-images/remove", { method: "POST", json: { node, image: ref, source: docker ? "docker" : "runtime", force: i.in_use } }); results.push(`${node}: removed`); }
      catch (e) { results.push(`${node}: ${e.message}`); }
    }
    toast(results.join(" · "), results.some((r) => !r.endsWith("removed")) ? "error" : "");
    loadNodeImages();
  }

  // Clean up dangling / unused images: preview first, then remove
  function openCleanup() {
    const nodes = (S.ni && S.ni.nodes) || [], anyDocker = nodes.some((n) => n.docker);
    const body = Ed.open("Clean up images", "Free disk space on the nodes", `
      <fieldset class="stack" style="border:0;padding:0;margin:0"><legend style="font-weight:500;font-size:14px;margin-bottom:6px">What to remove</legend>
        <label class="check" style="align-items:flex-start"><input type="radio" name="cuMode" value="dangling" checked style="margin-top:4px">
          <span><strong>Dangling images</strong><br><span class="muted" style="font-size:13px">Untagged leftovers of older versions and imports. Nothing can refer to them by name.</span></span></label>
        <label class="check" style="align-items:flex-start"><input type="radio" name="cuMode" value="unused" style="margin-top:4px">
          <span><strong>Dangling and unused images</strong><br><span class="muted" style="font-size:13px">Also tagged images no pod or workload in the cluster uses, including scaled-to-zero workloads and CronJobs. Deploying one of them again later means loading it again.</span></span></label>
      </fieldset>
      ${anyDocker ? '<label class="check"><input type="checkbox" id="cuDocker" checked> Also Docker\'s dangling images (<span class="mono">docker image prune</span>)</label>' : ""}
      <label class="lbl">Nodes <select class="field" id="cuNode"><option value="">All nodes</option>${nodes.map((n) => `<option>${esc(n.node)}</option>`).join("")}</select></label>
      <div class="notice info">Protected, never removed: images of running pods and of every workload template, system images pinned by the runtime, and anything the runtime reports as in use.</div>
      <div id="cuPlan"></div>`,
      [{ label: "Preview", id: "cuPreview", onClick: preview }, { label: "Remove", cls: "danger", id: "cuGo", onClick: go }]);
    $("cuGo").disabled = true;
    let planned = null;
    const opts = (dry) => ({ mode: body.querySelector('input[name="cuMode"]:checked').value, docker: !!($("cuDocker") && $("cuDocker").checked),
                             nodes: $("cuNode").value ? [$("cuNode").value] : [], dry_run: dry });
    body.querySelectorAll('input[name="cuMode"], #cuDocker, #cuNode').forEach((x) => x.onchange = () => { planned = null; $("cuGo").disabled = true; $("cuPlan").innerHTML = ""; });
    async function preview(btn) {
      await busy(btn, "Checking…", async () => {
        try {
          const r = await api("/api/node-images/cleanup", { method: "POST", json: opts(true) });
          planned = r;
          $("cuPlan").innerHTML = (r.errors.length ? `<div class="notice">${r.errors.map((e) => `<div><strong>${esc(e.node)}</strong>: ${esc(e.error)}</div>`).join("")}</div>` : "")
            + (r.candidates.length ? `<table class="inner" style="width:100%"><thead><tr><th>Image</th><th>Where</th><th>Size</th><th>Why</th></tr></thead><tbody>
              ${r.candidates.map((x) => `<tr><td class="mono" style="font-size:12.5px">${x.image ? esc(x.image) : "untagged " + esc(x.id)}</td>
                <td>${esc(x.node)}<div class="dns">${esc(RT_LABEL[x.source] || x.source)}</div></td><td>${esc(fmtBytes(x.size))}</td><td class="dns">${esc(x.reason)}</td></tr>`).join("")}
              </tbody></table><p><strong>${r.candidates.length} image(s), ${esc(fmtBytes(r.total_bytes))}</strong> will be removed.</p>`
              : '<div class="notice info">Nothing to remove. The nodes are clean.</div>');
          $("cuGo").disabled = !r.candidates.length;
          $("cuGo").textContent = r.candidates.length ? `Remove ${r.candidates.length} image(s)` : "Remove";
        } catch (e) { toast(e.message, "error"); }
      });
    }
    async function go(btn) {
      if (!planned || !confirm(`Remove ${planned.candidates.length} image(s), ${fmtBytes(planned.total_bytes)}?`)) return;
      await busy(btn, "Removing…", async () => {
        try {
          const r = await api("/api/node-images/cleanup", { method: "POST", json: opts(false) });
          const failed = r.results.filter((x) => !x.ok);
          $("cuPlan").innerHTML = `<div class="notice ${failed.length ? "" : "info"}">Removed ${r.removed} image(s), freed ${esc(fmtBytes(r.reclaimed_bytes))}.`
            + (failed.length ? `<br>${failed.length} could not be removed:<br>${failed.map((x) => `${esc(x.image || x.id)} on ${esc(x.node)}: ${esc(x.message)}`).join("<br>")}` : "") + "</div>";
          $("cuGo").disabled = true; planned = null;
          toast(`Removed ${r.removed} image(s), freed ${fmtBytes(r.reclaimed_bytes)}`, failed.length ? "error" : "");
          loadNodeImages();
        } catch (e) { toast(e.message, "error"); }
      });
    }
  }
  $("niCleanup").onclick = openCleanup;


  async function checkNodeTrust() {
    try {
      const nodes = await getNodes();
      const pending = nodes.filter((n) => n.agent && n.agent.ready && n.agent.registry && n.agent.registry.state !== "ok");
      $("regNodes").hidden = !pending.length;
      $("regNodes").innerHTML = pending.length ? `${pending.length === nodes.length ? "No node" : `${pending.length} of ${nodes.length} nodes`} ${pending.length === 1 ? "is" : "are"} set up to pull from the registry yet (${pending.map((n) => esc(n.node)).join(", ")}). Choose <strong>Set up nodes</strong>, or pods using registry images cannot start there.` : "";
    } catch (e) { /* nodes panel reports its own errors */ }
  }

  function renderImages() {
    if (!regOn()) return;
    const items = S.repos.filter((r) => matches(r, r.name, ...r.tags));
    if (!items.length) {
      $("imgRows").innerHTML = `<tr><td colspan="4" class="empty">${S.repos.length ? "No images match this filter." : "The registry is empty. Choose Push image tar to add your first image."}</td></tr>`;
      return;
    }
    $("imgRows").innerHTML = items.map((r) => {
      const open = S.openRepos.has(r.name);
      const shown = r.tags.slice(-6).reverse();
      const row = `<tr>
        <td><div class="dname mono">${esc(r.name)}</div></td>
        <td><div class="chips">${shown.map((t) => `<span class="chip">${esc(t)}</span>`).join("")}${r.tags.length > shown.length ? `<span class="muted" style="font-size:13px">and ${r.tags.length - shown.length} more</span>` : ""}</div></td>
        <td>${usedBy(r.used_by)}</td>
        <td><div class="actions"><button class="btn small" data-repo="${esc(r.name)}" aria-expanded="${open}">${open ? "Hide tags" : "Show tags"}</button></div></td></tr>`;
      return row + (open ? `<tr class="subrow"><td colspan="4">${renderTagTable(r.name)}</td></tr>` : "");
    }).join("");
    $("imgRows").querySelectorAll("[data-repo]").forEach((b) => b.onclick = async () => {
      const repo = b.dataset.repo;
      if (S.openRepos.has(repo)) { S.openRepos.delete(repo); return renderImages(); }
      S.openRepos.add(repo); renderImages();
      try { await getTags(repo, true); } catch (e) { toast(e.message, "error"); }
      renderImages();
    });
    $("imgRows").querySelectorAll("[data-use]").forEach((b) => b.onclick = () => useImage(b.dataset.use));
    $("imgRows").querySelectorAll("[data-copy]").forEach((b) => b.onclick = () => {
      navigator.clipboard?.writeText(b.dataset.copy).then(() => toast("Copied " + b.dataset.copy), () => toast(b.dataset.copy));
    });
    $("imgRows").querySelectorAll("[data-del]").forEach((b) => b.onclick = () => deleteTag(b.dataset.del, b.dataset.tag));
  }

  function renderTagTable(repo) {
    const tags = S.tagCache[repo];
    if (!tags) return '<div class="muted" style="padding:10px 0">Loading tags…</div>';
    return `<table class="inner"><thead><tr><th>Tag</th><th>Built</th><th>Size</th><th>Platform</th><th>Used by</th><th></th></tr></thead><tbody>
      ${tags.map((t) => `<tr>
        <td class="mono">${esc(t.tag)}${t.error ? `<div class="loaded" style="color:var(--fail)">${esc(t.error)}</div>` : ""}</td>
        <td>${esc(fmtDate(t.created))}</td><td>${esc(fmtBytes(t.size))}</td>
        <td class="mono" style="font-size:12px">${esc((t.platforms || []).join(", "))}</td>
        <td>${usedBy(t.used_by)}</td>
        <td><div class="actions">
          <button class="btn small" data-copy="${esc(t.image)}">Copy name</button>
          ${can("cluster") ? `<button class="btn small danger" data-del="${esc(repo)}" data-tag="${esc(t.tag)}">Delete</button>` : ""}
          ${can("deploy") ? `<button class="btn small primary" data-use="${esc(t.image)}">Deploy</button>` : ""}
        </div></td></tr>`).join("")}
    </tbody></table>`;
  }

  async function deleteTag(repo, tag) {
    const image = `${S.cfg.registry.host}/${repo}:${tag}`;
    const t = (S.tagCache[repo] || []).find((x) => x.tag === tag) || { used_by: [] };
    const warn = t.used_by.length ? `\n\nIt is used by ${t.used_by.join(", ")}. Pods started on new nodes will fail to pull it.` : "";
    if (!typedConfirm(tag, `Delete ${image} from the registry?\nOther tags pointing at the same build are removed too.${warn}`)) return;
    try {
      await api("/api/registry/tags?" + qs({ repo, tag, force: t.used_by.length ? "true" : "false" }), { method: "DELETE" });
      toast(`Deleted ${image}`); delete S.tagCache[repo]; loadImages();
    } catch (e) { toast(e.message, "error"); }
  }

  // Deploy a registry image into a deployment (Images tab)
  async function useImage(image, local = null) {
    // local = { nodes, total } when the image comes from the nodes' runtime rather than the registry
    const nsList = S.namespaces.filter((n) => can("deploy", n));
    const policies = local
      ? `<option value="IfNotPresent">IfNotPresent (use the copy on the node)</option>
         <option value="Never">Never (never try to pull; fail if a node lacks it)</option>`
      : `<option value="IfNotPresent">IfNotPresent (recommended for unique tags)</option>
         <option value="Always">Always (for tags you overwrite, like latest)</option>`;
    const partial = local && local.nodes.length < local.total
      ? `<div class="notice">This image is only on ${local.nodes.map(esc).join(", ")} (${local.nodes.length} of ${local.total} nodes). Pods scheduled on other nodes cannot start. Load the tar on every node, or push it to the registry.</div>` : "";
    const body = Ed.open("Deploy image", image, `${partial}
      <label class="lbl">Namespace <select class="field" id="uNs">${nsList.map((n) => `<option ${n === currentNs() ? "selected" : ""}>${esc(n)}</option>`).join("")}</select></label>
      <label class="lbl">Deployment <select class="field" id="uDep"></select></label>
      <label class="lbl">Container <select class="field" id="uCt"></select></label>
      <div class="current" id="uCur"></div>
      <label class="lbl">Pull policy <select class="field" id="uPolicy">${policies}</select></label>`,
      [{ label: "Deploy image", cls: "primary", id: "uGo", onClick: go }]);
    let deps = [];
    const fillCt = () => {
      const d = deps.find((x) => x.name === $("uDep").value);
      $("uCt").innerHTML = d ? d.containers.map((ct) => `<option>${esc(ct.name)}</option>`).join("") : "";
      showCur();
    };
    const showCur = () => {
      const d = deps.find((x) => x.name === $("uDep").value), ct = d && d.containers.find((x) => x.name === $("uCt").value);
      $("uCur").innerHTML = ct ? `Currently running <span class="mono">${esc(ct.image)}</span>` : "No deployments in this namespace.";
      $("uGo").disabled = !ct;
    };
    const fillDeps = async () => {
      try { deps = await api("/api/deployments?" + qs({ namespace: $("uNs").value })); } catch (e) { deps = []; toast(e.message, "error"); }
      $("uDep").innerHTML = deps.map((d) => `<option>${esc(d.name)}</option>`).join("");
      fillCt();
    };
    body.querySelector("#uNs").onchange = fillDeps;
    body.querySelector("#uDep").onchange = fillCt;
    body.querySelector("#uCt").onchange = showCur;
    await fillDeps();

    async function go(btn) {
      await busy(btn, "Starting…", async () => {
        try {
          const r = await api(`/api/deployments/${encodeURIComponent($("uNs").value)}/${encodeURIComponent($("uDep").value)}/image-ref`,
            { method: "POST", json: { container: $("uCt").value, image, pull_policy: $("uPolicy").value } });
          Ed.close(); openJob(r.job_id);
        } catch (e) { toast(e.message, "error"); }
      });
    }
  }

  // Upload with progress (fetch cannot report upload progress)
  function uploadForm(url, fd, onProgress) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", url);
      if (S.token) xhr.setRequestHeader("Authorization", "Bearer " + S.token);
      xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(e.loaded / e.total * 100); };
      xhr.onload = () => {
        let data = {}; try { data = JSON.parse(xhr.responseText); } catch (_) {}
        if (xhr.status === 200) resolve(data);
        else if (xhr.status === 401) { showLogin(); reject(new Error("Sign in required")); }
        else reject(new Error(data.detail || `Upload failed (HTTP ${xhr.status})`));
      };
      xhr.onerror = () => reject(new Error("Upload failed: network error"));
      xhr.send(fd);
    });
  }

  function pushTar() {
    let file = null;
    const body = Ed.open("Push image tar", `Store images in ${S.cfg.registry.host}`, `
      <div><div class="drop" id="pDrop" tabindex="0" role="button" aria-label="Choose image archive">
        <strong>Drop an image archive here, or click to choose</strong>
        <span>From docker save, skopeo copy or ctr export. An archive with several images pushes all of them.</span></div>
        <input type="file" id="pFile" accept=".tar,.gz,.tgz,application/x-tar,application/gzip" hidden></div>
      <label class="lbl">Image name
        <input class="field mono" id="pName" placeholder="Leave empty to keep the names inside the archive">
        <span class="hint">Only for single-image archives, for example team/billing:2.3.0. The registry address is added for you.</span></label>
      <label class="check"><input type="checkbox" id="pUnique"> Add a unique timestamp tag</label>
      <div class="upload-progress" id="pProg" hidden><span id="pText">Uploading…</span><div class="track"><i id="pBar" style="width:0"></i></div></div>`,
      [{ label: "Push to registry", cls: "primary", id: "pGo", onClick: go }]);
    const drop = body.querySelector("#pDrop"), input = body.querySelector("#pFile");
    $("pGo").disabled = true;
    const pick = (f) => {
      if (!f) return; file = f; drop.className = "drop has";
      drop.innerHTML = `<strong class="mono">${esc(f.name)}</strong><span>${fmtBytes(f.size)}. Click to choose a different file.</span>`;
      $("pGo").disabled = false;
    };
    drop.onclick = () => input.click();
    drop.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); input.click(); } };
    input.onchange = (e) => pick(e.target.files[0]);
    ["dragenter", "dragover"].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add("over"); }));
    ["dragleave", "drop"].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove("over"); }));
    drop.addEventListener("drop", (e) => pick(e.dataTransfer.files[0]));

    async function go(btn) {
      const fd = new FormData();
      fd.append("file", file); fd.append("target_image", $("pName").value.trim()); fd.append("unique_tag", $("pUnique").checked ? "true" : "false");
      $("pProg").hidden = false;
      await busy(btn, "Uploading…", async () => {
        try {
          const r = await uploadForm("/api/registry/push", fd, (p) => {
            $("pBar").style.width = p + "%";
            $("pText").textContent = p < 100 ? `Uploading, ${p.toFixed(0)}%` : "Upload complete, starting push…";
          });
          Ed.close(); openJob(r.job_id);
        } catch (e) { toast(e.message, "error"); $("pProg").hidden = true; }
      });
    }
  }
  $("pushTar").onclick = pushTar;

  $("setupNodes").onclick = async () => {
    if (!confirm(`Set up every node to pull from ${S.cfg.registry.host} over plain HTTP?\n\nThe node agents write the registry settings for containerd or CRI-O on each node.`)) return;
    const btn = $("setupNodes");
    await busy(btn, "Setting up…", async () => {
      try {
        const r = await api("/api/registry/configure-nodes", { method: "POST" });
        const label = { ok: "Ready", "action-needed": "One step left", manual: "Manual step", failed: "Failed" };
        const cls = { ok: "healthy", "action-needed": "progressing", manual: "progressing", failed: "failed" };
        Ed.open("Node setup", `Registry ${r.host}`, `<ul class="list">${r.nodes.map((n) => `<li style="align-items:flex-start"><div class="grow">
            <div><strong>${esc(n.node)}</strong> <span class="muted">${esc(n.runtime || "")}</span></div>
            ${n.message ? `<div class="node-msg">${esc(n.message)}</div>` : ""}</div>
            <span class="pill s-${cls[n.state] || "failed"}">${label[n.state] || n.state}</span></li>`).join("")}</ul>`);
        S.nodesAt = 0; checkNodeTrust();
      } catch (e) { toast(e.message, "error"); }
    });
  };

  // ================================================================== apply YAML
  const A = { overrides: {}, tars: {}, plan: null, checkedText: null, pending: null, busy: false };

  async function loadApply() {
    const nsList = S.namespaces.filter((n) => ["deploy", "config", "storage", "secrets"].some((cap) => can(cap, n)));
    const want = (A.pending && A.pending.ns) || $("yNs").value || (canWrite(currentNs()) && currentNs()) || (nsList.includes("default") ? "default" : nsList[0]);
    $("yNs").innerHTML = nsList.map((n) => `<option ${n === want ? "selected" : ""}>${esc(n)}</option>`).join("");
    const ro = !["deploy", "config", "storage", "secrets"].some((cap) => can(cap));
    $("yApply").hidden = ro; $("yTemplate").hidden = ro;
    if (regOn()) { try { await getRepos(); } catch (_) { /* shown on Images tab */ } }
    if (A.pending) {
      $("yText").value = A.pending.text; A.pending = null;
      A.overrides = {}; A.tars = {}; A.plan = null;
      return checkYaml();
    }
    renderPlan();
  }

  const registryImages = () => regOn() ? S.repos.flatMap((r) => r.tags.slice().reverse().map((t) => `${S.cfg.registry.host}/${r.name}:${t}`)) : [];
  const yamlChanged = () => A.checkedText !== null && $("yText").value !== A.checkedText;
  function setApplyState() {
    const stale = !A.plan || yamlChanged();
    const tarMissing = Object.values(A.tars).some((t) => !t.file);
    $("yApply").disabled = A.busy || stale || !A.plan.ok || tarMissing;
    $("yState").textContent = A.busy ? "" : !A.plan ? "" : yamlChanged() ? "The YAML changed. Choose Check again."
      : !A.plan.ok ? "Fix the errors in the plan first." : tarMissing ? "Choose the tar file for each container set to Upload." : "Ready to apply.";
  }

  async function checkYaml() {
    const text = $("yText").value;
    if (!text.trim()) { toast("Paste YAML or drop a file first.", "error"); return; }
    await busy($("yCheck"), "Checking…", async () => {
      try {
        A.plan = await api("/api/manifests/preview", { method: "POST", json: {
          yaml: text, namespace: $("yNs").value, qualify_images: $("yQualify").checked, image_overrides: A.overrides } });
        A.checkedText = text;
      } catch (e) { A.plan = null; A.checkedText = null; $("yPlan").innerHTML = `<div class="plan-err">${esc(e.message)}</div>`; setApplyState(); return; }
      renderPlan();
    });
  }

  const ACTION = { create: ["healthy", "Create"], update: ["progressing", "Update"], error: ["failed", "Error"],
                   created: ["healthy", "Created"], updated: ["healthy", "Updated"] };

  function renderPlan(results) {
    const plan = results || A.plan;
    if (!plan) { $("yPlan").innerHTML = '<span class="muted">Choose Check to see what will be created or changed.</span>'; return setApplyState(); }
    const imgs = registryImages();
    $("yPlan").innerHTML = plan.objects.map((o) => {
      const act = results && o.action !== "error" ? o.action + "d" : o.action;
      const [cls, label] = ACTION[act] || ["failed", act];
      const images = (o.images || []).map((im) => {
        const tar = A.tars[im.key], ov = A.overrides[im.key];
        const sel = tar ? "__tar" : ov ? ov : "__keep";
        const opts = [`<option value="__keep" ${sel === "__keep" ? "selected" : ""}>Keep: ${esc(im.original || "(none)")}</option>`];
        if (imgs.length) opts.push(`<optgroup label="Local registry">${imgs.map((x) => `<option ${x === sel ? "selected" : ""}>${esc(x)}</option>`).join("")}</optgroup>`);
        if (ov && !imgs.includes(ov)) opts.push(`<option selected>${esc(ov)}</option>`);
        opts.push(`<option value="__tar" ${sel === "__tar" ? "selected" : ""}>Upload a tar file…</option>`);
        const tarUi = tar ? `
          <div class="tarrow"><button class="btn small" data-tarpick="${esc(im.key)}">${tar.file ? esc(tar.file.name) + ` (${fmtBytes(tar.file.size)})` : "Choose tar file"}</button>
            <select class="field" data-tardest="${esc(im.key)}" aria-label="Where to send the image">
              <option value="registry" ${tar.dest === "registry" ? "selected" : ""} ${regOn() ? "" : "disabled"}>To local registry</option>
              <option value="nodes" ${tar.dest === "nodes" ? "selected" : ""}>Onto each node</option></select></div>
          <div class="tarstate">${esc(tar.state || (tar.dest === "nodes"
            ? "Loaded into CRI-O (skopeo) or containerd (ctr) on every node, whichever Kubernetes uses."
            : "Pushed to the local registry; every node pulls it from there."))}</div>` : "";
        const runs = tar ? "" : `<div class="mono" style="font-size:12.5px">Runs <strong>${esc(im.image)}</strong></div>`;
        return `<div class="plan-img">
          <label class="lbl" style="font-size:13px">Container <span class="mono">${esc(im.container)}</span>
            <select class="field mono" data-imgsel="${esc(im.key)}">${opts.join("")}</select></label>
          ${runs}${tarUi}${tar ? "" : (im.warnings || []).map((w) => `<div class="warn">${esc(w)}</div>`).join("")}</div>`;
      }).join("");
      return `<div class="plan-obj">
        <div class="plan-head"><span class="pill s-${cls}">${label}</span><strong>${esc(o.name)}</strong>
          <span class="kind">${esc(o.kind)} in ${esc(o.namespace)}</span></div>
        ${o.error ? `<div class="plan-err">${esc(o.error)}</div>` : ""}
        ${(o.warnings || []).map((w) => `<div class="warn" style="color:var(--warn);font-size:13px;margin-top:4px">${esc(w)}</div>`).join("")}
        ${results ? "" : images}</div>`;
    }).join("") || '<span class="muted">No objects.</span>';

    if (!results) {
      $("yPlan").querySelectorAll("[data-imgsel]").forEach((el) => el.onchange = () => {
        const key = el.dataset.imgsel, v = el.value;
        delete A.overrides[key]; delete A.tars[key];
        if (v === "__tar") { A.tars[key] = { file: null, dest: regOn() ? "registry" : "nodes" }; renderPlan(); }
        else { if (v !== "__keep") A.overrides[key] = v; checkYaml(); }
      });
      $("yPlan").querySelectorAll("[data-tardest]").forEach((el) => el.onchange = () => { A.tars[el.dataset.tardest].dest = el.value; renderPlan(); });
      $("yPlan").querySelectorAll("[data-tarpick]").forEach((b) => b.onclick = () => {
        const input = document.createElement("input");
        input.type = "file"; input.accept = ".tar,.gz,.tgz,application/x-tar,application/gzip";
        input.onchange = () => { if (input.files[0]) { A.tars[b.dataset.tarpick].file = input.files[0]; renderPlan(); } };
        input.click();
      });
    }
    setApplyState();
  }

  // Poll a job until it finishes
  async function waitJob(id, onUpdate) {
    for (;;) {
      const j = await api("/api/jobs/" + id);
      onUpdate && onUpdate(j);
      if (j.state !== "running") return j;
      await new Promise((r) => setTimeout(r, 1500));
    }
  }

  async function sendTar(key, t) {
    const fd = new FormData();
    fd.append("file", t.file); fd.append("target_image", ""); fd.append("unique_tag", "true");
    const url = t.dest === "registry" ? "/api/registry/push" : "/api/nodes/load";
    const r = await uploadForm(url, fd, (p) => { t.state = p < 100 ? `Uploading ${t.file.name}, ${p.toFixed(0)}%` : "Upload complete, preparing…"; renderPlan(); });
    const j = await waitJob(r.job_id, (j) => {
      const nodes = Object.entries(j.nodes || {});
      const detail = nodes.length ? nodes.map(([n, s]) => `${n}: ${s.state === "loading" ? Math.round(s.progress || 0) + "%" : s.state}`).join(", ") : "";
      t.state = `${(j.stages.find((s) => s[0] === j.stage) || ["", j.stage])[1]}${detail ? " (" + detail + ")" : ""}`;
      renderPlan();
    });
    if (j.state !== "succeeded") {
      const last = (j.log || []).filter((l) => l.level === "error").pop();
      throw new Error(`${t.file.name}: ${last ? last.msg : "failed"}`);
    }
    const image = t.dest === "registry" ? (j.pushed[0] || {}).image : j.target_image;
    if (!image) throw new Error(`${t.file.name}: no image name found in the archive`);
    if (t.dest === "registry" && j.pushed.length > 1) toast(`${t.file.name} holds ${j.pushed.length} images; using ${image}`);
    return image;
  }

  async function applyYaml() {
    const plan = A.plan, tars = Object.entries(A.tars);
    const summary = plan.objects.map((o) => `${o.action === "create" ? "Create" : "Update"} ${o.kind} ${o.namespace}/${o.name}`).join("\n");
    if (!confirm(`${summary}${tars.length ? `\n\nFirst, ${tars.length} tar file(s) will be uploaded and loaded.` : ""}\n\nApply now?`)) return;
    A.busy = true; setApplyState();
    try {
      for (const [key, t] of tars) {                     // 1. tar files -> images
        const image = await sendTar(key, t);
        delete A.tars[key]; A.overrides[key] = image;
      }
      const r = await api("/api/manifests/apply", { method: "POST", json: {   // 2. apply with the chosen images
        yaml: $("yText").value, namespace: $("yNs").value, qualify_images: $("yQualify").checked, image_overrides: A.overrides } });
      renderPlan(r);
      A.plan = null; A.checkedText = null;
      if (r.applied && r.ok) {
        toast(`Applied ${r.objects.length} object(s)`);
        $("yState").innerHTML = 'Applied. <a href="#workloads">Watch the rollout on Workloads</a>.';
      } else {
        toast(r.applied ? "Some objects failed; see the plan." : "Nothing was changed: the cluster rejected part of the YAML.", "error");
      }
    } catch (e) {
      toast(e.message, "error"); renderPlan();
    } finally {
      A.busy = false;
      if (!A.plan) $("yApply").disabled = true; else setApplyState();
    }
  }

  function yamlTemplate() {
    const ns = $("yNs").value || "default";
    const img = registryImages()[0] || "docker.io/library/nginx:1.27";
    return `apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
  namespace: ${ns}
  labels: { app: my-app }
spec:
  replicas: 1
  selector:
    matchLabels: { app: my-app }
  template:
    metadata:
      labels: { app: my-app }
    spec:
      containers:
        - name: app
          image: ${img}
          imagePullPolicy: IfNotPresent
          ports:
            - containerPort: 8080
          resources:
            requests: { cpu: 50m, memory: 64Mi }
            limits: { memory: 512Mi }
---
apiVersion: v1
kind: Service
metadata:
  name: my-app
  namespace: ${ns}
spec:
  selector: { app: my-app }
  ports:
    - port: 80
      targetPort: 8080
`;
  }

  async function openYamlFor(kind, ns, name) {
    try {
      const r = await api("/api/manifests/export?" + qs({ kind, namespace: ns, name }));
      A.pending = { text: r.yaml, ns };
      if (location.hash === "#apply") loadApply(); else location.hash = "#apply";
    } catch (e) { toast(e.message, "error"); }
  }

  $("yCheck").onclick = checkYaml;
  $("yApply").onclick = applyYaml;
  $("yText").oninput = setApplyState;
  $("yNs").onchange = () => { if (A.plan) checkYaml(); };
  $("yQualify").onchange = () => { if (A.plan) checkYaml(); };
  $("yTemplate").onclick = () => {
    if ($("yText").value.trim() && !confirm("Replace the current YAML with a template?")) return;
    $("yText").value = yamlTemplate(); A.overrides = {}; A.tars = {}; checkYaml();
  };
  const readYamlFiles = async (files) => {
    const texts = await Promise.all([...files].map((f) => f.text()));
    $("yText").value = texts.map((t) => t.trim()).join("\n---\n") + "\n";
    A.overrides = {}; A.tars = {}; checkYaml();
  };
  $("yDrop").onclick = () => $("yFile").click();
  $("yDrop").onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); $("yFile").click(); } };
  $("yFile").onchange = (e) => { if (e.target.files.length) readYamlFiles(e.target.files); e.target.value = ""; };
  ["dragenter", "dragover"].forEach((ev) => $("yDrop").addEventListener(ev, (e) => { e.preventDefault(); $("yDrop").classList.add("over"); }));
  ["dragleave", "drop"].forEach((ev) => $("yDrop").addEventListener(ev, (e) => { e.preventDefault(); $("yDrop").classList.remove("over"); }));
  $("yDrop").addEventListener("drop", (e) => { if (e.dataTransfer.files.length) readYamlFiles(e.dataTransfer.files); });

  // ================================================================== users and access
  const ROLE_TEXT = {
    viewer: "Sees everything in their namespaces. Changes nothing.",
    deployer: "Deploys images and tar files, applies workload YAML, restarts, scales and rolls back.",
    editor: "Deployer, plus config maps, volumes, environment and storage claims.",
    admin: "Everything in their namespaces, including secrets. With all namespaces: also nodes, cluster storage, registry cleanup and users.",
  };
  S.users = [];

  async function loadUsers() {
    if (!(S.me && S.me.caps.includes("users"))) { location.hash = "#workloads"; return; }
    $("rolesLegend").innerHTML = Object.entries(ROLE_TEXT).map(([r, t]) =>
      `<div class="role-card"><strong>${r[0].toUpperCase() + r.slice(1)}</strong><span>${esc(t)}</span></div>`).join("");
    try { S.users = (await api("/api/users")).users; renderUsers(); }
    catch (e) { $("userRows").innerHTML = `<tr><td colspan="6" class="empty">${esc(e.message)}</td></tr>`; }
  }

  const scopeText = (u) => u.namespaces.includes("*") ? "All namespaces (cluster)" : u.namespaces.map(esc).join(", ");
  function renderUsers() {
    const items = S.users.filter((u) => matches(u, u.name, u.role, ...u.namespaces));
    $("userRows").innerHTML = items.map((u, i) => `<tr>
      <td><div class="dname">${esc(u.name)}</div><div class="dns">${u.builtin ? "Built-in, uses the dashboard-auth token" : `Added by ${esc(u.created_by || "?")}${u.created ? ", " + esc(new Date(u.created).toLocaleDateString()) : ""}`}</div></td>
      <td>${esc(u.role)}</td>
      <td>${scopeText(u)}</td>
      <td><span class="pill s-${u.disabled ? "failed" : "healthy"}">${u.disabled ? "Disabled" : "Active"}</span></td>
      <td>${u.last_seen ? esc(new Date(u.last_seen).toLocaleString()) : '<span class="muted">not since restart</span>'}</td>
      <td><div class="actions">${u.builtin ? "" : `
        <button class="btn small" data-uedit="${i}">Edit</button>
        <button class="btn small" data-utoken="${i}">New token</button>
        <button class="btn small" data-udis="${i}">${u.disabled ? "Enable" : "Disable"}</button>
        <button class="btn small danger" data-udel="${i}">Delete</button>`}</div></td></tr>`).join("")
      || '<tr><td colspan="6" class="empty">No users match.</td></tr>';
    const on = (attr, fn) => $("userRows").querySelectorAll(`[${attr}]`).forEach((b) => b.onclick = () => fn(items[+b.getAttribute(attr)]));
    on("data-uedit", openUser);
    on("data-utoken", async (u) => {
      if (!confirm(`Issue a new token for ${u.name}? The current one stops working immediately.`)) return;
      try { const r = await api(`/api/users/${u.name}/token`, { method: "POST" }); showToken(u.name, r.token, false); }
      catch (e) { toast(e.message, "error"); }
    });
    on("data-udis", async (u) => {
      if (!u.disabled && !confirm(`Disable ${u.name}? They are signed out at their next click.`)) return;
      try { await api(`/api/users/${u.name}`, { method: "PUT", json: { disabled: !u.disabled } }); toast(`${u.name} ${u.disabled ? "enabled" : "disabled"}`); loadUsers(); }
      catch (e) { toast(e.message, "error"); }
    });
    on("data-udel", async (u) => {
      if (!typedConfirm(u.name, `Delete user ${u.name}? Their token stops working. Their changes stay in the change log.`)) return;
      try { await api(`/api/users/${u.name}`, { method: "DELETE" }); toast(`Deleted ${u.name}`); loadUsers(); }
      catch (e) { toast(e.message, "error"); }
    });
  }

  function openUser(u) {
    const isNew = !u;
    u = u || { name: "", role: "deployer", namespaces: [currentNs() || "default"] };
    const all = u.namespaces.includes("*");
    const body = Ed.open(isNew ? "Add user" : `Edit ${u.name}`, isNew ? "They sign in with their own token" : "Changes apply to their next click", `
      ${isNew ? `<label class="lbl">Name <input class="field" id="uName" placeholder="for example ravi" autocomplete="off">
        <span class="hint">Lowercase letters, digits and '-'. Shown in the change log.</span></label>` : ""}
      <fieldset class="stack" style="border:0;padding:0;margin:0"><legend style="font-weight:500;font-size:14px;margin-bottom:6px">Role: what they can do</legend>
        ${Object.entries(ROLE_TEXT).map(([r, t]) => `<label class="check" style="align-items:flex-start"><input type="radio" name="uRole" value="${r}" ${u.role === r ? "checked" : ""} style="margin-top:4px">
          <span><strong>${r[0].toUpperCase() + r.slice(1)}</strong><br><span class="muted" style="font-size:13px">${esc(t)}</span></span></label>`).join("")}
      </fieldset>
      <fieldset class="stack" style="border:0;padding:0;margin:0"><legend style="font-weight:500;font-size:14px;margin-bottom:6px">Scope: where they can do it</legend>
        <label class="check"><input type="radio" name="uScope" value="all" ${all ? "checked" : ""}> All namespaces (whole cluster)</label>
        <label class="check"><input type="radio" name="uScope" value="some" ${all ? "" : "checked"}> Only these namespaces</label>
        <div class="ns-picks" id="uNs">${S.namespaces.map((n) => `<label class="check"><input type="checkbox" value="${esc(n)}" ${u.namespaces.includes(n) ? "checked" : ""}> ${esc(n)}</label>`).join("")}</div>
      </fieldset>
      <div class="notice info" id="uHint"></div>`,
      [{ label: isNew ? "Add user" : "Save", cls: "primary", onClick: save }]);
    const sync = () => {
      const some = body.querySelector('input[name="uScope"]:checked').value === "some";
      $("uNs").style.opacity = some ? "1" : ".45";
      $("uNs").querySelectorAll("input").forEach((x) => { x.disabled = !some; });
      const role = body.querySelector('input[name="uRole"]:checked').value;
      $("uHint").textContent = role === "admin" && some
        ? "An admin limited to some namespaces manages everything inside them, but not nodes, cluster storage or users."
        : role === "admin" ? "A cluster admin can do everything, including adding users." : "The server enforces these rules; buttons they cannot use are hidden.";
    };
    body.querySelectorAll('input[name="uScope"], input[name="uRole"]').forEach((x) => x.onchange = sync); sync();
    if (isNew) $("uName").focus();

    async function save(btn) {
      if (isNew && !checkName($("uName"), "user")) return;
      const role = body.querySelector('input[name="uRole"]:checked').value;
      const some = body.querySelector('input[name="uScope"]:checked').value === "some";
      const namespaces = some ? [...$("uNs").querySelectorAll("input:checked")].map((x) => x.value) : ["*"];
      if (!namespaces.length) return toast("Choose at least one namespace, or all namespaces.", "error");
      await busy(btn, "Saving…", async () => {
        try {
          if (isNew) {
            const r = await api("/api/users", { method: "POST", json: { name: $("uName").value.trim(), role, namespaces } });
            loadUsers(); showToken(r.user.name, r.token, true);
          } else {
            await api(`/api/users/${u.name}`, { method: "PUT", json: { role, namespaces } });
            toast(`Saved ${u.name}`); Ed.close(); loadUsers();
          }
        } catch (e) { toast(e.message, "error"); }
      });
    }
  }

  function showToken(name, token, isNew) {
    const url = location.origin + location.pathname;
    Ed.open(isNew ? `${name} was added` : `New token for ${name}`, "Copy it now: it is shown only this once", `
      <div class="notice">The dashboard stores only a fingerprint of this token. If it is lost, issue a new one.</div>
      <div class="token-box" id="tokValue">${esc(token)}</div>
      <div style="display:flex;gap:10px"><button class="btn primary" id="tokCopy">Copy token</button></div>
      <div class="notice info">Send ${esc(name)} the dashboard address <span class="mono">${esc(url)}</span> and this token, through a private channel. They sign in with it on the first screen.</div>`,
      [{ label: "Done", cls: "primary", onClick: () => Ed.close() }]);
    $("tokCopy").onclick = () => {
      const done = () => toast("Token copied");
      if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(token).then(done, () => selectToken());
      else selectToken();
    };
    const selectToken = () => {       // http:// pages have no clipboard API: select it for Ctrl+C
      const r = document.createRange(); r.selectNodeContents($("tokValue"));
      const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(r);
      try { document.execCommand("copy") ? toast("Token copied") : toast("Token selected: press Ctrl+C"); } catch (_) { toast("Token selected: press Ctrl+C"); }
    };
  }
  $("addUser").onclick = () => openUser(null);

  // ================================================================== nodes, jobs, audit
  async function loadNodes() {
    try {
      const nodes = await getNodes(true);
      const withAgent = nodes.filter((n) => n.agent && n.agent.ready && !n.agent.error).length;
      $("nodeSummary").textContent = `${withAgent} of ${nodes.length} nodes can receive images`;
      $("nodes").innerHTML = nodes.map((n) => {
        const a = n.agent; let dot = "fail", text = "No agent running";
        if (a && a.error) text = "Agent unreachable";
        else if (a && a.ready && a.runtime_error) { dot = "fail"; text = "Agent cannot use the runtime: " + a.runtime_error; }
        else if (a && a.ready) { dot = a.busy ? "warn" : "ok"; text = (a.busy ? "Importing, " : "Ready, ") + (a.runtime || "runtime unknown"); }
        else if (a) { dot = "warn"; text = "Agent starting"; }
        if (!n.node_ready) { dot = "fail"; text = "Node not ready"; }
        const reg = a && a.registry && a.registry.host ? a.registry.state : null;
        if (reg && reg !== "unset") text += reg === "ok" ? ", pulls from the local registry" : ", registry not set up";
        return `<li><span class="dot ${dot}"></span><div class="grow"><div>${esc(n.node)}${n.schedulable ? "" : " (cordoned)"}</div><div class="sub">${esc(text)}, ${esc(n.runtime || "")}</div></div></li>`;
      }).join("") || '<li class="sub">No nodes found.</li>';
    } catch (e) { toast("Could not load nodes: " + e.message, "error"); }
  }
  async function loadJobs() {
    try {
      const jobs = await api("/api/jobs");
      if (!jobs.length) return;
      const label = { running: "Running", succeeded: "Done", failed: "Failed" };
      $("jobs").innerHTML = jobs.slice(0, 8).map((j) => `<li><button class="linklike" data-job="${j.id}">
        <div style="display:flex;gap:12px;align-items:center"><div class="grow"><div>${j.deployment ? `${esc(j.namespace)}/${esc(j.deployment)}` : `${j.mode === "load" ? "Load" : "Push"} ${esc(j.filename || "")}`}</div>
        <div class="sub mono">${esc(j.target_image || "preparing…")}</div></div>
        <span class="pill s-${j.state}">${label[j.state]}</span></div></button></li>`).join("");
      $("jobs").querySelectorAll("[data-job]").forEach((b) => b.onclick = () => openJob(b.dataset.job));
    } catch (e) {}
  }
  const AUDIT_LABEL = { create: "Created", edit: "Edited", delete: "Deleted", view: "Viewed", scale: "Scaled", restart: "Restarted",
    image: "Image updated", rollback: "Rolled back", "volume-add": "Storage added", "volume-remove": "Storage removed",
    "env-add": "Environment added", "env-remove": "Environment removed", resize: "Resized", release: "Released", unpin: "Unpinned",
    push: "Pushed to registry", "registry-nodes": "Registry set up on nodes", apply: "Applied YAML", "autoscale-on": "Autoscaling on", "autoscale-change": "Autoscaling changed", "autoscale-off": "Autoscaling off",
    resources: "Set resources", "image-cleanup": "Cleaned up images", delete: "Deleted", "registry-on": "Registry switched on", "registry-off": "Registry switched off", "image-remove": "Removed image from node", "user-create": "User added", "user-update": "User changed", "user-token": "New user token", "user-delete": "User deleted" };
  async function loadAudit() {
    try {
      const rows = await api("/api/audit");
      $("audit").innerHTML = rows.length ? rows.slice(0, 100).map((r) => `<li><div class="grow">
        <div><strong>${esc(AUDIT_LABEL[r.action] || r.action)}</strong> <span class="mono">${esc(r.target)}</span></div>
        <div class="sub">${esc(r.detail)}</div></div><span class="muted" style="font-size:13px;text-align:right">${r.user ? `<strong>${esc(r.user)}</strong><br>` : ""}${esc(new Date(r.ts).toLocaleString())}</span></li>`).join("")
        : '<li class="sub">No changes yet.</li>';
    } catch (e) {}
  }

  // ================================================================== image update sheet
  let chosenFile = null, current = null, currentJob = null, jobTimer = null;
  function openSheet() { $("scrim").classList.add("open"); $("sheet").classList.add("open"); }
  function closeSheet() { $("scrim").classList.remove("open"); $("sheet").classList.remove("open"); clearInterval(jobTimer); jobTimer = null; current = null; }
  $("sheetClose").onclick = closeSheet; $("scrim").onclick = closeSheet; $("cancelBtn").onclick = closeSheet;
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (Ed.isOpen()) Ed.close(); else if ($("sheet").classList.contains("open")) closeSheet();
  });

  function openImageForm(d, container) {
    current = d; chosenFile = null; $("fFile").value = "";
    $("sheetTitle").textContent = "Update image"; $("sheetSub").textContent = `${d.namespace}/${d.name}`;
    $("fContainer").innerHTML = d.containers.map((c) => `<option ${c.name === container ? "selected" : ""}>${esc(c.name)}</option>`).join("");
    $("fTarget").value = ""; $("fUnique").checked = true;
    const on = regOn();
    document.querySelector('#fSource input[value="registry"]').disabled = !on;
    document.querySelector(`#fSource input[value="${on ? "registry" : "upload"}"]`).checked = true;
    $("fDest").querySelector('option[value="registry"]').disabled = !on;
    $("fDest").value = on ? "registry" : "nodes";
    showCurrent(); resetDrop();
    $("formView").hidden = false; $("jobView").hidden = true; $("upProg").hidden = true;
    $("submitBtn").hidden = false; $("cancelBtn").textContent = "Cancel"; $("rollbackBtn").hidden = true;
    syncSource(); openSheet();
    if (on) fillRepos();
  }
  const srcValue = () => document.querySelector('#fSource input:checked').value;
  const currentContainer = () => current && current.containers.find((c) => c.name === $("fContainer").value);

  function showCurrent() {
    const c = currentContainer();
    $("fCurrent").innerHTML = `Currently running <span class="mono">${esc(c.image)}</span>, pull policy ${esc(c.pull_policy)}`;
  }
  $("fContainer").onchange = () => { showCurrent(); if (srcValue() === "registry") fillRepos(); };

  // Registry picker: preselect the repository the container already uses
  async function fillRepos() {
    $("fRepo").innerHTML = "<option>Loading…</option>"; $("fTag").innerHTML = "";
    let repos;
    try { repos = await getRepos(); } catch (e) { toast(e.message, "error"); repos = []; }
    if (!repos.length) {
      $("fRepo").innerHTML = '<option value="">The registry is empty</option>';
      $("fRefPreview").innerHTML = "Push a tar on the Images tab first, or choose Upload a tar file.";
      return syncSubmit();
    }
    const img = currentContainer().image, host = S.cfg.registry.host + "/";
    const usedRepo = img.startsWith(host) ? img.slice(host.length).replace(/:[^:/]+$/, "") : null;
    $("fRepo").innerHTML = repos.map((r) => `<option ${r.name === usedRepo ? "selected" : ""}>${esc(r.name)}</option>`).join("");
    await fillTags();
  }
  async function fillTags() {
    const repo = $("fRepo").value;
    $("fTag").innerHTML = "<option>Loading…</option>";
    try {
      const tags = await getTags(repo, true);
      $("fTag").innerHTML = tags.map((t) => `<option value="${esc(t.tag)}">${esc(t.tag)}${t.created ? `  (${esc(new Date(t.created).toLocaleDateString())})` : ""}</option>`).join("");
    } catch (e) { $("fTag").innerHTML = ""; toast(e.message, "error"); }
    showRef();
  }
  const pickedImage = () => $("fRepo").value && $("fTag").value ? `${S.cfg.registry.host}/${$("fRepo").value}:${$("fTag").value}` : "";
  function showRef() {
    const img = pickedImage(), cur = currentContainer();
    $("fRefPreview").innerHTML = !img ? "Choose a repository and tag."
      : img === cur.image ? `<span class="mono">${esc(img)}</span> is already running. Deploying it again restarts the pods.`
      : `Deploys <span class="mono">${esc(img)}</span>`;
    syncSubmit();
  }
  $("fRepo").onchange = fillTags; $("fTag").onchange = showRef;

  function setPolicies(list) {
    const keep = $("fPolicy").value;
    const text = { IfNotPresent: "IfNotPresent", Always: "Always (re-pull on every start)", Never: "Never (fail if the image is missing)" };
    $("fPolicy").innerHTML = list.map((p) => `<option value="${p}">${text[p]}</option>`).join("");
    $("fPolicy").value = list.includes(keep) ? keep : list[0];
  }
  function syncSource() {
    const src = srcValue(), dest = $("fDest").value, toReg = src === "registry" || dest === "registry";
    $("srcRegistry").hidden = src !== "registry"; $("srcUpload").hidden = src !== "upload";
    setPolicies(toReg ? ["IfNotPresent", "Always"] : ["IfNotPresent", "Never"]);
    $("fDestHint").textContent = dest === "registry"
      ? `Stored in ${S.cfg.registry.host}, so any node, including new ones, can pull it.`
      : "Loaded into containerd or CRI-O on every current node. Nodes added later will not have it.";
    $("fTargetHint").innerHTML = dest === "registry"
      ? `For example <span class="mono">team/api:1.4.2</span>. It is stored under <span class="mono">${esc((S.cfg.registry || {}).host || "")}/</span>.`
      : `For example <span class="mono">registry.local/team/api:1.4.2</span>. The archive is re-tagged to this name on every node.`;
    syncSubmit();
  }
  function syncSubmit() {
    const src = srcValue();
    $("submitBtn").textContent = src === "registry" ? "Deploy image" : $("fDest").value === "registry" ? "Push and deploy" : "Load and deploy";
    $("submitBtn").disabled = src === "registry" ? !pickedImage() : !chosenFile;
  }
  document.querySelectorAll('#fSource input').forEach((r) => r.onchange = () => { syncSource(); if (srcValue() === "registry") fillRepos(); });
  $("fDest").onchange = syncSource;

  function resetDrop() {
    $("drop").className = "drop";
    $("drop").innerHTML = "<strong>Drop an image archive here, or click to choose</strong><span>.tar from docker save, skopeo copy or ctr export. Gzipped .tar.gz works too.</span>";
  }
  function setFile(f) {
    if (!f) return;
    chosenFile = f; $("drop").className = "drop has";
    $("drop").innerHTML = `<strong class="mono">${esc(f.name)}</strong><span>${fmtBytes(f.size)}. Click to choose a different file.</span>`;
    syncSubmit();
  }
  $("drop").onclick = () => $("fFile").click();
  $("drop").onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); $("fFile").click(); } };
  $("fFile").onchange = (e) => setFile(e.target.files[0]);
  ["dragenter", "dragover"].forEach((ev) => $("drop").addEventListener(ev, (e) => { e.preventDefault(); $("drop").classList.add("over"); }));
  ["dragleave", "drop"].forEach((ev) => $("drop").addEventListener(ev, (e) => { e.preventDefault(); $("drop").classList.remove("over"); }));
  $("drop").addEventListener("drop", (e) => setFile(e.dataTransfer.files[0]));

  $("submitBtn").onclick = async () => {
    if (!current) return;
    const d = current, base = `/api/deployments/${encodeURIComponent(d.namespace)}/${encodeURIComponent(d.name)}`;
    const btn = $("submitBtn");
    if (srcValue() === "registry") {
      return busy(btn, "Starting…", async () => {
        try {
          const r = await api(base + "/image-ref", { method: "POST", json: { container: $("fContainer").value, image: pickedImage(), pull_policy: $("fPolicy").value } });
          openJob(r.job_id); loadJobs();
        } catch (e) { toast(e.message, "error"); }
      });
    }
    const fd = new FormData();
    fd.append("file", chosenFile); fd.append("container", $("fContainer").value);
    fd.append("target_image", $("fTarget").value.trim()); fd.append("unique_tag", $("fUnique").checked ? "true" : "false");
    fd.append("pull_policy", $("fPolicy").value); fd.append("destination", $("fDest").value);
    $("upProg").hidden = false;
    await busy(btn, "Uploading…", async () => {
      try {
        const r = await uploadForm(base + "/image", fd, (p) => {
          $("upBar").style.width = p + "%";
          $("upText").textContent = p < 100 ? `Uploading to dashboard, ${p.toFixed(0)}%` : "Upload complete, preparing archive…";
        });
        openJob(r.job_id); loadJobs();
      } catch (e) { toast(e.message, "error"); $("upProg").hidden = true; }
    });
  };

  function openJob(id) {
    currentJob = id;
    $("formView").hidden = true; $("jobView").hidden = false; $("submitBtn").hidden = true; $("cancelBtn").textContent = "Close";
    $("log").innerHTML = ""; $("lanes").innerHTML = "";
    openSheet(); clearInterval(jobTimer); pollJob(); jobTimer = setInterval(pollJob, 1500);
  }
  async function pollJob() {
    let j;
    try { j = await api("/api/jobs/" + currentJob); } catch (e) { clearInterval(jobTimer); toast(e.message, "error"); return; }
    const pushOnly = !j.deployment, loadOnly = j.mode === "load";
    $("sheetTitle").textContent = loadOnly
      ? (j.state === "running" ? "Loading onto nodes" : j.state === "succeeded" ? "Loaded onto nodes" : "Load failed")
      : pushOnly
      ? (j.state === "running" ? "Pushing to registry" : j.state === "succeeded" ? "Pushed to registry" : "Push failed")
      : (j.state === "running" ? "Updating image" : j.state === "succeeded" ? "Image updated" : "Update failed");
    $("sheetSub").textContent = pushOnly ? j.filename : `${j.namespace}/${j.deployment}, container ${j.container}`;
    const stages = j.stages, idx = stages.findIndex((s) => s[0] === j.stage);
    $("stages").style.gridTemplateColumns = `repeat(${stages.length}, 1fr)`;
    $("stages").innerHTML = stages.map(([, l], i) => {
      let cls = "stage";
      if (i < idx || j.state === "succeeded") cls += " done"; else if (i === idx) cls += j.state === "failed" ? " bad" : " active";
      return `<div class="${cls}">${l}</div>`;
    }).join("");
    $("jobImage").innerHTML = j.target_image
      ? `${j.previous_image ? `<span class="mono">${esc(j.previous_image)}</span><br>to ` : "New image "}<span class="mono">${esc(j.target_image)}</span>`
      : j.filename ? `Reading <span class="mono">${esc(j.filename)}</span>` : "Preparing…";
    $("pushedSec").hidden = !j.pushed.length;
    $("pushed").innerHTML = j.pushed.map((p) => `<li><div class="grow"><div class="mono">${esc(p.image)}</div><div class="sub mono">${esc(p.digest)}</div></div></li>`).join("");
    $("lanesSec").hidden = !["nodes", "load"].includes(j.mode);
    const nodes = Object.entries(j.nodes);
    $("lanes").innerHTML = nodes.length ? nodes.map(([n, s]) => {
      const txt = { queued: "Waiting", loading: s.progress >= 100 ? "Importing" : `Sending ${Math.round(s.progress || 0)}%`, loaded: `Loaded in ${s.seconds}s`, failed: "Failed" }[s.state];
      return `<div class="lane ${s.state}"><span class="node" title="${esc(n)}">${esc(n)}</span>
        <div class="track"><i style="width:${s.state === "loaded" || s.state === "failed" ? 100 : (s.progress || 0)}%"></i></div>
        <span class="pill s-${s.state}">${txt}</span>${s.error ? `<div class="lane-err">${esc(s.error)}</div>` : ""}</div>`;
    }).join("") : '<div class="dns">Nodes appear here once the archive is checked.</div>';
    if (j.rollout && j.rollout.desired != null) {
      $("rolloutSec").hidden = false; const r = j.rollout;
      $("rolloutNums").innerHTML = `<span><b>${r.updated}</b>updated</span><span><b>${r.ready}</b>ready</span><span><b>${r.available}</b>available</span><span><b>${r.desired}</b>desired</span>`;
    } else $("rolloutSec").hidden = true;
    const lg = $("log"), atBottom = lg.scrollHeight - lg.scrollTop - lg.clientHeight < 30;
    lg.innerHTML = j.log.map((l) => `<div class="${l.level}"><span class="t">${timeOf(l.ts)}</span>  ${esc(l.msg)}</div>`).join("");
    if (atBottom) lg.scrollTop = lg.scrollHeight;
    $("rollbackBtn").hidden = !(j.state !== "running" && j.previous_image);
    $("rollbackBtn").onclick = async () => {
      if (!confirm(`Roll ${j.container} back to ${j.previous_image}?`)) return;
      try { await api(`/api/jobs/${j.id}/rollback`, { method: "POST" }); toast("Rolled back to " + j.previous_image); loadDeployments(); pollJob(); }
      catch (e) { toast("Roll back failed: " + e.message, "error"); }
    };
    if (j.state !== "running") {
      clearInterval(jobTimer); jobTimer = null; loadJobs(); S.reposAt = 0; S.tagCache = {};
      if (S.tab === "images") loadImages(); else if (!pushOnly) loadDeployments();
      toast(loadOnly ? (j.state === "succeeded" ? `Loaded ${j.target_image} onto the nodes` : "Load onto nodes failed")
        : pushOnly ? (j.state === "succeeded" ? `Pushed ${j.pushed.length} image(s) to the registry` : "Push to registry failed")
        : j.state === "succeeded" ? `${j.deployment} is running the new image` : `Update of ${j.deployment} failed`, j.state === "failed" ? "error" : "");
    }
  }

  // ================================================================== lifecycle
  function stopRefresh() { clearInterval(refreshTimer); refreshTimer = null; }
  function startRefresh() {
    stopRefresh();
    if ($("autoRefresh").checked) refreshTimer = setInterval(() => { if (!document.hidden) refreshView(); }, 10000);
  }
  $("nsSelect").onchange = refreshView;
  $("search").oninput = rerender;
  $("showSystem").onchange = rerender;
  $("refreshBtn").onclick = refreshView;
  $("autoRefresh").onchange = startRefresh;

  async function start() {
    try {
      S.cfg = await fetch("/api/config").then((r) => r.json());
      $("version").textContent = "v" + S.cfg.version;
      if (S.cfg.auth_required && !S.token) return showLogin();
      S.me = await api("/api/me");
      await loadNamespaces();
      $("login").hidden = true; $("app").hidden = false; $("tabs").hidden = false; $("signOut").hidden = !S.cfg.auth_required;
      $("readOnlyNote").hidden = !S.cfg.read_only;
      $("whoami").hidden = !S.cfg.auth_required;
      $("whoami").textContent = `${S.me.name} · ${S.me.role}${S.me.namespaces.includes("*") ? "" : " · " + S.me.namespaces.join(", ")}`;
      $("whoami").title = S.me.namespaces.includes("*") ? "All namespaces" : "Namespaces: " + S.me.namespaces.join(", ");
      Object.entries({ newConfigMap: "config", newSecret: "secrets", newPvc: "storage", newPv: "cluster" })
        .forEach(([id, cap]) => { $(id).hidden = !can(cap); });
      $("usersTab").hidden = !(S.me.caps || []).includes("users");
      route(); startRefresh();
    } catch (e) {
      if (e.message !== "Sign in required") { $("clusterDot").className = "dot fail"; $("clusterText").textContent = "Dashboard API unreachable"; }
    }
  }
  start();
})();
