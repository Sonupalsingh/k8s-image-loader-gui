"""Shared helpers: Kubernetes clients, auth, write guards, audit log, validation."""
from __future__ import annotations

import asyncio
import datetime as dt
import hmac
from contextvars import ContextVar
import logging
import os
import re
from collections import deque

from fastapi import HTTPException, Request
from kubernetes import client, config
from kubernetes.client.rest import ApiException

log = logging.getLogger("dashboard")

DASHBOARD_TOKEN = os.getenv("DASHBOARD_TOKEN", "")
HIDE_NAMESPACES = {n for n in os.getenv("HIDE_NAMESPACES", "").split(",") if n}
PROTECTED_NAMESPACES = {n for n in os.getenv(
    "PROTECTED_NAMESPACES", "kube-system,kube-public,kube-node-lease,k8s-image-loader").split(",") if n}
READ_ONLY = os.getenv("READ_ONLY", "false").lower() == "true"
ANNOTATION_PREFIX = "image-loader.k8s.io"
AGENT_TOKEN = os.getenv("AGENT_TOKEN", "")
AGENT_NAMESPACE = os.getenv("AGENT_NAMESPACE", "k8s-image-loader")
AGENT_SELECTOR = os.getenv("AGENT_SELECTOR", "app.kubernetes.io/component=node-agent")
AGENT_PORT = int(os.getenv("AGENT_PORT", "8081"))

try:
    config.load_incluster_config()
except config.ConfigException:
    config.load_kube_config()

apps_api = client.AppsV1Api()
core_api = client.CoreV1Api()
storage_api = client.StorageV1Api()
autoscaling_api = client.AutoscalingV2Api()
batch_api = client.BatchV1Api()
api_client = client.ApiClient()


# --------------------------------------------------------------------------- basics
def k8s(fn, *args, **kwargs):
    """Run a blocking kubernetes-client call in a worker thread."""
    return asyncio.to_thread(fn, *args, **kwargs)


def to_dict(obj) -> dict:
    """Model -> plain dict with Kubernetes (camelCase) field names."""
    return api_client.sanitize_for_serialization(obj)


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def age_seconds(ts) -> int | None:
    if not ts:
        return None
    return int((dt.datetime.now(dt.timezone.utc) - ts).total_seconds())


# --------------------------------------------------------------------------- users, roles, scope
#
# Roles grant capabilities; a scope limits them to some namespaces or the whole cluster.
#   deploy  - image updates, restart, scale, rollback, push images, apply workload YAML
#   config  - config maps, volumes and env of workloads
#   storage - persistent volume claims
#   secrets - read and change secret values
#   cluster - persistent volumes, storage classes, node setup, registry cleanup (all-namespace scope only)
#   users   - manage dashboard users (all-namespace scope only)
ROLES = {
    "viewer":   set(),
    "deployer": {"deploy"},
    "editor":   {"deploy", "config", "storage"},
    "admin":    {"deploy", "config", "storage", "secrets", "cluster", "users"},
}
CLUSTER_CAPS = {"cluster", "users"}
CAP_TEXT = {"deploy": "deploy", "config": "change configuration", "storage": "change storage",
            "secrets": "use secrets", "cluster": "change cluster-wide settings", "users": "manage users"}


class User:
    def __init__(self, name: str, role: str, namespaces: list[str] | None, builtin: bool = False):
        self.name, self.role, self.builtin = name, role, builtin
        self.namespaces = None if not namespaces or "*" in namespaces else sorted(set(namespaces))  # None = all

    @property
    def all_namespaces(self) -> bool:
        return self.namespaces is None

    def caps(self) -> set[str]:
        caps = set(ROLES.get(self.role, set()))
        return caps if self.all_namespaces else caps - CLUSTER_CAPS

    def in_scope(self, namespace: str) -> bool:
        return self.all_namespaces or namespace in self.namespaces

    def public(self) -> dict:
        return {"name": self.name, "role": self.role, "builtin": self.builtin,
                "namespaces": ["*"] if self.all_namespaces else self.namespaces, "caps": sorted(self.caps())}


ADMIN = User("admin", "admin", ["*"], builtin=True)
CURRENT_USER: ContextVar[User] = ContextVar("current_user", default=ADMIN)


def user() -> User:
    return CURRENT_USER.get()


async def require_auth(request: Request) -> None:
    """Resolve the caller from its bearer token (async, so the user stays set for the request)."""
    if not DASHBOARD_TOKEN:
        CURRENT_USER.set(ADMIN)             # authentication switched off
        return
    header = request.headers.get("authorization", "")
    token = header[7:] if header.lower().startswith("bearer ") else ""
    if token and hmac.compare_digest(token, DASHBOARD_TOKEN):
        CURRENT_USER.set(ADMIN)
        return
    import users                             # late import: users imports common
    u = await users.authenticate(token) if token else None
    if not u:
        raise HTTPException(status_code=401, detail="Sign in with your dashboard access token.")
    CURRENT_USER.set(u)
    # Any request that names a namespace must be inside the user's scope
    ns = request.path_params.get("namespace") or request.query_params.get("namespace")
    if ns and not u.in_scope(ns):
        raise HTTPException(403, f"You do not have access to namespace '{ns}'.")


def require(cap: str, namespace: str | None = None) -> User:
    u = user()
    if cap not in u.caps():
        extra = " It needs a user with all-namespace scope." if cap in CLUSTER_CAPS and cap in ROLES.get(u.role, set()) else ""
        raise HTTPException(403, f"Your role ({u.role}) cannot {CAP_TEXT.get(cap, cap)}.{extra} Ask an admin for access.")
    if namespace and not u.in_scope(namespace):
        raise HTTPException(403, f"You do not have access to namespace '{namespace}'.")
    return u


def require_write(namespace: str | None = None, cap: str = "deploy") -> None:
    if READ_ONLY:
        raise HTTPException(403, "The dashboard is in read-only mode (READ_ONLY=true).")
    if namespace and namespace in PROTECTED_NAMESPACES:
        raise HTTPException(403, f"Namespace '{namespace}' is protected. Change it with kubectl, "
                                 f"or remove it from PROTECTED_NAMESPACES.")
    require(cap, namespace)


def visible(namespace: str) -> bool:
    return namespace not in HIDE_NAMESPACES and user().in_scope(namespace)


# --------------------------------------------------------------------------- audit log
AUDIT: deque = deque(maxlen=300)


def audit(action: str, target: str, detail: str = "") -> None:
    who = user().name
    AUDIT.appendleft({"ts": now_iso(), "user": who, "action": action, "target": target, "detail": detail})
    log.info("AUDIT user=%s %s %s %s", who, action, target, detail)


# --------------------------------------------------------------------------- validation
DNS_SUBDOMAIN = re.compile(r"^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*$")
DNS_LABEL = re.compile(r"^[a-z0-9]([-a-z0-9]*[a-z0-9])?$")
CONFIG_KEY = re.compile(r"^[-._a-zA-Z0-9]+$")
QUANTITY = re.compile(r"^(\d+(?:\.\d+)?)(Ki|Mi|Gi|Ti|Pi|Ei|k|M|G|T|P|E)?$")
UNITS = {"Ki": 2**10, "Mi": 2**20, "Gi": 2**30, "Ti": 2**40, "Pi": 2**50, "Ei": 2**60,
         "k": 10**3, "M": 10**6, "G": 10**9, "T": 10**12, "P": 10**15, "E": 10**18, None: 1}


def check_name(value: str, what: str = "Name", label: bool = False) -> str:
    value = (value or "").strip()
    pattern, limit = (DNS_LABEL, 63) if label else (DNS_SUBDOMAIN, 253)
    if not value or len(value) > limit or not pattern.match(value):
        raise HTTPException(400, f"{what} '{value}' is invalid. Use lowercase letters, digits and '-', "
                                 f"starting and ending with a letter or digit (max {limit}).")
    return value


def check_keys(keys) -> None:
    for k in keys:
        if not k or len(k) > 253 or not CONFIG_KEY.match(k):
            raise HTTPException(400, f"Key '{k}' is invalid. Use letters, digits, '-', '_' and '.'.")


def parse_quantity(value: str) -> float:
    m = QUANTITY.match((value or "").strip())
    if not m:
        raise HTTPException(400, f"Size '{value}' is invalid. Use a value like 10Gi, 500Mi or 1Ti.")
    return float(m[1]) * UNITS[m[2]]


def check_abs_path(value: str, what: str) -> str:
    value = (value or "").strip()
    if not value.startswith("/") or ":" in value or "\0" in value or "/../" in f"{value}/":
        raise HTTPException(400, f"{what} must be an absolute path like /data (no ':' or '..').")
    return value


# --------------------------------------------------------------------------- deployments
def deployment_status(d) -> str:
    spec_replicas = d.spec.replicas if d.spec.replicas is not None else 1
    st = d.status
    conds = {c.type: c for c in (st.conditions or [])}
    prog = conds.get("Progressing")
    if prog and prog.status == "False":
        return "failed"
    if spec_replicas == 0:
        return "scaled-down"
    if (st.observed_generation or 0) < (d.metadata.generation or 0) or (st.updated_replicas or 0) < spec_replicas:
        return "progressing"
    if (st.available_replicas or 0) >= spec_replicas and (st.unavailable_replicas or 0) == 0:
        return "healthy"
    return "degraded"


def references(d) -> set[tuple[str, str]]:
    """Every ConfigMap, Secret and PVC a Deployment's pod template uses."""
    refs: set[tuple[str, str]] = set()
    spec = d.spec.template.spec
    for v in spec.volumes or []:
        if v.config_map:
            refs.add(("configmap", v.config_map.name))
        if v.secret:
            refs.add(("secret", v.secret.secret_name))
        if v.persistent_volume_claim:
            refs.add(("pvc", v.persistent_volume_claim.claim_name))
        if v.projected:
            for s in v.projected.sources or []:
                if s.config_map:
                    refs.add(("configmap", s.config_map.name))
                if s.secret:
                    refs.add(("secret", s.secret.name))
    for s in spec.image_pull_secrets or []:
        refs.add(("secret", s.name))
    for c in (spec.containers or []) + (spec.init_containers or []):
        for ef in c.env_from or []:
            if ef.config_map_ref:
                refs.add(("configmap", ef.config_map_ref.name))
            if ef.secret_ref:
                refs.add(("secret", ef.secret_ref.name))
        for e in c.env or []:
            vf = e.value_from
            if vf and vf.config_map_key_ref:
                refs.add(("configmap", vf.config_map_key_ref.name))
            if vf and vf.secret_key_ref:
                refs.add(("secret", vf.secret_key_ref.name))
    return refs


async def usage_map(namespace: str = "") -> dict[tuple[str, str, str], list[str]]:
    """{(namespace, kind, name): [deployment names]} for quick 'used by' lookups."""
    if namespace:
        res = await k8s(apps_api.list_namespaced_deployment, namespace)
    else:
        res = await k8s(apps_api.list_deployment_for_all_namespaces)
    usage: dict[tuple[str, str, str], list[str]] = {}
    for d in res.items:
        for kind, name in references(d):
            usage.setdefault((d.metadata.namespace, kind, name), []).append(d.metadata.name)
    return usage


async def restart_deployments(namespace: str, names: list[str], reason: str) -> list[str]:
    done = []
    patch = {"spec": {"template": {"metadata": {"annotations": {
        "kubectl.kubernetes.io/restartedAt": now_iso(),
        f"{ANNOTATION_PREFIX}/restart-reason": reason[:200]}}}}}
    for name in names:
        await k8s(apps_api.patch_namespaced_deployment, name, namespace, patch)
        done.append(name)
    if done:
        audit("restart", f"deployments/{namespace}", f"{', '.join(done)} ({reason})")
    return done


async def mutate_pod_spec(namespace: str, name: str, fn) -> None:
    """Read a Deployment, let `fn` edit its pod spec dict, write it back atomically.

    A JSON-patch `test` on resourceVersion makes the write fail instead of
    overwriting someone else's change made in the meantime.
    """
    d = await k8s(apps_api.read_namespaced_deployment, name, namespace)
    spec = to_dict(d.spec.template.spec)
    fn(spec)
    ops = [
        {"op": "test", "path": "/metadata/resourceVersion", "value": d.metadata.resource_version},
        {"op": "replace", "path": "/spec/template/spec", "value": spec},
    ]
    try:
        await k8s(apps_api.patch_namespaced_deployment, name, namespace, ops)
    except ApiException as exc:
        if exc.status == 422 and "test" in (exc.body or ""):
            raise HTTPException(409, "The deployment changed while you were editing. Reload and try again.")
        raise


def fully_qualified(ref: str) -> str:
    """nginx:1 -> docker.io/library/nginx:1. CRI-O resolves short names through its search
    registries (often quay.io first), so deployments always get the full name."""
    first, _, rest = ref.partition("/")
    if not rest:
        return f"docker.io/library/{ref}"
    if "." not in first and ":" not in first and first != "localhost":
        return f"docker.io/{ref}"
    return ref


# --------------------------------------------------------------------------- node agents
def runtime_hint(runtime_version: str | None) -> str | None:
    """Node .status.nodeInfo.containerRuntimeVersion -> the runtime the kubelet uses.

    'cri-o://1.29.1' -> crio, 'containerd://1.7.20-k3s1' -> k3s, 'containerd://1.7.13' -> containerd
    """
    rv = (runtime_version or "").lower()
    if rv.startswith("cri-o"):
        return "crio"
    if rv.startswith("containerd"):
        return "k3s" if ("k3s" in rv or "rke2" in rv) else "containerd"
    if rv.startswith("docker"):
        return "docker"
    return None


async def node_runtime_hints() -> dict[str, str | None]:
    nodes = await k8s(core_api.list_node)
    return {n.metadata.name: runtime_hint(n.status.node_info.container_runtime_version if n.status.node_info else None)
            for n in nodes.items}

async def agent_url(node: str) -> str:
    """Base URL of the ready node agent on `node`, or a 409 explaining why there is none."""
    pods = await k8s(core_api.list_namespaced_pod, AGENT_NAMESPACE, label_selector=AGENT_SELECTOR)
    for p in pods.items:
        if p.spec.node_name != node:
            continue
        ready = any(x.type == "Ready" and x.status == "True" for x in (p.status.conditions or []))
        if ready and p.status.pod_ip:
            return f"http://{p.status.pod_ip}:{AGENT_PORT}"
    raise HTTPException(409, f"No ready node agent on {node}, so the directory cannot be created. "
                             f"Create it on the node yourself, or untick 'Create the directory'.")
