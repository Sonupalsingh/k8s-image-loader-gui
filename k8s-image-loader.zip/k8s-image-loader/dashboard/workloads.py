"""Deployment editing: replicas, storage (volumes + mounts), env from ConfigMap/Secret, node pinning."""
from __future__ import annotations

from typing import Literal

import re
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from kubernetes.client.rest import ApiException
from pydantic import BaseModel, Field

import common as c

router = APIRouter(dependencies=[Depends(c.require_auth)])

HOSTNAME_LABEL = "kubernetes.io/hostname"
HOST_PATH_TYPES = {"DirectoryOrCreate", "Directory", "FileOrCreate", "File", ""}
VOLUME_TYPES = ("persistentVolumeClaim", "hostPath", "emptyDir", "configMap", "secret", "projected",
                "nfs", "csi", "downwardAPI", "ephemeral", "local")


# --------------------------------------------------------------------------- serializers
def summarize_volume(v: dict) -> dict:
    vtype = next((t for t in VOLUME_TYPES if t in v), next((k for k in v if k != "name"), "unknown"))
    src = v.get(vtype) or {}
    source = {
        "persistentVolumeClaim": lambda: f"claim {src.get('claimName')}" + (" (read-only)" if src.get("readOnly") else ""),
        "hostPath": lambda: f"{src.get('path')} on the node" + (f" ({src['type']})" if src.get("type") else ""),
        "emptyDir": lambda: ("memory" if src.get("medium") == "Memory" else "node disk")
                            + (f", limit {src['sizeLimit']}" if src.get("sizeLimit") else "") + ", deleted with the pod",
        "configMap": lambda: f"config map {src.get('name')}",
        "secret": lambda: f"secret {src.get('secretName')}",
        "nfs": lambda: f"{src.get('server')}:{src.get('path')}",
        "csi": lambda: f"CSI {src.get('driver')}",
        "projected": lambda: "projected: " + ", ".join(
            next(iter(k for k in s), "?") for s in src.get("sources", [])),
    }.get(vtype, lambda: vtype)()
    return {"name": v.get("name"), "type": vtype, "source": source}


def pod_summary(p) -> dict:
    statuses = p.status.container_statuses or []
    reason = None
    for cs in statuses:
        if cs.state and cs.state.waiting and cs.state.waiting.reason:
            reason = cs.state.waiting.reason
        elif cs.state and cs.state.terminated and cs.state.terminated.reason:
            reason = cs.state.terminated.reason
    if p.metadata.deletion_timestamp:
        reason = "Terminating"
    return {
        "name": p.metadata.name,
        "node": p.spec.node_name,
        "phase": p.status.phase,
        "ready": sum(1 for cs in statuses if cs.ready),
        "containers": len(p.spec.containers),
        "restarts": sum(cs.restart_count or 0 for cs in statuses),
        "reason": reason,
        "age_seconds": c.age_seconds(p.metadata.creation_timestamp),
    }


# --------------------------------------------------------------------------- detail
@router.get("/api/deployments/{namespace}/{name}")
async def deployment_detail(namespace: str, name: str):
    d = await c.k8s(c.apps_api.read_namespaced_deployment, name, namespace)
    spec = c.to_dict(d.spec.template.spec)
    selector = ",".join(f"{k}={v}" for k, v in (d.spec.selector.match_labels or {}).items())
    pods = await c.k8s(c.core_api.list_namespaced_pod, namespace, label_selector=selector) if selector else None

    hpa = None
    try:
        h = await _find_hpa(namespace, name)
        hpa = _describe_hpa(h) if h else None
    except ApiException:
        pass  # autoscaling access not granted; not fatal
    no_cpu_request = [ct.name for ct in d.spec.template.spec.containers
                      if not ((ct.resources and ct.resources.requests) or {}).get("cpu")]

    return {
        "namespace": namespace,
        "name": name,
        "status": c.deployment_status(d),
        "replicas": d.spec.replicas if d.spec.replicas is not None else 1,
        "ready": d.status.ready_replicas or 0,
        "strategy": d.spec.strategy.type if d.spec.strategy else None,
        "protected": namespace in c.PROTECTED_NAMESPACES or c.READ_ONLY,
        "hpa": hpa,
        "autoscaling": {"metrics_available": await metrics_available(), "containers_without_cpu_request": no_cpu_request},
        "node_selector": spec.get("nodeSelector") or {},
        "pinned_node": (spec.get("nodeSelector") or {}).get(HOSTNAME_LABEL),
        "volumes": [summarize_volume(v) for v in spec.get("volumes") or []],
        "containers": [{
            "name": ct["name"],
            "image": ct.get("image"),
            "mounts": [{"volume": m["name"], "path": m["mountPath"], "sub_path": m.get("subPath"),
                        "read_only": bool(m.get("readOnly"))} for m in ct.get("volumeMounts") or []],
            "env_from": [{"kind": "configMap" if "configMapRef" in ef else "secret",
                          "name": (ef.get("configMapRef") or ef.get("secretRef") or {}).get("name"),
                          "prefix": ef.get("prefix")} for ef in ct.get("envFrom") or []],
            "env_count": len(ct.get("env") or []),
        } for ct in spec.get("containers") or []],
        "pods": [pod_summary(p) for p in (pods.items if pods else [])],
    }


# --------------------------------------------------------------------------- replicas
class ReplicasIn(BaseModel):
    replicas: int = Field(ge=0, le=500)


@router.put("/api/deployments/{namespace}/{name}/replicas")
async def scale(namespace: str, name: str, body: ReplicasIn):
    c.require_write(namespace)
    await c.k8s(c.apps_api.patch_namespaced_deployment_scale, name, namespace, {"spec": {"replicas": body.replicas}})
    c.audit("scale", f"deployment/{namespace}/{name}", f"replicas → {body.replicas}")
    return {"ok": True, "replicas": body.replicas}


# --------------------------------------------------------------------------- volumes
class MountIn(BaseModel):
    container: str
    mount_path: str
    sub_path: str = ""
    read_only: bool = False


class VolumeIn(BaseModel):
    name: str
    type: Literal["persistentVolumeClaim", "hostPath", "emptyDir", "configMap", "secret"]
    claim_name: str = ""
    path: str = ""
    host_path_type: str = "DirectoryOrCreate"
    medium: Literal["", "Memory"] = ""
    size_limit: str = ""
    source_name: str = ""
    pin_node: str = ""
    mounts: list[MountIn] = Field(min_length=1)


def build_volume(body: VolumeIn) -> dict:
    v: dict = {"name": body.name}
    if body.type == "persistentVolumeClaim":
        v["persistentVolumeClaim"] = {"claimName": c.check_name(body.claim_name, "Claim name")}
    elif body.type == "hostPath":
        if body.host_path_type not in HOST_PATH_TYPES:
            raise HTTPException(400, f"Unknown host path type '{body.host_path_type}'.")
        v["hostPath"] = {"path": c.check_abs_path(body.path, "Node path")}
        if body.host_path_type:
            v["hostPath"]["type"] = body.host_path_type
    elif body.type == "emptyDir":
        v["emptyDir"] = {}
        if body.medium:
            v["emptyDir"]["medium"] = body.medium
        if body.size_limit:
            c.parse_quantity(body.size_limit)
            v["emptyDir"]["sizeLimit"] = body.size_limit
    elif body.type == "configMap":
        v["configMap"] = {"name": c.check_name(body.source_name, "Config map")}
    elif body.type == "secret":
        v["secret"] = {"secretName": c.check_name(body.source_name, "Secret")}
    return v


@router.post("/api/deployments/{namespace}/{name}/volumes")
async def add_volume(namespace: str, name: str, body: VolumeIn):
    c.require_write(namespace, cap="config")
    c.check_name(body.name, "Volume name", label=True)
    volume = build_volume(body)
    warnings: list[str] = []

    if body.type == "persistentVolumeClaim":
        pvc = await c.k8s(c.core_api.read_namespaced_persistent_volume_claim, body.claim_name, namespace)
        d = await c.k8s(c.apps_api.read_namespaced_deployment, name, namespace)
        modes = pvc.spec.access_modes or []
        if (d.spec.replicas or 1) > 1 and "ReadWriteMany" not in modes and "ReadOnlyMany" not in modes:
            warnings.append("This claim is ReadWriteOnce: all pods must run on the same node, and pods on "
                            "other nodes will stay Pending. Use 1 replica or a ReadWriteMany claim.")
    if body.type == "hostPath" and not body.pin_node:
        warnings.append("Data on a node path stays on that node. Without pinning, a pod moved to another "
                        "node sees an empty directory.")

    def mutate(spec: dict):
        if any(v["name"] == body.name for v in spec.get("volumes") or []):
            raise HTTPException(409, f"A volume named '{body.name}' already exists.")
        containers = {ct["name"]: ct for ct in spec["containers"]}
        for m in body.mounts:
            ct = containers.get(m.container)
            if not ct:
                raise HTTPException(400, f"Container '{m.container}' not found.")
            path = c.check_abs_path(m.mount_path, "Mount path")
            if any(x["mountPath"] == path for x in ct.get("volumeMounts") or []):
                raise HTTPException(409, f"Container '{m.container}' already has something mounted at {path}.")
            mount = {"name": body.name, "mountPath": path}
            if m.sub_path:
                mount["subPath"] = m.sub_path.strip("/")
            if m.read_only:
                mount["readOnly"] = True
            ct.setdefault("volumeMounts", []).append(mount)
        spec.setdefault("volumes", []).append(volume)
        if body.pin_node:
            spec.setdefault("nodeSelector", {})[HOSTNAME_LABEL] = body.pin_node

    await c.mutate_pod_spec(namespace, name, mutate)
    where = ", ".join(f"{m.container}:{m.mount_path}" for m in body.mounts)
    c.audit("volume-add", f"deployment/{namespace}/{name}", f"{body.name} ({body.type}) at {where}")
    return {"ok": True, "warnings": warnings}


@router.delete("/api/deployments/{namespace}/{name}/volumes/{volume}")
async def remove_volume(namespace: str, name: str, volume: str):
    c.require_write(namespace, cap="config")

    def mutate(spec: dict):
        before = len(spec.get("volumes") or [])
        spec["volumes"] = [v for v in spec.get("volumes") or [] if v["name"] != volume]
        if len(spec["volumes"]) == before:
            raise HTTPException(404, f"Volume '{volume}' not found.")
        for ct in (spec.get("containers") or []) + (spec.get("initContainers") or []):
            if ct.get("volumeMounts"):
                ct["volumeMounts"] = [m for m in ct["volumeMounts"] if m["name"] != volume]

    await c.mutate_pod_spec(namespace, name, mutate)
    c.audit("volume-remove", f"deployment/{namespace}/{name}", volume)
    return {"ok": True}


@router.delete("/api/deployments/{namespace}/{name}/node-pin")
async def unpin_node(namespace: str, name: str):
    c.require_write(namespace, cap="config")

    def mutate(spec: dict):
        (spec.get("nodeSelector") or {}).pop(HOSTNAME_LABEL, None)

    await c.mutate_pod_spec(namespace, name, mutate)
    c.audit("unpin", f"deployment/{namespace}/{name}")
    return {"ok": True}


# --------------------------------------------------------------------------- env from
class EnvFromIn(BaseModel):
    container: str
    kind: Literal["configMap", "secret"]
    name: str
    prefix: str = ""


def _env_key(kind: str) -> str:
    return "configMapRef" if kind == "configMap" else "secretRef"


@router.post("/api/deployments/{namespace}/{name}/env-from")
async def add_env_from(namespace: str, name: str, body: EnvFromIn):
    c.require_write(namespace, cap="config")
    c.check_name(body.name)

    def mutate(spec: dict):
        ct = next((x for x in spec["containers"] if x["name"] == body.container), None)
        if not ct:
            raise HTTPException(400, f"Container '{body.container}' not found.")
        key = _env_key(body.kind)
        if any((ef.get(key) or {}).get("name") == body.name for ef in ct.get("envFrom") or []):
            raise HTTPException(409, f"{body.container} already loads environment from {body.name}.")
        entry = {key: {"name": body.name}}
        if body.prefix:
            entry["prefix"] = body.prefix
        ct.setdefault("envFrom", []).append(entry)

    await c.mutate_pod_spec(namespace, name, mutate)
    c.audit("env-add", f"deployment/{namespace}/{name}", f"{body.container} ← {body.kind} {body.name}")
    return {"ok": True}


@router.delete("/api/deployments/{namespace}/{name}/env-from")
async def remove_env_from(namespace: str, name: str, container: str, kind: Literal["configMap", "secret"], source: str):
    c.require_write(namespace, cap="config")

    def mutate(spec: dict):
        ct = next((x for x in spec["containers"] if x["name"] == container), None)
        if not ct:
            raise HTTPException(400, f"Container '{container}' not found.")
        key = _env_key(kind)
        ct["envFrom"] = [ef for ef in ct.get("envFrom") or [] if (ef.get(key) or {}).get("name") != source]

    await c.mutate_pod_spec(namespace, name, mutate)
    c.audit("env-remove", f"deployment/{namespace}/{name}", f"{container} ← {kind} {source}")
    return {"ok": True}


# --------------------------------------------------------------------------- autoscaling (HPA)
_metrics = {"at": 0.0, "ok": None}


async def metrics_available() -> bool:
    """Is metrics-server (metrics.k8s.io) serving? Without it an HPA cannot read CPU or memory."""
    import time
    if _metrics["ok"] is not None and time.monotonic() - _metrics["at"] < 60:
        return _metrics["ok"]
    try:
        await c.k8s(c.api_client.call_api, "/apis/metrics.k8s.io/v1beta1", "GET",
                    auth_settings=["BearerToken"], response_type="object", _return_http_data_only=True)
        ok = True
    except ApiException:
        ok = False
    _metrics.update(at=time.monotonic(), ok=ok)
    return ok


async def _find_hpa(namespace: str, name: str):
    hpas = await c.k8s(c.autoscaling_api.list_namespaced_horizontal_pod_autoscaler, namespace)
    return next((h for h in hpas.items if h.spec.scale_target_ref.kind == "Deployment"
                 and h.spec.scale_target_ref.name == name), None)


def _describe_hpa(h) -> dict:
    targets, current = {}, {}
    for m in h.spec.metrics or []:
        if m.type == "Resource" and m.resource.target.type == "Utilization":
            targets[m.resource.name] = m.resource.target.average_utilization
    for m in (h.status.current_metrics or []) if h.status else []:
        if m.type == "Resource" and m.resource.current:
            current[m.resource.name] = m.resource.current.average_utilization
    conds = [{"type": x.type, "status": x.status, "reason": x.reason, "message": x.message}
             for x in (h.status.conditions or [])] if h.status else []
    problem = next((x for x in conds if x["status"] == "False" and x["type"] in ("AbleToScale", "ScalingActive")), None)
    return {"name": h.metadata.name, "min": h.spec.min_replicas or 1, "max": h.spec.max_replicas,
            "cpu": targets.get("cpu"), "memory": targets.get("memory"),
            "current_cpu": current.get("cpu"), "current_memory": current.get("memory"),
            "current_replicas": h.status.current_replicas if h.status else None,
            "desired_replicas": h.status.desired_replicas if h.status else None,
            "problem": problem, "conditions": conds,
            "managed_by_dashboard": (h.metadata.labels or {}).get("app.kubernetes.io/managed-by") == "k8s-image-loader"}


class AutoscaleIn(BaseModel):
    min_replicas: int = Field(1, ge=1, le=500)
    max_replicas: int = Field(..., ge=1, le=500)
    cpu_percent: Optional[int] = Field(70, ge=1, le=1000)
    memory_percent: Optional[int] = Field(None, ge=1, le=1000)
    set_cpu_request: Optional[str] = None      # e.g. "100m" for containers that have no CPU request


@router.put("/api/deployments/{namespace}/{name}/autoscaling")
async def set_autoscaling(namespace: str, name: str, body: AutoscaleIn):
    """Turn autoscaling on, or change it: an autoscaling/v2 HPA for this deployment."""
    c.require_write(namespace)
    if body.max_replicas < body.min_replicas:
        raise HTTPException(400, "Maximum pods must be at least the minimum.")
    if not body.cpu_percent and not body.memory_percent:
        raise HTTPException(400, "Choose a CPU or memory target.")
    d = await c.k8s(c.apps_api.read_namespaced_deployment, name, namespace)

    if body.set_cpu_request:
        if not re.fullmatch(r"\d+m|\d+(\.\d+)?", body.set_cpu_request):
            raise HTTPException(400, "CPU request must look like 100m or 0.5.")
        missing = [ct.name for ct in d.spec.template.spec.containers
                   if not ((ct.resources and ct.resources.requests) or {}).get("cpu")]
        if missing:
            patch = {"spec": {"template": {"spec": {"containers": [
                {"name": n, "resources": {"requests": {"cpu": body.set_cpu_request}}} for n in missing]}}}}
            await c.k8s(c.apps_api.patch_namespaced_deployment, name, namespace, patch)
            c.audit("resources", f"deployment/{namespace}/{name}", f"CPU request {body.set_cpu_request} for {', '.join(missing)}")

    metrics = []
    if body.cpu_percent:
        metrics.append({"type": "Resource", "resource": {"name": "cpu", "target": {"type": "Utilization", "averageUtilization": body.cpu_percent}}})
    if body.memory_percent:
        metrics.append({"type": "Resource", "resource": {"name": "memory", "target": {"type": "Utilization", "averageUtilization": body.memory_percent}}})
    existing = await _find_hpa(namespace, name)
    hpa = {"apiVersion": "autoscaling/v2", "kind": "HorizontalPodAutoscaler",
           "metadata": {"name": existing.metadata.name if existing else name, "namespace": namespace,
                        "labels": {"app.kubernetes.io/managed-by": "k8s-image-loader"}},
           "spec": {"scaleTargetRef": {"apiVersion": "apps/v1", "kind": "Deployment", "name": name},
                    "minReplicas": body.min_replicas, "maxReplicas": body.max_replicas, "metrics": metrics}}
    if existing:
        hpa["metadata"]["resourceVersion"] = existing.metadata.resource_version
        await c.k8s(c.autoscaling_api.replace_namespaced_horizontal_pod_autoscaler, existing.metadata.name, namespace, hpa)
    else:
        await c.k8s(c.autoscaling_api.create_namespaced_horizontal_pod_autoscaler, namespace, hpa)
    target = ", ".join(x for x in (f"CPU {body.cpu_percent}%" if body.cpu_percent else "",
                                  f"memory {body.memory_percent}%" if body.memory_percent else "") if x)
    c.audit("autoscale-on" if not existing else "autoscale-change", f"deployment/{namespace}/{name}",
            f"{body.min_replicas}-{body.max_replicas} pods, target {target}")
    return {"ok": True, "hpa": _describe_hpa(await _find_hpa(namespace, name))}


@router.delete("/api/deployments/{namespace}/{name}/autoscaling")
async def remove_autoscaling(namespace: str, name: str):
    """Turn autoscaling off. The deployment keeps its current number of pods."""
    c.require_write(namespace)
    h = await _find_hpa(namespace, name)
    if not h:
        raise HTTPException(404, "Autoscaling is not on for this deployment.")
    await c.k8s(c.autoscaling_api.delete_namespaced_horizontal_pod_autoscaler, h.metadata.name, namespace)
    c.audit("autoscale-off", f"deployment/{namespace}/{name}", f"removed {h.metadata.name}")
    return {"ok": True}


# --------------------------------------------------------------------------- delete a deployment
async def _delete_plan(namespace: str, name: str) -> dict:
    d = await c.k8s(c.apps_api.read_namespaced_deployment, name, namespace)
    labels = (d.spec.template.metadata.labels or {}) if d.spec.template.metadata else {}
    others = [x for x in (await c.k8s(c.apps_api.list_namespaced_deployment, namespace)).items if x.metadata.name != name]
    services = []
    for s in (await c.k8s(c.core_api.list_namespaced_service, namespace)).items:
        sel = s.spec.selector or {}
        if not sel or not all(labels.get(k) == v for k, v in sel.items()):
            continue                              # does not point at this deployment's pods
        shared_with = [o.metadata.name for o in others
                       if all(((o.spec.template.metadata.labels or {}) if o.spec.template.metadata else {}).get(k) == v
                              for k, v in sel.items())]
        services.append({"name": s.metadata.name, "shared_with": shared_with})
    hpa = await _find_hpa(namespace, name)
    claims = sorted({v.persistent_volume_claim.claim_name for v in (d.spec.template.spec.volumes or [])
                     if v.persistent_volume_claim})
    return {"deployment": d, "services": services, "hpa": hpa.metadata.name if hpa else None, "claims": claims,
            "replicas": d.spec.replicas if d.spec.replicas is not None else 1}


@router.get("/api/deployments/{namespace}/{name}/delete-preview")
async def delete_preview(namespace: str, name: str):
    p = await _delete_plan(namespace, name)
    return {k: p[k] for k in ("services", "hpa", "claims", "replicas")}


@router.delete("/api/deployments/{namespace}/{name}")
async def delete_deployment(namespace: str, name: str, delete_services: bool = False):
    """Delete a deployment (its pods stop), its autoscaler, and optionally its own Services.
    Storage claims are never deleted: they hold data."""
    c.require_write(namespace, cap="config")
    p = await _delete_plan(namespace, name)
    deleted = []
    if p["hpa"]:
        await c.k8s(c.autoscaling_api.delete_namespaced_horizontal_pod_autoscaler, p["hpa"], namespace)
        deleted.append(f"autoscaler {p['hpa']}")
    await c.k8s(c.apps_api.delete_namespaced_deployment, name, namespace,
                body={"propagationPolicy": "Background"})
    deleted.append(f"deployment {name}")
    kept = []
    for s in p["services"]:
        if delete_services and not s["shared_with"]:
            await c.k8s(c.core_api.delete_namespaced_service, s["name"], namespace)
            deleted.append(f"service {s['name']}")
        else:
            kept.append(s["name"])
    c.audit("delete", f"deployment/{namespace}/{name}", "; ".join(deleted[:-1] + deleted[-1:])
            + (f"; kept services {', '.join(kept)}" if kept else "") + (f"; kept claims {', '.join(p['claims'])}" if p["claims"] else ""))
    return {"ok": True, "deleted": deleted, "kept_services": kept, "kept_claims": p["claims"]}
