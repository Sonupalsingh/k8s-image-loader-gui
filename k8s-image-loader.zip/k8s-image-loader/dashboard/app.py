"""
k8s-image-loader dashboard.

  * Lists every Deployment in the cluster (or selected namespace).
  * Accepts an image tarball (docker save / OCI archive, optionally gzipped).
  * Streams the archive to the node agent on every node, which imports it into
    containerd or CRI-O.
  * Patches the Deployment to the new image (imagePullPolicy IfNotPresent/Never)
    and follows the rollout until it is complete, failed or timed out.
"""
from __future__ import annotations

import asyncio
import datetime as dt
import gzip
import json
import logging
import os
import re
import shutil
import tarfile
import time
import uuid
from collections import OrderedDict
from pathlib import Path

import httpx
from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from kubernetes.client.rest import ApiException
from pydantic import BaseModel

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

import common as c  # noqa: E402  (loads kube config)
import config_api  # noqa: E402
import storage  # noqa: E402
import manifests  # noqa: E402
import registry  # noqa: E402
import users  # noqa: E402
import nodeimages  # noqa: E402
import workloads  # noqa: E402
from common import ANNOTATION_PREFIX, age_seconds, deployment_status, k8s, now_iso, require_auth  # noqa: E402

VERSION = "1.6.0"

AGENT_TOKEN, AGENT_NAMESPACE, AGENT_SELECTOR, AGENT_PORT = c.AGENT_TOKEN, c.AGENT_NAMESPACE, c.AGENT_SELECTOR, c.AGENT_PORT
UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", "/data"))
ROLLOUT_TIMEOUT = int(os.getenv("ROLLOUT_TIMEOUT_SECONDS", "600"))
AGENT_TIMEOUT = int(os.getenv("AGENT_TIMEOUT_SECONDS", "1800"))
MAX_JOBS = 50
CHUNK = 1024 * 1024

log = logging.getLogger("dashboard")

app = FastAPI(title="k8s-image-loader", version=VERSION)
STATIC = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=STATIC), name="static")
app.include_router(workloads.router)
app.include_router(config_api.router)
app.include_router(storage.router)
app.include_router(registry.router)
app.include_router(manifests.router)
app.include_router(users.router)
app.include_router(nodeimages.router)

JOBS: "OrderedDict[str, dict]" = OrderedDict()
DEPLOY_LOCKS: dict[str, asyncio.Lock] = {}
BACKGROUND: set[asyncio.Task] = set()   # keep references so tasks are not GC'd


@app.exception_handler(ApiException)
async def kubernetes_error(request: Request, exc: ApiException):
    """Turn Kubernetes API errors into readable messages for the UI."""
    message = exc.reason or "Kubernetes API error"
    try:
        message = json.loads(exc.body).get("message", message)
    except Exception:  # noqa: BLE001
        pass
    if exc.status == 409:
        message = f"Conflict: {message}. It was changed by someone else; reload and try again."
    status = exc.status if exc.status and 400 <= exc.status < 600 else 502
    return JSONResponse(status_code=status, content={"detail": message})


# --------------------------------------------------------------------------- image refs
REF_RE = re.compile(r"^[a-z0-9]+(?:[._\-/:][a-zA-Z0-9]+)*(?::[\w][\w.\-]{0,127})?$", re.I)


def split_ref(ref: str) -> tuple[str, str | None]:
    """Return (repository, tag). Handles registry ports like host:5000/app:v1."""
    last_slash = ref.rfind("/")
    colon = ref.rfind(":")
    if colon > last_slash:
        return ref[:colon], ref[colon + 1:]
    return ref, None


def with_unique_tag(ref: str) -> str:
    repo, tag = split_ref(ref)
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d%H%M%S")
    base = tag if tag and tag != "latest" else "build"
    return f"{repo}:{base}-{stamp}"


# --------------------------------------------------------------------------- archive inspection
def prepare_archive(path: Path) -> Path:
    """Decompress gzip archives so every runtime tool can read them."""
    with path.open("rb") as fh:
        magic = fh.read(2)
    if magic != b"\x1f\x8b":
        return path
    plain = path.with_suffix(".tar")
    with gzip.open(path, "rb") as src, plain.open("wb") as dst:
        shutil.copyfileobj(src, dst, CHUNK)
    path.unlink(missing_ok=True)
    return plain


def inspect_archive(path: Path) -> dict:
    try:
        with tarfile.open(path, "r:") as tf:
            members = {m.name.lstrip("./"): m for m in tf.getmembers()}
            if "manifest.json" in members:
                manifest = json.load(tf.extractfile(members["manifest.json"]))
                tags = [t for entry in manifest for t in (entry.get("RepoTags") or [])]
                return {"format": "docker", "tags": tags, "images": len(manifest)}
            if "index.json" in members:
                index = json.load(tf.extractfile(members["index.json"]))
                tags = []
                for m in index.get("manifests", []):
                    ann = m.get("annotations") or {}
                    name = ann.get("io.containerd.image.name") or ann.get("org.opencontainers.image.ref.name")
                    if name and ("/" in name or ":" in name):
                        tags.append(name)
                return {"format": "oci", "tags": tags, "images": len(index.get("manifests", []))}
    except tarfile.TarError as exc:
        raise ValueError(f"The file is not a valid tar archive ({exc}).") from exc
    raise ValueError("The archive has no manifest.json or index.json. Create it with `docker save`, "
                     "`podman save` or `ctr images export`.")


# --------------------------------------------------------------------------- serializers
def serialize_deployment(d) -> dict:
    meta = d.spec.template.metadata
    ann = (meta.annotations if meta else None) or {}
    return {
        "namespace": d.metadata.namespace,
        "name": d.metadata.name,
        "status": deployment_status(d),
        "replicas": d.spec.replicas if d.spec.replicas is not None else 1,
        "ready": d.status.ready_replicas or 0,
        "updated": d.status.updated_replicas or 0,
        "available": d.status.available_replicas or 0,
        "age_seconds": age_seconds(d.metadata.creation_timestamp),
        "revision": (d.metadata.annotations or {}).get("deployment.kubernetes.io/revision"),
        "containers": [
            {"name": c.name, "image": c.image, "pull_policy": c.image_pull_policy}
            for c in d.spec.template.spec.containers
        ],
        "protected": d.metadata.namespace in c.PROTECTED_NAMESPACES or c.READ_ONLY,
        "last_loaded": {
            "image": ann.get(f"{ANNOTATION_PREFIX}/image"),
            "at": ann.get(f"{ANNOTATION_PREFIX}/loaded-at"),
        },
    }


# --------------------------------------------------------------------------- agents
async def list_agents() -> dict:
    pods, nodes = await asyncio.gather(
        k8s(c.core_api.list_namespaced_pod, AGENT_NAMESPACE, label_selector=AGENT_SELECTOR),
        k8s(c.core_api.list_node),
    )
    by_node = {}
    for p in pods.items:
        ready = any(c.type == "Ready" and c.status == "True" for c in (p.status.conditions or []))
        if p.spec.node_name:
            by_node[p.spec.node_name] = {"pod": p.metadata.name, "ip": p.status.pod_ip, "ready": ready}

    result = []
    for n in nodes.items:
        node_ready = any(c.type == "Ready" and c.status == "True" for c in (n.status.conditions or []))
        info = n.status.node_info
        agent = by_node.get(n.metadata.name)
        result.append({
            "node": n.metadata.name,
            "node_ready": node_ready,
            "schedulable": not n.spec.unschedulable,
            "runtime": info.container_runtime_version if info else None,
            "kubelet": info.kubelet_version if info else None,
            "agent": agent,
        })
    return {"nodes": result}


async def send_to_agent(http: httpx.AsyncClient, job: dict, node: str, ip: str,
                        archive: Path, fmt: str, source: str | None, target: str, hint: str | None = None) -> bool:
    ns = job["nodes"][node]
    ns.update(state="loading", started=now_iso())
    sent = 0
    size = archive.stat().st_size

    async def body():
        nonlocal sent
        with archive.open("rb") as fh:
            while True:
                chunk = await asyncio.to_thread(fh.read, CHUNK)
                if not chunk:
                    break
                sent += len(chunk)
                ns["progress"] = round(sent / size * 100, 1) if size else 100
                yield chunk

    headers = {"x-target-image": target, "x-archive-format": fmt, "x-agent-token": AGENT_TOKEN,
               "x-node-runtime": hint or "",
               "content-type": "application/x-tar", "content-length": str(size)}
    if source:
        headers["x-source-ref"] = source
    try:
        resp = await http.post(f"http://{ip}:{AGENT_PORT}/load", content=body(), headers=headers)
        data = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
        if resp.status_code != 200:
            raise RuntimeError(data.get("detail") or resp.text[:500])
        ns.update(state="loaded", runtime=data.get("runtime"), seconds=data.get("total_seconds"), progress=100)
        log_step(job, f"{node}: loaded into {data.get('runtime')} in {data.get('total_seconds')}s")
        return True
    except Exception as exc:  # noqa: BLE001
        ns.update(state="failed", error=str(exc))
        log_step(job, f"{node}: {exc}", "error")
        return False


# --------------------------------------------------------------------------- jobs
MODES = {
    # direct: load the tar onto every node through the node agents (no registry needed)
    "nodes": [("inspect", "Inspect archive"), ("distribute", "Load on nodes"), ("patch", "Update deployment"),
              ("rollout", "Roll out pods"), ("done", "Complete")],
    # push the tar to the local registry, then point the deployment at it
    "registry": [("inspect", "Inspect archive"), ("push", "Push to registry"), ("patch", "Update deployment"),
                 ("rollout", "Roll out pods"), ("done", "Complete")],
    # only push the tar to the registry (Images tab)
    "push": [("inspect", "Inspect archive"), ("push", "Push to registry"), ("done", "Complete")],
    # use an image that is already in the registry
    "ref": [("patch", "Update deployment"), ("rollout", "Roll out pods"), ("done", "Complete")],
    # only load the tar onto every node (containerd: ctr, CRI-O: skopeo); used by Apply YAML
    "load": [("inspect", "Inspect archive"), ("distribute", "Load on nodes"), ("done", "Complete")],
}


def new_job(namespace: str | None, name: str | None, container: str | None, filename: str | None,
            mode: str = "nodes") -> dict:
    job = {
        "id": uuid.uuid4().hex[:12],
        "mode": mode,
        "stages": MODES[mode],
        "namespace": namespace,
        "deployment": name,
        "container": container,
        "filename": filename,
        "state": "running",
        "stage": MODES[mode][0][0],
        "created": now_iso(),
        "finished": None,
        "target_image": None,
        "previous_image": None,
        "pushed": [],
        "user": c.user().name,
        "nodes": {},
        "rollout": {},
        "log": [],
    }
    JOBS[job["id"]] = job
    while len(JOBS) > MAX_JOBS:
        JOBS.popitem(last=False)
    return job


def log_step(job: dict, msg: str, level: str = "info") -> None:
    job["log"].append({"ts": now_iso(), "level": level, "msg": msg})
    getattr(log, "error" if level == "error" else "info")("[job %s] %s", job["id"], msg)


def finish(job: dict, state: str, msg: str) -> None:
    job["state"] = state
    job["finished"] = now_iso()
    log_step(job, msg, "error" if state == "failed" else "info")


async def wait_for_rollout(job: dict, namespace: str, name: str) -> bool:
    deadline = time.monotonic() + ROLLOUT_TIMEOUT
    reported: set[str] = set()
    fatal = {"ErrImageNeverPull", "ErrImagePull", "ImagePullBackOff", "InvalidImageName", "CreateContainerConfigError"}
    while time.monotonic() < deadline:
        d = await k8s(c.apps_api.read_namespaced_deployment, name, namespace)
        want = d.spec.replicas if d.spec.replicas is not None else 1
        st = d.status
        job["rollout"] = {"desired": want, "updated": st.updated_replicas or 0,
                          "ready": st.ready_replicas or 0, "available": st.available_replicas or 0}

        conds = {c.type: c for c in (st.conditions or [])}
        prog = conds.get("Progressing")
        if prog and prog.reason == "ProgressDeadlineExceeded":
            log_step(job, f"Rollout exceeded its progress deadline: {prog.message}", "error")
            return False

        done = ((st.observed_generation or 0) >= d.metadata.generation
                and (st.updated_replicas or 0) == want
                and (st.replicas or 0) == want
                and (st.available_replicas or 0) == want)
        if done:
            return True

        selector = ",".join(f"{k}={v}" for k, v in (d.spec.selector.match_labels or {}).items())
        if selector:
            pods = await k8s(c.core_api.list_namespaced_pod, namespace, label_selector=selector)
            for p in pods.items:
                for cs in (p.status.container_statuses or []):
                    w = cs.state.waiting if cs.state else None
                    if w and w.reason and w.reason not in ("ContainerCreating", "PodInitializing"):
                        key = f"{p.metadata.name}/{w.reason}"
                        if key not in reported:
                            reported.add(key)
                            log_step(job, f"Pod {p.metadata.name} ({p.spec.node_name}): {w.reason} "
                                          f"{(w.message or '')[:300]}", "error" if w.reason in fatal else "warn")
        await asyncio.sleep(3)
    log_step(job, f"Rollout did not finish within {ROLLOUT_TIMEOUT}s.", "error")
    return False


fully_qualified = c.fully_qualified


def resolve_target(requested: str, unique_tag: bool, to_registry: bool) -> str:
    target = requested.strip()
    if "@" in target or not REF_RE.match(target):
        raise ValueError(f"'{target}' is not a valid image reference.")
    if split_ref(target)[1] is None:
        target += ":latest"
    target = registry.node_ref(target) if to_registry else fully_qualified(target)
    if unique_tag:
        target = with_unique_tag(target)
    return target


async def distribute(job: dict, archive: Path, info: dict, source: str | None, target: str) -> bool:
    agents = (await list_agents())["nodes"]
    targets = [a for a in agents if a["agent"] and a["agent"]["ready"] and a["agent"]["ip"]]
    missing = [a["node"] for a in agents if a not in targets and a["node_ready"]]
    if missing:
        log_step(job, f"No ready agent on: {', '.join(missing)}. Pods scheduled there cannot start.", "warn")
    if not targets:
        finish(job, "failed", "No node agents are ready. Check the node-agent DaemonSet.")
        return False
    for a in targets:
        job["nodes"][a["node"]] = {"state": "queued", "progress": 0}
    async with httpx.AsyncClient(timeout=httpx.Timeout(AGENT_TIMEOUT, connect=10)) as http:
        results = await asyncio.gather(*[
            send_to_agent(http, job, a["node"], a["agent"]["ip"], archive, info["format"], source, target,
                          c.runtime_hint(a["runtime"]))
            for a in targets])
    if not all(results):
        failed = [n for n, s in job["nodes"].items() if s["state"] == "failed"]
        finish(job, "failed", f"Image load failed on {', '.join(failed)}. The deployment was not changed.")
        return False
    return True


async def push_images(job: dict, archive: Path, info: dict, pairs: list[tuple[str | None, str]]) -> bool:
    multi = info["images"] > 1
    for source, dest in pairs:
        log_step(job, f"Pushing {source or 'image'} → {dest}")
        started = time.monotonic()
        try:
            digest = await registry.push(archive, info["format"], source, dest, multi)
        except RuntimeError as exc:
            finish(job, "failed", f"{exc}. The deployment was not changed." if job["deployment"] else str(exc))
            return False
        job["pushed"].append({"image": dest, "digest": digest})
        log_step(job, f"Pushed {dest} ({digest[:19]}…) in {time.monotonic() - started:.1f}s")
        c.audit("push", f"image/{dest}", digest)
    return True


async def patch_and_rollout(job: dict, target: str, pull_policy: str) -> None:
    ns, name, container = job["namespace"], job["deployment"], job["container"]
    job["stage"] = "patch"
    d = await k8s(c.apps_api.read_namespaced_deployment, name, ns)
    current = next((x for x in d.spec.template.spec.containers if x.name == container), None)
    if not current:
        return finish(job, "failed", f"Container '{container}' no longer exists in {ns}/{name}.")
    job["previous_image"] = current.image
    patch = {"spec": {"template": {
        "metadata": {"annotations": {
            f"{ANNOTATION_PREFIX}/image": target,
            f"{ANNOTATION_PREFIX}/loaded-at": now_iso(),
            f"{ANNOTATION_PREFIX}/job": job["id"],
            "kubectl.kubernetes.io/restartedAt": now_iso(),
        }},
        "spec": {"containers": [{"name": container, "image": target, "imagePullPolicy": pull_policy}]},
    }}}
    await k8s(c.apps_api.patch_namespaced_deployment, name, ns, patch)
    log_step(job, f"Patched {ns}/{name}: {container} {current.image} → {target} (pullPolicy {pull_policy})")
    c.audit("image", f"deployment/{ns}/{name}", f"{container}: {current.image} → {target}")

    job["stage"] = "rollout"
    if await wait_for_rollout(job, ns, name):
        job["stage"] = "done"
        finish(job, "succeeded", f"Rollout complete. {ns}/{name} is running {target}.")
    else:
        finish(job, "failed", "Rollout did not complete. Use Roll back to restore the previous image.")


async def run_job(job: dict, archive: Path | None, target_in: str, unique_tag: bool, pull_policy: str) -> None:
    """Run one image job. See MODES for the stages of each mode."""
    mode, ns, name = job["mode"], job["namespace"], job["deployment"]
    lock = DEPLOY_LOCKS.setdefault(f"{ns}/{name}", asyncio.Lock()) if name else asyncio.Lock()
    try:
        async with lock:
            if mode == "ref":
                job["target_image"] = target_in
                return await patch_and_rollout(job, target_in, pull_policy)

            # 1. inspect the archive
            archive = await asyncio.to_thread(prepare_archive, archive)
            info = await asyncio.to_thread(inspect_archive, archive)
            log_step(job, f"Archive: {info['format']} format, {archive.stat().st_size / 1048576:.1f} MiB, "
                          f"{info['images']} image(s), tags: {', '.join(info['tags']) or 'none'}")
            source = info["tags"][0] if info["tags"] else None

            if mode == "push":
                # push every image in the archive; a name override only applies to single-image archives
                if target_in and info["images"] > 1:
                    log_step(job, "The archive holds several images; keeping their own names.", "warn")
                    target_in = ""
                if target_in:
                    pairs = [(source, resolve_target(target_in, unique_tag, True))]
                elif info["tags"]:
                    pairs = [(t, resolve_target(t, unique_tag, True)) for t in info["tags"]]
                else:
                    return finish(job, "failed", "The archive has no image tag. Enter an image name and try again.")
                job["target_image"] = pairs[0][1] if len(pairs) == 1 else f"{len(pairs)} images"
                job["stage"] = "push"
                if await push_images(job, archive, info, pairs):
                    job["stage"] = "done"
                    finish(job, "succeeded", f"Pushed {len(pairs)} image(s) to {registry.REGISTRY_HOST}.")
                return

            if not (target_in or source):
                return finish(job, "failed", "The archive has no image tag. Enter a target image name and try again.")
            target = resolve_target(target_in or source, unique_tag, mode == "registry")
            job["target_image"] = target
            log_step(job, f"Target image: {target}")

            # 2. make the image available to the nodes
            if mode in ("nodes", "load"):
                job["stage"] = "distribute"
                if not await distribute(job, archive, info, source, target):
                    return
                if mode == "load":
                    job["stage"] = "done"
                    return finish(job, "succeeded", f"{target} is loaded on every node with an agent.")
            else:
                job["stage"] = "push"
                if not await push_images(job, archive, info, [(source, target)]):
                    return

            # 3 + 4. point the deployment at it and follow the rollout
            await patch_and_rollout(job, target, pull_policy)
    except ApiException as exc:
        finish(job, "failed", f"Kubernetes API error {exc.status}: {exc.reason}")
    except ValueError as exc:
        finish(job, "failed", str(exc))
    except Exception as exc:  # noqa: BLE001
        log.exception("job %s crashed", job["id"])
        finish(job, "failed", f"Unexpected error: {exc}")
    finally:
        if archive:
            for p in {archive, archive.with_suffix(".tar")}:
                p.unlink(missing_ok=True)


def start_job(job: dict, *args) -> None:
    task = asyncio.create_task(run_job(job, *args))
    BACKGROUND.add(task)
    task.add_done_callback(BACKGROUND.discard)


async def save_upload(file: UploadFile) -> Path:
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    dest = UPLOAD_DIR / f"{uuid.uuid4().hex}.upload"
    with dest.open("wb") as fh:
        while chunk := await file.read(CHUNK):
            fh.write(chunk)
    await file.close()
    return dest


async def check_target(namespace: str, name: str, container: str) -> None:
    try:
        d = await k8s(c.apps_api.read_namespaced_deployment, name, namespace)
    except ApiException as exc:
        raise HTTPException(exc.status, f"Deployment {namespace}/{name} not found") from exc
    if container not in [x.name for x in d.spec.template.spec.containers]:
        raise HTTPException(400, f"Container '{container}' not found in {namespace}/{name}")
    lock = DEPLOY_LOCKS.get(f"{namespace}/{name}")
    if lock and lock.locked():
        raise HTTPException(409, f"An update for {namespace}/{name} is already running.")


# --------------------------------------------------------------------------- routes
@app.get("/")
async def index():
    return FileResponse(STATIC / "index.html")


@app.get("/healthz")
async def healthz():
    return {"ok": True, "version": VERSION}


@app.on_event("startup")
async def _registry_state_on_start():
    try:
        await registry.refresh_state(force=True)
    except Exception:  # noqa: BLE001  (cluster not reachable yet; checked again on use)
        pass


@app.get("/api/config")
async def api_config():
    try:
        await registry.refresh_state()
    except Exception:  # noqa: BLE001
        pass
    return {"version": VERSION, "auth_required": bool(c.DASHBOARD_TOKEN), "rollout_timeout": ROLLOUT_TIMEOUT,
            "read_only": c.READ_ONLY, "protected_namespaces": sorted(c.PROTECTED_NAMESPACES),
            "registry": {"enabled": registry.active(), "configured": registry.CONFIGURED,
                         "host": registry.REGISTRY_HOST}}


@app.get("/api/namespaces", dependencies=[Depends(require_auth)])
async def namespaces():
    res = await k8s(c.core_api.list_namespace)
    return sorted(n.metadata.name for n in res.items if c.visible(n.metadata.name))


@app.get("/api/deployments", dependencies=[Depends(require_auth)])
async def deployments(namespace: str = ""):
    if namespace:
        res = await k8s(c.apps_api.list_namespaced_deployment, namespace)
    else:
        res = await k8s(c.apps_api.list_deployment_for_all_namespaces)
    items = [serialize_deployment(d) for d in res.items if c.visible(d.metadata.namespace)]
    return sorted(items, key=lambda x: (x["namespace"], x["name"]))


@app.get("/api/agents", dependencies=[Depends(require_auth)])
async def agents():
    data = await list_agents()
    async with httpx.AsyncClient(timeout=3) as http:
        async def probe(n):
            a = n["agent"]
            if not (a and a["ip"]):
                return
            try:
                r = await http.get(f"http://{a['ip']}:{AGENT_PORT}/healthz",
                                   params={"runtime": c.runtime_hint(n["runtime"]) or ""})
                a.update(r.json())
            except Exception as exc:  # noqa: BLE001
                a["error"] = str(exc)
        await asyncio.gather(*[probe(n) for n in data["nodes"]])
    return data


@app.post("/api/deployments/{namespace}/{name}/image", dependencies=[Depends(require_auth)])
async def update_image(namespace: str, name: str,
                       file: UploadFile = File(...),
                       container: str = Form(...),
                       target_image: str = Form(""),
                       unique_tag: bool = Form(True),
                       pull_policy: str = Form("IfNotPresent"),
                       destination: str = Form("nodes")):
    """Upload a tar and roll it out: destination 'registry' pushes it first, 'nodes' loads it on each node."""
    c.require_write(namespace)
    if destination not in ("nodes", "registry"):
        raise HTTPException(400, "destination must be 'nodes' or 'registry'")
    if destination == "registry":
        registry._require_enabled()
    allowed = ("IfNotPresent", "Always") if destination == "registry" else ("IfNotPresent", "Never")
    if pull_policy not in allowed:
        raise HTTPException(400, f"pull_policy must be one of {', '.join(allowed)}")
    await check_target(namespace, name, container)
    dest = await save_upload(file)
    job = new_job(namespace, name, container, file.filename or "image.tar", destination)
    log_step(job, f"Received {file.filename} ({dest.stat().st_size / 1048576:.1f} MiB)")
    start_job(job, dest, target_image.strip(), unique_tag, pull_policy)
    return {"job_id": job["id"]}


class ImageRefIn(BaseModel):
    container: str
    image: str
    pull_policy: str = "IfNotPresent"


@app.post("/api/deployments/{namespace}/{name}/image-ref", dependencies=[Depends(require_auth)])
async def update_image_ref(namespace: str, name: str, body: ImageRefIn):
    """Point a deployment at an image that is already in the local registry."""
    c.require_write(namespace)
    image = body.image.strip()
    if "@" in image or not REF_RE.match(image):
        raise HTTPException(400, f"'{image}' is not a valid image reference.")
    if body.pull_policy not in ("IfNotPresent", "Always", "Never"):
        raise HTTPException(400, "pull_policy must be IfNotPresent, Always or Never")
    await check_target(namespace, name, body.container)
    job = new_job(namespace, name, body.container, None, "ref")
    log_step(job, f"Using {image} from the registry")
    start_job(job, None, image, False, body.pull_policy)
    return {"job_id": job["id"]}


@app.post("/api/nodes/load", dependencies=[Depends(require_auth)])
async def nodes_load(file: UploadFile = File(...), target_image: str = Form(""), unique_tag: bool = Form(True)):
    """Load a tar onto every node without touching any deployment (Apply YAML sets the image)."""
    c.require_write()
    dest = await save_upload(file)
    job = new_job(None, None, None, file.filename or "image.tar", "load")
    log_step(job, f"Received {file.filename} ({dest.stat().st_size / 1048576:.1f} MiB)")
    start_job(job, dest, target_image.strip(), unique_tag, "IfNotPresent")
    return {"job_id": job["id"]}


@app.post("/api/registry/push", dependencies=[Depends(require_auth)])
async def registry_push(file: UploadFile = File(...), target_image: str = Form(""), unique_tag: bool = Form(False)):
    """Push every image in a tar to the local registry without touching any deployment."""
    c.require_write()
    registry._require_enabled()
    dest = await save_upload(file)
    job = new_job(None, None, None, file.filename or "image.tar", "push")
    log_step(job, f"Received {file.filename} ({dest.stat().st_size / 1048576:.1f} MiB)")
    start_job(job, dest, target_image.strip(), unique_tag, "IfNotPresent")
    return {"job_id": job["id"]}


@app.post("/api/deployments/{namespace}/{name}/restart", dependencies=[Depends(require_auth)])
async def restart(namespace: str, name: str):
    c.require_write(namespace)
    patch = {"spec": {"template": {"metadata": {"annotations": {"kubectl.kubernetes.io/restartedAt": now_iso()}}}}}
    await k8s(c.apps_api.patch_namespaced_deployment, name, namespace, patch)
    c.audit("restart", f"deployment/{namespace}/{name}")
    return {"ok": True}


@app.post("/api/jobs/{job_id}/rollback", dependencies=[Depends(require_auth)])
async def rollback(job_id: str):
    job = JOBS.get(job_id)
    if not job or not _job_visible(job) or not job.get("previous_image"):
        raise HTTPException(404, "Nothing to roll back for this job.")
    c.require_write(job["namespace"])
    patch = {"spec": {"template": {
        "metadata": {"annotations": {"kubectl.kubernetes.io/restartedAt": now_iso(),
                                     f"{ANNOTATION_PREFIX}/image": job["previous_image"]}},
        "spec": {"containers": [{"name": job["container"], "image": job["previous_image"]}]},
    }}}
    await k8s(c.apps_api.patch_namespaced_deployment, job["deployment"], job["namespace"], patch)
    log_step(job, f"Rolled back {job['container']} to {job['previous_image']}")
    c.audit("rollback", f"deployment/{job['namespace']}/{job['deployment']}", job["previous_image"])
    return {"ok": True}


@app.get("/api/audit", dependencies=[Depends(require_auth)])
async def audit_log():
    """Admins see every change; everyone else sees their own."""
    u = c.user()
    return list(c.AUDIT) if "users" in u.caps() else [a for a in c.AUDIT if a.get("user") == u.name]


@app.get("/api/jobs", dependencies=[Depends(require_auth)])
def _job_visible(job: dict) -> bool:
    # Deployment jobs follow namespace scope; push/load jobs are visible to whoever started them, and admins
    if job.get("namespace"):
        return c.visible(job["namespace"])
    u = c.user()
    return job.get("user") in (None, u.name) or "users" in u.caps()


async def jobs():
    return [{k: j.get(k) for k in ("id", "mode", "namespace", "deployment", "container", "state", "stage",
                                   "created", "finished", "target_image", "filename", "user")}
            for j in reversed(JOBS.values()) if _job_visible(j)]


@app.get("/api/jobs/{job_id}", dependencies=[Depends(require_auth)])
async def job_detail(job_id: str):
    job = JOBS.get(job_id)
    if not job or not _job_visible(job):
        raise HTTPException(404, "Job not found (jobs are kept in memory; the dashboard may have restarted).")
    return job
