"""Apply YAML from the dashboard, like `kubectl apply`, with a preview first.

* POST /api/manifests/preview  parse, pick images, server-side dry run: what WOULD happen
* POST /api/manifests/apply    same checks, then server-side apply for real
* GET  /api/manifests/export   an existing object as clean YAML, to edit and re-apply

Server-side apply (field manager "k8s-image-loader") means re-applying the same file is
safe and only the fields in the file are owned by the dashboard.
"""
from __future__ import annotations

import asyncio
import json
import re

import httpx
import yaml
from fastapi import APIRouter, Depends, HTTPException
from kubernetes.client.rest import ApiException
from kubernetes.dynamic import DynamicClient
from kubernetes.dynamic.exceptions import DynamicApiError, ResourceNotFoundError
from pydantic import BaseModel, Field

import common as c
import registry

router = APIRouter(dependencies=[Depends(c.require_auth)])

FIELD_MANAGER = "k8s-image-loader"
MAX_BYTES = 2 * 1024 * 1024
MAX_OBJECTS = 50

# What the dashboard may apply, in the order it applies them (dependencies first).
ALLOWED = ["ServiceAccount", "ConfigMap", "Secret", "PersistentVolumeClaim", "Service",
           "Deployment", "StatefulSet", "Ingress", "HorizontalPodAutoscaler"]
ORDER = {k: i for i, k in enumerate(ALLOWED)}
WORKLOADS = {"Deployment", "StatefulSet"}
KIND_CAP = {"ConfigMap": "config", "Secret": "secrets", "PersistentVolumeClaim": "storage"}   # others: deploy

_dyn: DynamicClient | None = None


async def dyn() -> DynamicClient:
    global _dyn
    if _dyn is None:
        _dyn = await asyncio.to_thread(DynamicClient, c.api_client)   # runs API discovery once
    return _dyn


def _api_message(exc: Exception) -> str:
    body = getattr(exc, "body", None)
    try:
        msg = json.loads(body).get("message") or str(exc)
    except Exception:  # noqa: BLE001
        msg = exc.summary() if hasattr(exc, "summary") else str(exc)
    if "field not declared in schema" in msg or "unknown field" in msg:
        m = re.search(r"\.([A-Za-z0-9_.-]+): field not declared in schema", msg) or re.search(r'unknown field "([^"]+)"', msg)
        where = f' "{m.group(1)}"' if m else ""
        msg = (f"Unknown field{where}: Kubernetes does not know this field at this place. "
               f"Check its spelling and indentation (settings of a ConfigMap go indented under data:). "
               f"Details: {msg}")
    return msg


# --------------------------------------------------------------------------- parsing
class ManifestIn(BaseModel):
    yaml: str = Field(..., max_length=MAX_BYTES)
    namespace: str = "default"                  # for objects without metadata.namespace
    qualify_images: bool = True                 # nginx:1 -> docker.io/library/nginx:1
    image_overrides: dict[str, str] = {}        # "Deployment/web/app" -> new image


def parse(text: str) -> list[dict]:
    try:
        docs = [d for d in yaml.safe_load_all(text) if d is not None]
    except yaml.YAMLError as exc:
        mark = getattr(exc, "problem_mark", None)
        where = f" (line {mark.line + 1}, column {mark.column + 1})" if mark else ""
        raise HTTPException(400, f"The file is not valid YAML{where}: {getattr(exc, 'problem', exc)}")
    objs: list[dict] = []
    for d in docs:
        if isinstance(d, dict) and d.get("kind") == "List":
            objs.extend(d.get("items") or [])
        else:
            objs.append(d)
    if not objs:
        raise HTTPException(400, "The file contains no Kubernetes objects.")
    if len(objs) > MAX_OBJECTS:
        raise HTTPException(400, f"At most {MAX_OBJECTS} objects per apply.")
    for i, o in enumerate(objs, 1):
        if not isinstance(o, dict) or not o.get("apiVersion") or not o.get("kind"):
            raise HTTPException(400, f"Object {i} has no apiVersion or kind.")
        if not (o.get("metadata") or {}).get("name"):
            raise HTTPException(400, f"Object {i} ({o['kind']}) has no metadata.name.")
        if o["kind"] not in ALLOWED:
            raise HTTPException(400, f"{o['kind']} '{o['metadata']['name']}' cannot be applied here. "
                                     f"Supported kinds: {', '.join(ALLOWED)}.")
    return objs


def containers(obj: dict) -> list[dict]:
    if obj["kind"] not in WORKLOADS:
        return []
    spec = ((obj.get("spec") or {}).get("template") or {}).get("spec") or {}
    return (spec.get("initContainers") or []) + (spec.get("containers") or [])


def image_key(obj: dict, container: dict) -> str:
    return f"{obj['kind']}/{obj['metadata']['name']}/{container.get('name')}"


async def image_warnings(image: str) -> list[str]:
    out = []
    if registry.is_local(image):
        if registry.active():
            repo, tag = registry.repo_and_tag(image[len(registry.REGISTRY_HOST) + 1:])
            try:
                async with httpx.AsyncClient(base_url=registry.REGISTRY_URL, timeout=5) as http:
                    r = await registry._manifest(http, repo, tag, "HEAD")
                if r.status_code == 404:
                    out.append("This tag is not in the local registry. Push the tar on the Images tab first.")
            except httpx.HTTPError:
                out.append("Could not reach the local registry to check this tag.")
    else:
        out.append("Not from the local registry: every node must be able to pull it, or have it loaded.")
    return out


# --------------------------------------------------------------------------- preview / apply
async def prepare(body: ManifestIn) -> list[dict]:
    """Parse, set namespaces, apply image choices. Returns plan items (object + metadata)."""
    default_ns = body.namespace.strip() or "default"
    plan = []
    for obj in parse(body.yaml):
        md = obj["metadata"]
        ns = md.get("namespace") or default_ns
        md["namespace"] = ns
        item = {"kind": obj["kind"], "name": md["name"], "namespace": ns, "object": obj,
                "images": [], "warnings": [], "error": None}
        cap = KIND_CAP.get(obj["kind"], "deploy")
        u = c.user()
        if c.READ_ONLY:
            item["error"] = "The dashboard is in read-only mode."
        elif ns in c.PROTECTED_NAMESPACES or ns in c.HIDE_NAMESPACES:
            item["error"] = f"Namespace {ns} is protected; nothing is applied there."
        elif not u.in_scope(ns):
            item["error"] = f"You do not have access to namespace '{ns}'."
        elif cap not in u.caps():
            item["error"] = f"Your role ({u.role}) cannot {c.CAP_TEXT[cap]}, so it cannot apply a {obj['kind']}."
        for ct in containers(obj):
            key = image_key(obj, ct)
            original = ct.get("image") or ""
            chosen = body.image_overrides.get(key) or original
            if body.qualify_images and chosen and "@" not in chosen:
                chosen = c.fully_qualified(chosen)
            if chosen != original:
                ct["image"] = chosen
            item["images"].append({"key": key, "container": ct.get("name"), "original": original,
                                   "image": chosen, "warnings": await image_warnings(chosen) if chosen else
                                   ["No image set."]})
        if obj["kind"] == "Deployment":
            spec = obj.get("spec") or {}
            pod = (spec.get("template") or {}).get("spec") or {}
            uses_claim = any(v.get("persistentVolumeClaim") for v in pod.get("volumes") or [])
            if uses_claim and (spec.get("replicas") or 1) > 1:
                item["warnings"].append("Several replicas share a claim; with ReadWriteOnce they must run on one node.")
        plan.append(item)
    plan.sort(key=lambda p: ORDER[p["kind"]])
    return plan


async def run_plan(plan: list[dict], dry_run: bool) -> list[dict]:
    d = await dyn()
    results = []
    for item in plan:
        res = {k: item[k] for k in ("kind", "name", "namespace", "images", "warnings")}
        if item["error"]:
            results.append({**res, "action": "error", "error": item["error"]})
            continue
        obj = item["object"]
        try:
            api = await asyncio.to_thread(d.resources.get, api_version=obj["apiVersion"], kind=obj["kind"])
        except ResourceNotFoundError:
            results.append({**res, "action": "error", "error": f"{obj['apiVersion']} {obj['kind']} is not served by this cluster."})
            continue
        try:
            await asyncio.to_thread(api.get, name=item["name"], namespace=item["namespace"])
            action = "update"
        except DynamicApiError as exc:
            if exc.status != 404:
                results.append({**res, "action": "error", "error": _api_message(exc)})
                continue
            action = "create"
        try:
            # fieldValidation=Strict, like kubectl: a misplaced or misspelled field is an error,
            # not silently dropped (e.g. a data key that is not indented under "data:")
            await asyncio.to_thread(d.server_side_apply, api, body=obj, name=item["name"], namespace=item["namespace"],
                                    field_manager=FIELD_MANAGER, force_conflicts=True,
                                    query_params=[("fieldValidation", "Strict")],
                                    **({"dry_run": "All"} if dry_run else {}))
            results.append({**res, "action": action})
            if not dry_run:
                c.audit("apply", f"{item['kind'].lower()}/{item['namespace']}/{item['name']}",
                        f"{action}d" + (f"; images: {', '.join(i['image'] for i in item['images'])}" if item["images"] else ""))
        except (DynamicApiError, ApiException) as exc:
            results.append({**res, "action": "error", "error": _api_message(exc)})
    return results


@router.post("/api/manifests/preview")
async def preview(body: ManifestIn):
    """Validate against the cluster without changing anything (server-side dry run)."""
    results = await run_plan(await prepare(body), dry_run=True)
    return {"ok": all(r["action"] != "error" for r in results), "objects": results}


@router.post("/api/manifests/apply")
async def apply(body: ManifestIn):
    if c.READ_ONLY:
        raise HTTPException(403, "The dashboard is in read-only mode (READ_ONLY=true).")
    plan = await prepare(body)
    blocked = [p for p in plan if p["error"]]
    if blocked:
        raise HTTPException(403, blocked[0]["error"])
    # Dry run everything first: if any object would fail, change nothing.
    check = await run_plan(plan, dry_run=True)
    bad = [r for r in check if r["action"] == "error"]
    if bad:
        return {"ok": False, "applied": False, "objects": check}
    results = await run_plan(await prepare(body), dry_run=False)
    return {"ok": all(r["action"] != "error" for r in results), "applied": True, "objects": results}


# --------------------------------------------------------------------------- export
STRIP_META = ("managedFields", "uid", "resourceVersion", "creationTimestamp", "generation", "selfLink")
STRIP_ANN = ("kubectl.kubernetes.io/last-applied-configuration", "deployment.kubernetes.io/revision")


def clean(obj: dict) -> dict:
    obj.pop("status", None)
    md = obj.get("metadata") or {}
    for k in STRIP_META:
        md.pop(k, None)
    ann = md.get("annotations") or {}
    for k in STRIP_ANN:
        ann.pop(k, None)
    if not ann:
        md.pop("annotations", None)
    tmpl = ((obj.get("spec") or {}).get("template") or {}).get("metadata") or {}
    if tmpl.get("creationTimestamp") is None:
        tmpl.pop("creationTimestamp", None)
    if obj.get("kind") == "Service":
        for k in ("clusterIP", "clusterIPs"):
            (obj.get("spec") or {}).pop(k, None)
    return obj


@router.get("/api/manifests/export")
async def export(kind: str, namespace: str, name: str):
    if kind not in ALLOWED:
        raise HTTPException(400, f"Export supports: {', '.join(ALLOWED)}")
    if not c.visible(namespace):
        raise HTTPException(404, "Not found.")
    api_version = {"Deployment": "apps/v1", "StatefulSet": "apps/v1", "Ingress": "networking.k8s.io/v1",
                   "HorizontalPodAutoscaler": "autoscaling/v2"}.get(kind, "v1")
    d = await dyn()
    api = await asyncio.to_thread(d.resources.get, api_version=api_version, kind=kind)
    try:
        obj = await asyncio.to_thread(api.get, name=name, namespace=namespace)
    except DynamicApiError as exc:
        raise HTTPException(exc.status or 500, _api_message(exc))
    data = clean(obj.to_dict())
    if kind == "Secret":
        c.require("secrets", namespace)
        c.audit("view", f"secret/{namespace}/{name}", "exported as YAML")
    return {"yaml": yaml.safe_dump(data, sort_keys=False, default_flow_style=False)}
