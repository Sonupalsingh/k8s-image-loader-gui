# Changelog

## 1.6.0
- **Clean up images** on the nodes: dangling images, or dangling and unused ones, with a preview of what goes and the space it frees. Also Docker's dangling images.
- **Remove** now works for Docker's images too.
- "In use" is decided **cluster-wide**: every pod (including static system pods), running containers' image IDs and digests, and every Deployment, StatefulSet, DaemonSet, Job and CronJob template, including those scaled to zero.
- **Delete deployment** (Editor or Admin): removes its autoscaler, optionally its own Services (shared ones are kept), and never its storage claims.
- **Restart pods** is back in Manage.
- Fix: `node-import.sh` treated the empty `config_path = ""` in containerd 1.7's default config (common on Ubuntu) as set, so nodes never trusted the local registry. It now says which line to change.
- New beginner guide: `docs/getting-started.md` (Ubuntu and RHEL).
- Fix: `make undeploy` deleted the whole namespace, including the registry and its images. It now removes only the dashboard and agents.

## 1.5.2
- Fix: **On nodes** failed with `Expecting value: line 1 column 1` when crictl printed a warning before its JSON. The agent now reads only crictl's data, falls back to CRI-O's image store, and always shows Docker's images.

## 1.5.1
- Fix: loading a tar on CRI-O failed with `overlay: unknown option metacopy` on nodes using the RHEL default `mountopt = "nodev,metacopy=on"`. The agent now writes a proper storage configuration for skopeo and verifies each import.

## 1.5.0
- **Local registry on/off switch**. Stored images are kept while it is off; external registries stay on.
- **Images on nodes**: what CRI-O or containerd holds, read with crictl, plus Docker's images.
- **Autoscaling (HPA)** in Manage, with checks for metrics-server and CPU requests.
- Fix: deployers had non-working buttons in Manage.

## 1.4.0
- **Users and access**: personal tokens, roles (viewer, deployer, editor, admin), namespace scope, enforced by the server. The change log records who did what.
- Config maps: the name is checked in place, and manifest files are offered to Apply YAML. Strict YAML validation.

## 1.3.0
- **Apply YAML** with a server-side dry run, all-or-nothing apply, and a per-container image picker: registry, or a tar file loaded to the registry or onto the nodes.
- **YAML** button to edit existing Deployments.

## 1.2.x
- **Local registry** in the cluster: push tars, browse tags, deploy from the registry, set up node trust.
- Bootstrap **bundle** (`make bundle`) and `node-import.sh`: skopeo on CRI-O, ctr on containerd, following the runtime the kubelet uses.
- Fully qualified image names everywhere, so CRI-O never resolves short names through internet registries.

## 1.1.0
- Scaling, volumes, environment, config maps, secrets and storage (PVs, claims, local disks).

## 1.0.0
- First version: load an image tar onto every node through the node agents, and roll it out to a Deployment.
