# Troubleshooting

Start with these three commands. They answer most questions:

```bash
kubectl -n k8s-image-loader get pods -o wide                              # is everything running, and where?
kubectl -n k8s-image-loader logs deploy/image-loader-dashboard --tail=50  # dashboard log (changes are marked AUDIT)
kubectl -n k8s-image-loader logs -l app.kubernetes.io/component=node-agent --prefix --tail=50   # agent logs, every node
```

## Installation

### `make: *** No rule to make target 'bundle'`
You are not in the project folder, or the repository contents are incomplete. `ls` must show `Makefile`, `dashboard/`, `agent/`, `deploy/` and `scripts/`. If `make` itself is missing, install it (`dnf install make` / `apt-get install make`) or run the script directly: `./scripts/make-bundle.sh`.

### `unable to prepare context: path "dashboard" not found`, or `ERROR: the project folders are missing`
Only single files were copied, without the project's folders. This happens when files are uploaded one by one on the GitHub website, which drops folders. Push the project with `git` instead (the folders `dashboard/`, `agent/`, `deploy/`, `scripts/` and `docs/` must be in the repository), clone it again, and run `sudo make bundle` in its top folder.

### `node-import.sh: tar: This does not look like a tar archive`
`node-import.sh` needs the **image bundle** (`k8s-image-loader-bundle-<version>.tar`, created by `make bundle`), or any image tar made with `docker save` / `skopeo`. It does not take the project's source code or a `.zip`.

### `sudo: ./node-import.sh: command not found`
The script isn't executable (common after downloading or copying it). Run `chmod +x node-import.sh`, or start it with `sudo bash node-import.sh …`.

### `dnf`: `Cannot download repomd.xml … /mnt/BaseOS`
Your RHEL system installs packages from the DVD mounted at `/mnt`, and nothing is mounted. Mount it (`sudo mount /dev/sr0 /mnt`, or `mount -o loop rhel.iso /mnt`) and make sure both `BaseOS` and `AppStream` are configured. The "not registered with an entitlement server" message is only a warning.

### `make bundle` builds an old version
The version comes from `scripts/make-bundle.sh`. Check it with `grep VERSION= scripts/make-bundle.sh`. If it's old, you have an old copy of the code: `git pull`.

### `docker save` problems (`content digest … not found`, `blobs/sha256/…: file does not exist`)
Newer Docker versions with the **containerd image store** write `docker save` output that other tools can't read. `make-bundle.sh` detects this and exports another way (`flattening with docker export`). No action is needed; every exported image is verified.

## Pods of the tool itself show `ImagePullBackOff`

The node doesn't have the image under the exact name the pod asks for. Check `kubectl -n k8s-image-loader describe pod <pod> | grep -E "Image:|Failed"`:

| The error says | Cause | Fix |
|---|---|---|
| `reading manifest … in quay.io/…: unauthorized` | The image is missing on the node, so CRI-O tried a search registry | Import the bundle on that node (`node-import.sh`); every image must say `OK` |
| Image `…:1.5.0` but the node has `…:1.6.0` (or the reverse) | Manifests and imported bundle are from different versions | Apply the manifests from the **same** version as the bundle: `kubectl apply -k deploy` |
| `node-import.sh` said `Runtime: containerd`, but the node runs CRI-O | Docker's containerd was found instead of the kubelet's runtime | Re-import with `RUNTIME=crio ./node-import.sh . localhost:30500`. Check with `crictl images`, which shows what Kubernetes sees |

After fixing, restart the pods: `kubectl -n k8s-image-loader delete pod -l app.kubernetes.io/name=k8s-image-loader`.

## Deploying images

### `ErrImagePull … http: server gave HTTP response to HTTPS client`
The node doesn't trust the local registry yet. On the **Images** tab choose **Set up nodes**, then do any step it reports. On containerd 1.x, that step is adding `config_path = "/etc/containerd/certs.d"` to `/etc/containerd/config.toml` and restarting containerd.

### `ErrImagePull … connection refused` on `localhost:30500`
Your kube-proxy mode doesn't serve NodePorts on `localhost` (IPVS, nftables, some eBPF networking). Set `REGISTRY_HOST` to `<node-ip>:30500` on the dashboard **and** the agent ([configuration](configuration.md#registry)), then run **Set up nodes** again.

### Loading a tar on CRI-O fails with `overlay: unknown option metacopy`
Fixed in 1.5.1. Older agents passed CRI-O's storage options inside the image name, which breaks on the RHEL default `mountopt = "nodev,metacopy=on"`. Update to the current version.

### `Image load failed on <node>. The deployment was not changed.`
The tar couldn't be imported on that node; the job log above this line shows the node's reason. Nothing was changed, so fix the cause and try again. A common cause is disk space: the agent's work directory is limited to 20 Gi (`sizeLimit` in `03-agent-daemonset.yaml`).

### An image name points at an internet registry (for example `…azurecr.io/…`)
That's fine in an air-gapped cluster. With pull policy **IfNotPresent**, Kubernetes uses the copy on the node (or in the local registry, under its `localhost:30500/…` name) and never contacts the internet registry.

### Rollout doesn't finish
The job log lists pod problems: `CrashLoopBackOff` (the application exits; check its logs), `ErrImageNeverPull` (the image isn't on that node and the pull policy is Never), or `Pending` (not enough resources, or a storage claim that isn't bound). **Roll back** restores the previous image.

## Images on nodes

### `cannot list crio images: Expecting value: line 1 column 1 (char 0)`
Fixed in 1.5.2. crictl printed a warning before its JSON output. Current agents ignore such text, fall back to reading CRI-O's image store directly, and still show Docker's images.

### A node is missing from the list, or shows an error
Its agent isn't ready: check `kubectl -n k8s-image-loader get pods -o wide`. The error text is the agent's own message.

### Remove or Clean up refuses an image
It's in use by a pod or a workload somewhere in the cluster, or the runtime reports that a container runs from it. That protection is intended, because in an air-gapped cluster a removed image can't simply be pulled again. Stop or delete what uses it first.

## Apply YAML and config

### `The file is not valid YAML (line 8, column 3)`
The indentation is wrong at that line. YAML uses spaces, never tabs, and child keys must be indented under their parent (config map keys under `data:`).

### `Unknown field "…": Kubernetes does not know this field at this place`
A field is misspelled or at the wrong level. The dashboard validates strictly, like `kubectl`, instead of silently dropping it.

### A config map change has no effect
Environment variables and `subPath` mounts are read when the pod starts. Save again with **Restart the deployments that use it** ticked, or use **Restart pods** in Manage.

### `Name '' is invalid`
The name field is empty; the grey text in it is only an example. Enter a name with lowercase letters, digits and `-`.

## Autoscaling

### "metrics-server is not installed"
The autoscaler can't measure CPU or memory without metrics-server. [Install it](installation.md#9-optional-metrics-server-for-autoscaling) once for the cluster.

### Autoscaling is on, but it says "not scaling"
The status names the reason. Usually a container has **no CPU request** (the dashboard offers to set one), or metrics-server can't reach the kubelets. On kubeadm test clusters, add `--kubelet-insecure-tls` to metrics-server's args.

## Access

### I lost the admin token
Read it from the cluster: `kubectl -n k8s-image-loader get secret dashboard-auth -o jsonpath='{.data.token}' | base64 -d`. To replace it, see [Configuration](configuration.md#tokens).

### A user's buttons are missing
Their role doesn't allow that work, or the namespace is protected. The header shows their role and namespaces; an admin can change them on the **Users** tab.

### Upload stops at 100% for a long time
The dashboard is decompressing, pushing or distributing a large archive. The job's activity log shows each step. Uploads through an Ingress need a large body size and long timeouts; see `deploy/06-ingress.example.yaml`.
