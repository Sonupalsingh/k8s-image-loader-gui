# Architecture

## Components

| Component | Runs as | Image | Job |
|---|---|---|---|
| **Dashboard** | Deployment, 1 replica, non-root, read-only root filesystem | `k8s-image-loader/dashboard` (Python 3.12, FastAPI, skopeo) | Web UI and REST API. Talks to the Kubernetes API, pushes to the registry, instructs the agents |
| **Node agent** | DaemonSet, one pod per node, privileged | `k8s-image-loader/agent` (Python 3.12, ctr, crictl, skopeo) | Imports, lists and removes images in the node's runtime, and configures the runtime to trust the registry |
| **Registry** | Deployment, 1 replica, with a PersistentVolumeClaim | `registry:2.8.3` (CNCF Distribution) | Stores images. Every node reaches it at `localhost:30500` (NodePort) |

All three run in the namespace `k8s-image-loader`. The UI is plain HTML and JavaScript served by the dashboard; it needs no internet (fonts fall back to system fonts).

## How an image reaches a pod

```mermaid
sequenceDiagram
    participant U as Browser
    participant D as Dashboard
    participant R as Registry
    participant A as Node agents
    participant K as Kubernetes API
    U->>D: upload app.tar
    D->>D: inspect archive (docker-archive / OCI, gzip ok)
    alt to the local registry
        D->>R: skopeo copy docker-archive: → docker://
    else onto each node
        D->>A: stream the tar to every agent in parallel
        A->>A: ctr import (containerd) / skopeo copy → containers-storage (CRI-O)
    end
    D->>K: patch Deployment image (only if every step succeeded)
    K-->>D: rollout status, pod problems
    D-->>U: live stages, log, Roll back
```

**If loading fails on any node, the Deployment is not changed**, so pods never end up in `ErrImagePull` halfway through. Image names are always fully qualified (`nginx:1.27` becomes `docker.io/library/nginx:1.27`), because CRI-O resolves short names through its search registries and would otherwise try to download from the internet.

## Finding the right runtime

A node can have several container runtimes. Docker, for example, brings its own containerd even on a CRI-O node. Images must go into the one **the kubelet uses**:

- **The dashboard** reads each node's runtime from the Node object (`status.nodeInfo.containerRuntimeVersion`: `cri-o://…`, `containerd://…`, or `…-k3s`) and tells the agent on every call.
- **`node-import.sh`** reads the kubelet's `--container-runtime-endpoint`: from the running kubelet, `/var/lib/kubelet/config.yaml`, kubeadm's flags or `/etc/crictl.yaml`.
- **When in doubt, both refuse to guess.** They ask you to set `RUNTIME` rather than import into the wrong place.

| Runtime | Import | List | Registry trust |
|---|---|---|---|
| CRI-O | `skopeo copy` into containers-storage, with the node's storage settings | `crictl images`, or CRI-O's store files | `/etc/containers/registries.conf.d/50-k8s-image-loader.conf` |
| containerd | `ctr -n k8s.io images import` | `crictl images`, or `ctr images ls` | `/etc/containerd/certs.d/<registry>/hosts.toml` |
| k3s / RKE2 | `ctr` through the embedded containerd | as containerd | `/etc/rancher/<k3s or rke2>/registries.yaml` |

## Deciding what an image is used by

Before an image is removed from a node, the dashboard checks the **whole cluster**:

- every pod's images, including static system pods such as `kube-apiserver`;
- the image IDs and digests of running containers, which catches untagged images;
- the templates of every Deployment, StatefulSet, DaemonSet, Job and CronJob, **including those scaled to zero**.

It never removes images the runtime pins as system images. If any of these checks can't be completed, it removes nothing. In an air-gapped cluster, a wrongly removed image can't simply be pulled again.

## Security model

- **Authentication.** Every request needs a bearer token: the built-in admin's (secret `dashboard-auth`) or a personal user's. User tokens are stored only as SHA-256 fingerprints, and compared in constant time.
- **Authorization is enforced by the server.** Each change is checked against the user's role (the kind of work) and scope (namespaces). Any request that names a namespace outside the scope is refused, even when crafted by hand. The UI only mirrors these rules by hiding buttons.
- **Audit.** Every change is recorded with user, time, action and target, visible on Nodes and activity and in the dashboard's log (prefix `AUDIT`). So are secret views.
- **Guard rails.** Protected namespaces are read-only, `READ_ONLY=true` makes everything read-only, deleting things asks you to type the name, Apply YAML is all-or-nothing with strict validation, and edits use optimistic locking.
- **The node agent is privileged.** It writes into the container runtime and reads host paths. It accepts requests only with the agent token. A NetworkPolicy (`05-networkpolicy.yaml`) lets only the dashboard reach it, if your network plugin enforces NetworkPolicies. It can create directories only under `LOCAL_STORAGE_ROOTS`.
- **The registry uses plain HTTP without a login.** That is typical for an internal registry, but anyone who can reach port 30500 on a node can pull and push. Keep node ports off untrusted networks. For stricter setups, put the registry behind TLS and authentication.
- **Treat dashboard admin access like cluster-admin.** An admin can read secrets and change workloads cluster-wide.

## Code layout

```
dashboard/
  app.py          image jobs (upload, inspect, push or load, patch, rollout, rollback), app setup
  common.py       Kubernetes clients, users/roles/scope, guards, audit log, validation
  workloads.py    replicas, restart, volumes, env, autoscaling, delete, pods
  config_api.py   config maps and secrets
  storage.py      storage classes, persistent volumes and claims
  registry.py     local registry: browse, push, delete, on/off switch, node setup
  nodeimages.py   images on nodes, cluster-wide usage, removal and cleanup
  manifests.py    Apply YAML: dry run, apply, export
  users.py        user store and user management
  static/         index.html, app.js, styles.css
agent/agent.py    runtime detection, import, list, remove, registry trust, directories
scripts/          make-bundle.sh, node-import.sh
deploy/           manifests; deploy/registry/ for the registry
```
