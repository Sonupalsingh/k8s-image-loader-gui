# Configuration

All settings are environment variables in the manifests under `deploy/`. Change them there and apply again: `kubectl apply -k deploy`.

## Dashboard

`deploy/04-dashboard.yaml`

| Variable | In the manifest | Purpose |
|---|---|---|
| `DASHBOARD_TOKEN` | from secret `dashboard-auth` | Token of the **built-in admin**. If empty, sign-in is switched off (not recommended). |
| `AGENT_TOKEN` | from secret `agent-auth` | Shared secret the dashboard sends to the node agents. |
| `AGENT_NAMESPACE` | `k8s-image-loader` | Namespace of the agents, the registry and the user store. |
| `AGENT_SELECTOR` | `app.kubernetes.io/component=node-agent` | Label selector that finds the agent pods. |
| `REGISTRY_URL` | `http://image-registry.k8s-image-loader.svc:5000` | Where the dashboard pushes to and browses the registry. **Remove it to turn off all registry features.** |
| `REGISTRY_HOST` | `localhost:30500` | The registry address used in image names, as the **nodes** reach it. Must match the agent's `REGISTRY_HOST`. |
| `REGISTRY_DEPLOYMENT` | `image-registry` (default) | Name of the registry Deployment that the on/off switch scales. If it doesn't exist, the registry counts as external: always on, no switch. |
| `PROTECTED_NAMESPACES` | `kube-system,kube-public,kube-node-lease,k8s-image-loader` | Visible but read-only: changes there are refused. |
| `HIDE_NAMESPACES` | `kube-public,kube-node-lease` | Not shown at all. |
| `READ_ONLY` | `false` | `true` turns the whole dashboard into a viewer. |
| `ROLLOUT_TIMEOUT_SECONDS` | `600` | How long a rollout is followed before it counts as failed. |
| `AGENT_TIMEOUT_SECONDS` | `1800` (default) | Maximum time for one node to receive and import a tar. |
| `REGISTRY_PUSH_TIMEOUT_SECONDS` | `1800` (default) | Maximum time for one push to the registry. |
| `UPLOAD_DIR` | `/data` | Where uploads wait while they are processed. |

**Upload size.** Uploaded tars pass through the `emptyDir` volumes `/data` and `/tmp`, each limited to **20 Gi**. For bigger images, raise `sizeLimit` in `04-dashboard.yaml` and make sure the node has the disk space.

## Node agent

`deploy/03-agent-daemonset.yaml`

| Variable | In the manifest | Purpose |
|---|---|---|
| `AGENT_TOKEN` | from secret `agent-auth` | Must match the dashboard's. |
| `RUNTIME` | `auto` | Force `crio`, `containerd` or `k3s`. Normally the dashboard tells the agent which runtime each node's kubelet uses, taken from the Node object. |
| `REGISTRY_HOST` | `localhost:30500` | The registry address that **Set up nodes** configures and that the node status reports on. |
| `LOCAL_STORAGE_ROOTS` | `/mnt/disks:/var/lib/k8s-volumes` | The only host directories in which the dashboard may create local-volume folders. Each needs a matching `hostPath` mount under `/host`. |
| `CONTAINERD_SOCKET` | not set | A custom containerd socket, relative to the host root, for example `run/k3s/containerd/containerd.sock`. |
| `CONTAINERD_NAMESPACE` | `k8s.io` (default) | The containerd namespace the kubelet uses. |
| `CRIO_STORAGE_DRIVER` | not set | Override the storage driver read from the node's `/etc/containers/storage.conf`. |
| `IMPORT_TIMEOUT_SECONDS` | `1800` (default) | Maximum time for one import. |

**How the agent reaches the node.** Host paths are mounted under `/host`: `/run`, `/var/run` (the runtime sockets), `/var/lib/containers` and `/etc/containers` (CRI-O storage and registry settings), `/etc/containerd`, `/etc/rancher`, and the local-storage roots. On CRI-O nodes the agent imports with CRI-O's **exact** storage settings from `/etc/containers/storage.conf`: driver, locations and mount options such as `nodev,metacopy=on`.

## Registry

`deploy/registry/`

| File | What it sets |
|---|---|
| `registry.yaml` | The registry (`registry:2.8.3`, one replica, deleting tags enabled) and its **NodePort service on port 30500** |
| `pvc.yaml` | Its storage: a **50 Gi** claim from the default storage class |
| `pv-local.example.yaml` | Alternative: a local disk on one node, for clusters without a storage class ([how](installation.md#5-install-the-local-registry)) |

**Nodes reach the registry at `localhost:30500`.** This relies on kube-proxy serving NodePorts on `localhost`, which the iptables mode does. With IPVS, nftables or some eBPF networking, set `REGISTRY_HOST` to `<node-ip>:30500` on **both** the dashboard and the agent, then run **Set up nodes** again.

## Tokens

| Secret | Key | Used for |
|---|---|---|
| `dashboard-auth` | `token` | The built-in admin |
| `agent-auth` | `token` | Dashboard to agent |
| `dashboard-users` | `users.json` | Users created on the Users tab: name, role, scope, and a SHA-256 fingerprint of each token (never the token itself) |

Replace the built-in admin token:

```bash
kubectl -n k8s-image-loader create secret generic dashboard-auth \
  --from-literal=token="$(openssl rand -hex 24)" --dry-run=client -o yaml | kubectl apply -f -
kubectl -n k8s-image-loader rollout restart deploy/image-loader-dashboard
```

## Permissions of the dashboard

`deploy/02-rbac.yaml` gives the dashboard's service account a ClusterRole. In summary:

| Resources | Access | Why |
|---|---|---|
| Deployments | read, create, change, delete | Workloads, images, Apply YAML |
| StatefulSets, Services, ServiceAccounts, Ingresses, HorizontalPodAutoscalers | read, create, change (Services and HPAs also delete) | Apply YAML, autoscaling, deleting a Deployment's Service |
| DaemonSets, ReplicaSets, Jobs, CronJobs | read | Deciding which images are in use before removing any |
| Pods, Nodes, Namespaces | read | Status, nodes, image usage |
| ConfigMaps, Secrets | read and change | Config maps, secrets, the user store |
| PersistentVolumes, PersistentVolumeClaims, StorageClasses | read and change | Storage |
| `metrics.k8s.io` pods | read | Checking that metrics-server is installed |

The dashboard can't touch nodes, namespaces or RBAC itself. To limit it further, replace the ClusterRole with namespaced Roles, and use `PROTECTED_NAMESPACES` or `READ_ONLY=true`.

The **node agent** has no Kubernetes permissions (`automountServiceAccountToken: false`). It is privileged on its node, because importing images means writing into the container runtime.
