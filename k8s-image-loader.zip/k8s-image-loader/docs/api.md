# API

Everything the dashboard does is available as a REST API, which is useful for CI pipelines in air-gapped environments.

**Authentication.** Every request except `/healthz` and `/api/config` needs a bearer token. Use a personal user token with the role the pipeline needs, for example a **Deployer** limited to its namespaces, rather than the built-in admin's.

```bash
URL=http://<node-ip>:30080
AUTH="Authorization: Bearer <token>"
```

Errors come back as JSON `{"detail": "…"}`: `401` means no valid token, `403` means not allowed for this role or scope, `409` means refused because of the current state (for example, the image is in use).

## Deploy a new build from CI

```bash
# 1. Upload the tar, push it to the registry, and roll it out
JOB=$(curl -s -H "$AUTH" \
  -F file=@billing.tar -F container=billing -F destination=registry \
  -F unique_tag=true -F pull_policy=IfNotPresent \
  $URL/api/deployments/prod/billing-api/image | jq -r .job_id)

# 2. Wait for the result
while :; do
  STATE=$(curl -s -H "$AUTH" $URL/api/jobs/$JOB | jq -r .state)
  [ "$STATE" != running ] && break; sleep 3
done
echo "rollout: $STATE"                    # succeeded / failed

# 3. If it failed: roll back to the previous image
[ "$STATE" = failed ] && curl -s -X POST -H "$AUTH" $URL/api/jobs/$JOB/rollback
```

`destination=nodes` loads the tar directly onto every node instead of the registry.

## Common calls

```bash
# Push a tar (one or many images) to the registry without deploying
curl -H "$AUTH" -F file=@apps.tar $URL/api/registry/push

# Deploy a version that is already in the registry (or on the nodes)
curl -H "$AUTH" -H 'Content-Type: application/json' \
  -d '{"container":"billing","image":"localhost:30500/team/billing:2.3.0","pull_policy":"IfNotPresent"}' \
  $URL/api/deployments/prod/billing-api/image-ref

# Apply YAML: dry run first, then for real (all or nothing)
jq -n --rawfile y app.yaml '{yaml:$y, namespace:"prod"}' > body.json
curl -H "$AUTH" -H 'Content-Type: application/json' -d @body.json $URL/api/manifests/preview
curl -H "$AUTH" -H 'Content-Type: application/json' -d @body.json $URL/api/manifests/apply

# Scale, restart, autoscale
curl -X PUT  -H "$AUTH" -H 'Content-Type: application/json' -d '{"replicas":3}' $URL/api/deployments/prod/web/replicas
curl -X POST -H "$AUTH" $URL/api/deployments/prod/web/restart
curl -X PUT  -H "$AUTH" -H 'Content-Type: application/json' \
  -d '{"min_replicas":2,"max_replicas":10,"cpu_percent":70}' $URL/api/deployments/prod/web/autoscaling

# Registry contents and tag details
curl -H "$AUTH" $URL/api/registry
curl -H "$AUTH" "$URL/api/registry/tags?repo=team/billing"

# Clean up dangling images on the nodes: preview, then remove
curl -H "$AUTH" -H 'Content-Type: application/json' -d '{"mode":"dangling","dry_run":true}'  $URL/api/node-images/cleanup
curl -H "$AUTH" -H 'Content-Type: application/json' -d '{"mode":"dangling","dry_run":false}' $URL/api/node-images/cleanup
```

## All endpoints

### Workloads and image jobs

| Method and path | Body | Does |
|---|---|---|
| `GET /api/deployments?namespace=` | | List Deployments |
| `GET /api/deployments/{ns}/{name}` | | Details: containers, volumes, pods, autoscaler |
| `POST /api/deployments/{ns}/{name}/image` | form: `file`, `container`, `target_image`, `unique_tag`, `pull_policy`, `destination` (`registry` / `nodes`) | Upload a tar and roll it out; returns `job_id` |
| `POST /api/deployments/{ns}/{name}/image-ref` | `container`, `image`, `pull_policy` | Deploy an image already in the registry or on the nodes; returns `job_id` |
| `PUT /api/deployments/{ns}/{name}/replicas` | `replicas` | Scale |
| `POST /api/deployments/{ns}/{name}/restart` | | Rolling restart |
| `PUT /api/deployments/{ns}/{name}/autoscaling` | `min_replicas`, `max_replicas`, `cpu_percent`, `memory_percent`, `set_cpu_request` | Turn autoscaling on or change it |
| `DELETE /api/deployments/{ns}/{name}/autoscaling` | | Turn autoscaling off |
| `POST /api/deployments/{ns}/{name}/volumes` | `name`, `type`, `claim_name` / `path` / `source_name`, `mounts`, … | Add a volume |
| `DELETE /api/deployments/{ns}/{name}/volumes/{volume}` | | Remove a volume |
| `POST`/`DELETE /api/deployments/{ns}/{name}/env-from` | `container`, `kind`, `name`, `prefix` | Load environment from a config map or secret |
| `DELETE /api/deployments/{ns}/{name}/node-pin` | | Unpin from a node |
| `GET /api/deployments/{ns}/{name}/delete-preview` | | What deleting would remove or keep |
| `DELETE /api/deployments/{ns}/{name}?delete_services=` | | Delete (Editor or Admin) |
| `GET /api/jobs`, `GET /api/jobs/{id}` | | Image jobs and their log |
| `POST /api/jobs/{id}/rollback` | | Restore the previous image |
| `POST /api/nodes/load` | form: `file`, `target_image`, `unique_tag` | Load a tar onto every node without deploying |

### Registry and images on nodes

| Method and path | Body | Does |
|---|---|---|
| `GET /api/registry` | | Repositories and tags |
| `GET /api/registry/tags?repo=` | | Tag details: size, build time, platform, used by |
| `POST /api/registry/push` | form: `file`, `target_image`, `unique_tag` | Push a tar |
| `DELETE /api/registry/tags?repo=&tag=&force=` | | Delete a tag |
| `GET /api/registry/status`, `POST /api/registry/state` | `enabled` | Registry on/off switch |
| `POST /api/registry/configure-nodes` | | Let every node pull from the registry |
| `GET /api/node-images` | | Images on every node (runtime and Docker) |
| `POST /api/node-images/remove` | `node`, `image`, `source` (`runtime` / `docker`), `force` | Remove one image from a node |
| `POST /api/node-images/cleanup` | `mode` (`dangling` / `unused`), `docker`, `nodes`, `dry_run` | Preview or remove dangling and unused images |

### Apply YAML, config, storage, users

| Method and path | Does |
|---|---|
| `POST /api/manifests/preview` · `POST /api/manifests/apply` | Body `yaml`, `namespace`, `qualify_images`, `image_overrides` |
| `GET /api/manifests/export?kind=&namespace=&name=` | An object as clean YAML |
| `GET`/`POST /api/configmaps…`, `GET`/`PUT`/`DELETE /api/configmaps/{ns}/{name}` | Config maps |
| `GET`/`POST /api/secrets…`, `GET`/`PUT`/`DELETE /api/secrets/{ns}/{name}` | Secrets |
| `GET /api/storage/classes`, `POST /api/storage/classes/local` | Storage classes |
| `GET`/`POST /api/storage/pvs`, `DELETE /api/storage/pvs/{name}`, `POST …/{name}/release` | Persistent volumes |
| `GET /api/storage/pvcs`, `POST /api/storage/pvcs/{ns}`, `PUT …/{name}/size`, `DELETE …/{name}` | Claims |
| `GET /api/me` | Who am I: role, scope, capabilities |
| `GET`/`POST /api/users`, `PUT`/`DELETE /api/users/{name}`, `POST /api/users/{name}/token` | Users (admins with all-namespace scope) |
| `GET /api/namespaces`, `GET /api/agents`, `GET /api/audit`, `GET /api/config` | Namespaces, nodes and agents, change log, dashboard settings |
