"""
k8s-image-loader node agent.

Runs as a privileged DaemonSet on every node. Receives an image archive
(docker-archive or OCI tar) from the dashboard and imports it into the
node's container runtime:

  * containerd  -> `ctr -n k8s.io images import` (+ `ctr images tag`)
  * CRI-O       -> `skopeo copy <archive> containers-storage:<ref>`

Host paths are mounted under /host (see deploy/agent-daemonset.yaml).
"""
from __future__ import annotations

import asyncio
import hmac
import logging
import os
import re
import shutil
import socket
import time
import tomllib
import uuid
from pathlib import Path

import json

import httpx
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

VERSION = "1.5.2"

HOST_ROOT = Path(os.getenv("HOST_ROOT", "/host"))
WORK_DIR = Path(os.getenv("WORK_DIR", "/work"))
AGENT_TOKEN = os.getenv("AGENT_TOKEN", "")
NODE_NAME = os.getenv("NODE_NAME", socket.gethostname())
RUNTIME_OVERRIDE = os.getenv("RUNTIME", "auto").lower()  # auto | containerd | crio
IMPORT_TIMEOUT = int(os.getenv("IMPORT_TIMEOUT_SECONDS", "1800"))
CONTAINERD_NAMESPACE = os.getenv("CONTAINERD_NAMESPACE", "k8s.io")

CONTAINERD_SOCKETS = [
    os.getenv("CONTAINERD_SOCKET", ""),
    "run/containerd/containerd.sock",
    "var/run/containerd/containerd.sock",
]
CRIO_SOCKETS = ["run/crio/crio.sock", "var/run/crio/crio.sock"]
# Registry the nodes pull from (host:port as used in image references). Reported by /healthz.
REGISTRY_HOST = os.getenv("REGISTRY_HOST", "")
REGISTRY_HOST_RE = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?(:\d{1,5})?$")
CRIO_REGISTRY_DROPIN = "/etc/containers/registries.conf.d/50-k8s-image-loader.conf"
# Host directories under which the dashboard may create local-volume folders.
LOCAL_STORAGE_ROOTS = [r.rstrip("/") for r in os.getenv(
    "LOCAL_STORAGE_ROOTS", "/mnt/disks:/var/lib/k8s-volumes").split(":") if r.startswith("/")]

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("agent")

app = FastAPI(title="k8s-image-loader agent", version=VERSION)
_import_lock = asyncio.Lock()


# --------------------------------------------------------------------------- helpers
def _host(p: str) -> Path:
    return HOST_ROOT / p.lstrip("/")


def normalize_ref(ref: str) -> str:
    """Normalize an image reference the same way containerd/kubelet do."""
    ref = ref.strip()
    if "@" in ref:
        return ref
    first, _, rest = ref.partition("/")
    if not rest:
        ref = f"docker.io/library/{ref}"
    elif "." not in first and ":" not in first and first != "localhost":
        ref = f"docker.io/{ref}"
    last = ref.rsplit("/", 1)[-1]
    if ":" not in last:
        ref += ":latest"
    return ref


K3S_SOCKETS = ["run/k3s/containerd/containerd.sock"]


def _first_socket(paths: list[str]) -> str | None:
    return next((str(_host(p)) for p in paths if p and _host(p).is_socket()), None)


def detect_runtime(hint: str | None = None) -> dict:
    """Find the runtime the KUBELET uses on this node.

    `hint` comes from the dashboard, which reads it from the Node object
    (status.nodeInfo.containerRuntimeVersion): "crio", "containerd" or "k3s".
    A node can have several sockets (e.g. Docker's own containerd next to CRI-O),
    so without a hint and with both present we refuse to guess.
    """
    want = RUNTIME_OVERRIDE if RUNTIME_OVERRIDE in ("containerd", "crio", "k3s") else (hint or None)
    k3s = _first_socket(K3S_SOCKETS)
    ctd = _first_socket(CONTAINERD_SOCKETS)
    crio = _first_socket(CRIO_SOCKETS)
    if want == "crio":
        return {"runtime": "crio", "socket": crio} if crio else {"runtime": "unknown", "socket": None,
                "error": "the kubelet uses CRI-O but no CRI-O socket is mounted"}
    if want == "k3s":
        sock = k3s or ctd
        return {"runtime": "containerd", "socket": sock} if sock else {"runtime": "unknown", "socket": None,
                "error": "the kubelet uses k3s/RKE2 containerd but its socket is not mounted"}
    if want == "containerd":
        return {"runtime": "containerd", "socket": ctd} if ctd else {"runtime": "unknown", "socket": None,
                "error": "the kubelet uses containerd but no containerd socket is mounted"}
    if want == "docker":
        return {"runtime": "unknown", "socket": None,
                "error": "the kubelet uses Docker (cri-dockerd), which this agent does not support"}
    if crio and (ctd or k3s):
        return {"runtime": "ambiguous", "socket": None,
                "error": "both CRI-O and containerd sockets exist (Docker's containerd?); cannot tell which one "
                         "the kubelet uses. Set RUNTIME on the agent DaemonSet."}
    if k3s:
        return {"runtime": "containerd", "socket": k3s}
    if ctd:
        return {"runtime": "containerd", "socket": ctd}
    if crio:
        return {"runtime": "crio", "socket": crio}
    return {"runtime": "unknown", "socket": None, "error": "no containerd or CRI-O socket found on this node"}


def _toml_value(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, list):
        return "[" + ", ".join(_toml_value(x) for x in v) + "]"
    return json.dumps(str(v))          # a JSON string is a valid TOML basic string


def crio_storage_conf() -> Path:
    """A storage.conf for skopeo with CRI-O's exact settings, paths moved under the host mount.

    Options are NOT put into the containers-storage:[...] image name: that syntax splits on
    commas, so mountopt = "nodev,metacopy=on" would break (metacopy read as its own option).
    """
    data: dict = {}
    conf = _host("/etc/containers/storage.conf")
    if conf.is_file():
        try:
            data = tomllib.loads(conf.read_text())
        except Exception as exc:  # noqa: BLE001
            log.warning("could not parse %s: %s (using defaults)", conf, exc)
    st = data.get("storage", {})
    driver = os.getenv("CRIO_STORAGE_DRIVER") or st.get("driver") or "overlay"
    graphroot = st.get("graphroot") or "/var/lib/containers/storage"
    runroot = st.get("runroot") or "/run/containers/storage"
    lines = ["# generated by k8s-image-loader agent from the node's /etc/containers/storage.conf",
             "[storage]", f"driver = {_toml_value(driver)}",
             f"graphroot = {_toml_value(str(_host(graphroot)))}", f"runroot = {_toml_value(str(_host(runroot)))}"]
    opts = st.get("options", {}) or {}
    top = {k: v for k, v in opts.items() if not isinstance(v, dict) and k != "rootless_storage_path"}
    if "additionalimagestores" in top:
        top["additionalimagestores"] = [str(_host(p)) for p in top["additionalimagestores"]]
    if top:
        lines.append("[storage.options]")
        lines += [f"{k} = {_toml_value(v)}" for k, v in top.items()]
    for table, values in opts.items():
        if isinstance(values, dict):
            flat = {k: v for k, v in values.items() if not isinstance(v, dict)}
            if flat:
                lines.append(f"[storage.options.{table}]")
                lines += [f"{k} = {_toml_value(v)}" for k, v in flat.items()]
    WORK_DIR.mkdir(parents=True, exist_ok=True)
    out = WORK_DIR / "crio-storage.conf"
    tmp = out.with_suffix(".tmp")
    tmp.write_text("\n".join(lines) + "\n")
    tmp.replace(out)
    return out


async def run(cmd: list[str], timeout: int = IMPORT_TIMEOUT, env: dict | None = None,
              stdout_only: bool = False) -> str:
    """Run a command. stdout_only=True returns just stdout (for JSON output): warnings a tool
    prints on stderr are logged instead of being mixed into the data."""
    log.info("exec: %s", " ".join(cmd))
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE if stdout_only else asyncio.subprocess.STDOUT,
            env={**os.environ, **env} if env else None
        )
    except OSError as exc:  # binary missing or not executable
        raise RuntimeError(f"cannot run {cmd[0]}: {exc.strerror}") from exc
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        raise RuntimeError(f"command timed out after {timeout}s: {cmd[0]}")
    text = out.decode(errors="replace").strip()
    errtext = (err or b"").decode(errors="replace").strip()
    if proc.returncode != 0:
        detail = "\n".join(x for x in (errtext, text) if x)
        raise RuntimeError(f"`{' '.join(cmd[:4])} …` failed (exit {proc.returncode}): {detail[-2000:]}")
    if errtext:
        log.warning("%s wrote to stderr: %s", cmd[0], errtext[-500:])
    return text


def check_token(token: str | None) -> None:
    if not AGENT_TOKEN:
        return
    if not token or not hmac.compare_digest(token, AGENT_TOKEN):
        raise HTTPException(status_code=401, detail="invalid agent token")


# --------------------------------------------------------------------------- importers
async def import_containerd(sock: str, archive: Path, fmt: str, source: str | None, target: str) -> list[str]:
    base = ["ctr", "--address", sock, "-n", CONTAINERD_NAMESPACE]
    target_n = normalize_ref(target)
    steps: list[str] = []

    cmd = base + ["images", "import", "--digests"]
    if fmt == "oci" and not source:
        # OCI archive without a full image name: name the index after the target.
        cmd += ["--index-name", target_n]
    cmd.append(str(archive))
    steps.append(await run(cmd))

    if source:
        source_n = normalize_ref(source)
        if source_n != target_n:
            steps.append(await run(base + ["images", "tag", "--force", source_n, target_n], timeout=120))

    listing = await run(base + ["images", "ls", "-q"], timeout=120)
    if target_n not in listing.splitlines():
        raise RuntimeError(f"import finished but {target_n} is not present in containerd")
    return steps


async def import_crio(archive: Path, fmt: str, source: str | None, target: str) -> list[str]:
    if fmt == "docker":
        src = f"docker-archive:{archive}" + (f":{source}" if source else "")
    else:
        src = f"oci-archive:{archive}"
    ref = normalize_ref(target)
    env = {"CONTAINERS_STORAGE_CONF": str(crio_storage_conf())}
    out = await run(["skopeo", "copy", "--quiet", src, f"containers-storage:{ref}"], env=env)
    # read it back from CRI-O's storage: never report success without proof
    await run(["skopeo", "inspect", "--format", "{{.Name}}", f"containers-storage:{ref}"], timeout=120, env=env)
    return [out]


# --------------------------------------------------------------------------- routes
# --------------------------------------------------------------------------- registry trust
def _is_k3s(sock: str | None) -> str | None:
    if sock and "/k3s/" in sock:
        return "k3s"
    if sock and "/rke2/" in sock:
        return "rke2"
    return None


def containerd_hosts_file(host: str) -> Path:
    return _host(f"/etc/containerd/certs.d/{host}/hosts.toml")


def registry_status(host: str, hint: str | None = None) -> dict:
    """Whether this node's runtime is set up to pull from `host` over plain HTTP."""
    if not host:
        return {"state": "unset"}
    rt = detect_runtime(hint)
    if rt["runtime"] == "containerd":
        if _is_k3s(rt["socket"]):
            dist = _is_k3s(rt["socket"])
            conf = _host(f"/etc/rancher/{dist}/registries.yaml")
            ok = conf.is_file() and host in conf.read_text(errors="ignore")
            return {"state": "ok" if ok else "manual"}
        return {"state": "ok" if containerd_hosts_file(host).is_file() else "missing"}
    if rt["runtime"] == "crio":
        f = _host(CRIO_REGISTRY_DROPIN)
        return {"state": "ok" if f.is_file() and host in f.read_text(errors="ignore") else "missing"}
    return {"state": "unknown"}


async def containerd_uses_hosts_dir(sock: str) -> tuple[bool, str]:
    """containerd reads certs.d only if config_path is set (default from containerd 2.0)."""
    conf = _host("/etc/containerd/config.toml")
    if conf.is_file() and re.search(r"^\s*config_path\s*=\s*[\"'][^\"']+", conf.read_text(errors="ignore"), re.M):
        return True, "config_path is set"
    try:
        out = await run(["ctr", "--address", sock, "version"], timeout=15)
        m = re.search(r"Server:.*?Version:\s*v?(\d+)", out, re.S)
        if m and int(m[1]) >= 2:
            return True, f"containerd {m[1]}.x reads certs.d by default"
    except RuntimeError:
        pass
    return False, "config_path is not set in /etc/containerd/config.toml"


class RegistryIn(BaseModel):
    host: str
    runtime: str | None = None      # what the kubelet uses, from the Node object


@app.post("/registry-config")
async def registry_config(body: RegistryIn, x_agent_token: str | None = Header(default=None)):
    """Let the node runtime pull from the local registry over plain HTTP."""
    check_token(x_agent_token)
    host = body.host.strip()
    if not REGISTRY_HOST_RE.match(host):
        raise HTTPException(400, f"'{host}' is not a valid registry host[:port]")
    rt = detect_runtime(body.runtime)
    result = {"node": NODE_NAME, "runtime": rt["runtime"], "host": host}

    if rt["runtime"] == "containerd":
        dist = _is_k3s(rt["socket"])
        if dist:
            snippet = f'mirrors:\n  "{host}":\n    endpoint:\n      - "http://{host}"\n'
            return {**result, "state": "manual",
                    "message": f"{dist} manages containerd's registry config. Add this to "
                               f"/etc/rancher/{dist}/registries.yaml on the node, then restart {dist}:\n{snippet}"}
        f = containerd_hosts_file(host)
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(f'# Managed by k8s-image-loader\nserver = "http://{host}"\n\n'
                     f'[host."http://{host}"]\n  capabilities = ["pull", "resolve"]\n  skip_verify = true\n')
        ok, why = await containerd_uses_hosts_dir(rt["socket"])
        if ok:
            return {**result, "state": "ok", "message": f"Wrote {f.relative_to(HOST_ROOT)}; {why}. No restart needed."}
        return {**result, "state": "action-needed",
                "message": f"Wrote /etc/containerd/certs.d/{host}/hosts.toml, but {why}. Add under "
                           '[plugins."io.containerd.grpc.v1.cri".registry] the line '
                           'config_path = "/etc/containerd/certs.d", then restart containerd.'}

    if rt["runtime"] == "crio":
        f = _host(CRIO_REGISTRY_DROPIN)
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(f'# Managed by k8s-image-loader\n[[registry]]\nlocation = "{host}"\ninsecure = true\n')
        return {**result, "state": "action-needed",
                "message": f"Wrote {CRIO_REGISTRY_DROPIN}. Run 'systemctl reload crio' on the node to apply it."}

    raise HTTPException(500, rt.get("error") or "no containerd or CRI-O socket found on this node")


# --------------------------------------------------------------------------- images on this node
DOCKER_SOCKETS = ["run/docker.sock", "var/run/docker.sock"]
_SIZE_UNITS = {"B": 1, "KB": 10**3, "MB": 10**6, "GB": 10**9, "KIB": 2**10, "MIB": 2**20, "GIB": 2**30, "TIB": 2**40}


def _parse_size(text: str) -> int | None:
    m = re.match(r"^([\d.]+)\s*([A-Za-z]+)$", text.strip())
    return int(float(m[1]) * _SIZE_UNITS.get(m[2].upper(), 1)) if m else None


def _json_from(text: str, tool: str) -> dict:
    """Parse JSON output, skipping any text a tool printed before it."""
    text = text.strip()
    if not text:
        return {}
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        if start >= 0:
            try:
                return json.JSONDecoder().raw_decode(text[start:])[0]
            except json.JSONDecodeError:
                pass
    raise RuntimeError(f"{tool} did not return JSON; it printed: {text[:300]!r}")


def _crio_store_images() -> list[dict]:
    """Read CRI-O's image store directly (containers-storage images.json + layers.json)."""
    data: dict = {}
    conf = _host("/etc/containers/storage.conf")
    if conf.is_file():
        try:
            data = tomllib.loads(conf.read_text())
        except Exception:  # noqa: BLE001
            data = {}
    st = data.get("storage", {})
    driver = os.getenv("CRIO_STORAGE_DRIVER") or st.get("driver") or "overlay"
    root = _host(st.get("graphroot") or "/var/lib/containers/storage")
    images_json = root / f"{driver}-images" / "images.json"
    if not images_json.is_file():
        raise RuntimeError(f"CRI-O image store not found at {images_json.relative_to(HOST_ROOT)}")
    layers = {}
    layers_json = root / f"{driver}-layers" / "layers.json"
    if layers_json.is_file():
        for l in json.loads(layers_json.read_text() or "[]"):
            layers[l.get("id")] = l
    out = []
    for img in json.loads(images_json.read_text() or "[]"):
        size, lid, seen = 0, img.get("layer"), set()
        while lid and lid in layers and lid not in seen:        # walk the layer chain for the size
            seen.add(lid)
            size += layers[lid].get("diff-size") or layers[lid].get("compressed-size") or 0
            lid = layers[lid].get("parent")
        names = img.get("names") or []
        out.append({"id": (img.get("id") or "")[:12], "tags": [n for n in names if "@" not in n],
                    "digests": [n for n in names if "@" in n], "size": size or None, "pinned": False})
    return out


async def _runtime_images(rt: dict) -> list[dict]:
    """What the kubelet sees: via crictl (the CRI, same as the kubelet), else ctr for containerd."""
    sock = rt["socket"]
    crictl_error = None
    if shutil.which("crictl"):
        try:
            out = await run(["crictl", "--runtime-endpoint", f"unix://{sock}", "--image-endpoint", f"unix://{sock}",
                             "--timeout", "20s", "images", "-o", "json"], timeout=60, stdout_only=True)
            listing = _json_from(out, "crictl")
        except RuntimeError as exc:
            crictl_error, listing = str(exc), None
            log.warning("crictl images failed, falling back: %s", exc)
    else:
        listing = None
    if listing is not None:
        imgs = []
        for i in listing.get("images") or []:
            imgs.append({"id": (i.get("id") or "").removeprefix("sha256:")[:12], "tags": i.get("repoTags") or [],
                         "digests": i.get("repoDigests") or [], "size": int(i.get("size") or 0) or None,
                         "pinned": bool(i.get("pinned"))})
        return imgs
    if rt["runtime"] == "containerd":
        out = await run(["ctr", "--address", sock, "-n", CONTAINERD_NAMESPACE, "images", "ls"], timeout=60, stdout_only=True)
        by_digest: dict[str, dict] = {}
        for line in out.splitlines()[1:]:
            cols = re.split(r"\s{2,}|\t", line.strip())
            if len(cols) < 4:
                continue
            ref, digest, size = cols[0], cols[2], cols[3]
            e = by_digest.setdefault(digest, {"id": digest.removeprefix("sha256:")[:12], "tags": [], "digests": [],
                                              "size": _parse_size(size), "pinned": False})
            if ref.startswith("sha256:"):
                continue
            (e["digests"] if "@sha256:" in ref else e["tags"]).append(ref)
        return list(by_digest.values())
    if rt["runtime"] == "crio":
        try:
            return _crio_store_images()
        except (RuntimeError, OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"{crictl_error or 'crictl is not available'}; reading CRI-O's image store also failed: {exc}")
    raise RuntimeError(crictl_error or "crictl is not available")


async def _docker_images() -> list[dict] | None:
    sock = _first_socket(DOCKER_SOCKETS)
    if not sock:
        return None
    try:
        async with httpx.AsyncClient(transport=httpx.AsyncHTTPTransport(uds=sock), timeout=10) as http:
            r = await http.get("http://docker/images/json")
            r.raise_for_status()
    except (httpx.HTTPError, OSError):
        return None
    return [{"id": (i.get("Id") or "").removeprefix("sha256:")[:12],
             "tags": [t for t in (i.get("RepoTags") or []) if t != "<none>:<none>"],
             "digests": [d for d in (i.get("RepoDigests") or []) if not d.startswith("<none>")],
             "size": i.get("Size"), "pinned": False} for i in r.json()]


@app.get("/images")
async def images(runtime: str | None = None, x_agent_token: str | None = Header(default=None)):
    """Images on this node: the runtime the kubelet uses, plus Docker's (not used by Kubernetes) if present."""
    check_token(x_agent_token)
    rt = detect_runtime(runtime)
    if rt["runtime"] not in ("containerd", "crio"):
        raise HTTPException(500, rt.get("error") or "no container runtime found")
    # A failing runtime listing must not hide the rest: report it and still return Docker's images
    error = None
    try:
        imgs = await _runtime_images(rt)
    except (RuntimeError, OSError, json.JSONDecodeError) as exc:
        imgs, error = [], f"cannot list {rt['runtime']} images: {exc}"
        log.error(error)
    return {"node": NODE_NAME, "runtime": rt["runtime"], "images": imgs, "error": error, "docker": await _docker_images()}


class RemoveIn(BaseModel):
    image: str
    runtime: str | None = None


@app.post("/images/remove")
async def remove_image(body: RemoveIn, x_agent_token: str | None = Header(default=None)):
    """Remove an image from the runtime (fails if a running container uses it)."""
    check_token(x_agent_token)
    if not re.fullmatch(r"[A-Za-z0-9._/:@\-]+", body.image):
        raise HTTPException(400, "invalid image reference")
    rt = detect_runtime(body.runtime)
    if rt["runtime"] not in ("containerd", "crio"):
        raise HTTPException(500, rt.get("error") or "no container runtime found")
    sock = rt["socket"]
    try:
        if shutil.which("crictl"):
            out = await run(["crictl", "--runtime-endpoint", f"unix://{sock}", "--image-endpoint", f"unix://{sock}",
                             "rmi", body.image], timeout=120)
        elif rt["runtime"] == "containerd":
            out = await run(["ctr", "--address", sock, "-n", CONTAINERD_NAMESPACE, "images", "rm", body.image], timeout=120)
        else:
            raise RuntimeError("crictl is not available")
    except RuntimeError as exc:
        msg = str(exc)
        if "in use" in msg or "being used" in msg:
            msg = "a container on this node still uses it; stop those pods first"
        raise HTTPException(409, f"{NODE_NAME}: {msg}")
    log.info("removed image %s on %s", body.image, NODE_NAME)
    return {"node": NODE_NAME, "removed": body.image, "output": out[-500:]}


@app.get("/healthz")
async def healthz(runtime: str | None = None):
    rt = detect_runtime(runtime)
    return {
        "node": NODE_NAME,
        "version": VERSION,
        "runtime": rt["runtime"],
        "socket": rt["socket"],
        "busy": _import_lock.locked(),
        "runtime_error": rt.get("error"),
        "registry": {"host": REGISTRY_HOST, **registry_status(REGISTRY_HOST, runtime)},
        "free_disk_bytes": shutil.disk_usage(WORK_DIR).free if WORK_DIR.exists() else None,
    }


class MkdirIn(BaseModel):
    path: str
    mode: str = "0775"


@app.post("/mkdir")
async def mkdir(body: MkdirIn, x_agent_token: str | None = Header(default=None)):
    """Create a directory for a local persistent volume, only under LOCAL_STORAGE_ROOTS."""
    check_token(x_agent_token)
    path = os.path.normpath(body.path)
    root = next((r for r in LOCAL_STORAGE_ROOTS if path.startswith(r + "/")), None)
    if not root or ".." in body.path.split("/"):
        raise HTTPException(400, f"{body.path} is outside the allowed roots: {', '.join(LOCAL_STORAGE_ROOTS)}")
    try:
        mode = int(body.mode, 8)
    except ValueError:
        raise HTTPException(400, "mode must be octal, e.g. 0775")
    if mode & ~0o777:
        raise HTTPException(400, "mode must be between 0000 and 0777")
    target = _host(path)
    existed = target.exists()
    if existed and not target.is_dir():
        raise HTTPException(409, f"{path} exists on {NODE_NAME} and is not a directory")
    if not _host(root).is_dir():
        raise HTTPException(500, f"{root} is not mounted into the agent; check the DaemonSet volumes")
    target.mkdir(parents=True, exist_ok=True)
    if not existed:
        target.chmod(mode)
    log.info("mkdir %s on %s (existed=%s)", path, NODE_NAME, existed)
    return {"node": NODE_NAME, "path": path, "created": not existed}


@app.post("/load")
async def load(
    request: Request,
    x_agent_token: str | None = Header(default=None),
    x_target_image: str = Header(...),
    x_source_ref: str | None = Header(default=None),
    x_archive_format: str = Header(default="docker"),
    x_node_runtime: str | None = Header(default=None),
):
    check_token(x_agent_token)
    if not re.fullmatch(r"[A-Za-z0-9._/:@\-]+", x_target_image):
        raise HTTPException(400, "invalid target image reference")
    fmt = "oci" if x_archive_format == "oci" else "docker"

    rt = detect_runtime(x_node_runtime)
    if rt["runtime"] not in ("containerd", "crio"):
        raise HTTPException(500, rt.get("error") or "no containerd or CRI-O socket found on this node")

    WORK_DIR.mkdir(parents=True, exist_ok=True)
    archive = WORK_DIR / f"{uuid.uuid4().hex}.tar"
    started = time.monotonic()
    size = 0
    try:
        with archive.open("wb") as fh:
            async for chunk in request.stream():
                fh.write(chunk)
                size += len(chunk)
        received = time.monotonic() - started

        async with _import_lock:
            if rt["runtime"] == "containerd":
                output = await import_containerd(rt["socket"], archive, fmt, x_source_ref, x_target_image)
            else:
                output = await import_crio(archive, fmt, x_source_ref, x_target_image)

        result = {
            "node": NODE_NAME,
            "runtime": rt["runtime"],
            "image": normalize_ref(x_target_image),
            "bytes": size,
            "receive_seconds": round(received, 2),
            "total_seconds": round(time.monotonic() - started, 2),
            "output": "\n".join(o for o in output if o)[-4000:],
        }
        log.info("loaded %s on %s via %s", result["image"], NODE_NAME, rt["runtime"])
        return result
    except RuntimeError as exc:
        log.error("import failed: %s", exc)
        return JSONResponse(status_code=500, content={"node": NODE_NAME, "runtime": rt["runtime"], "detail": str(exc)})
    finally:
        archive.unlink(missing_ok=True)
